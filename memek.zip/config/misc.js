// config/misc.js
// Berisi perintah lain-lain / contoh

const handleHello = async (context) => {
    const { reply } = context;
    reply("<blockquote>Hello juga!</blockquote>", {
        parse_mode: 'HTML'
    });
};

module.exports = {
    'hello': handleHello,
};

