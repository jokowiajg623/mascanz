const fs = require('fs');
// Import helper yang sudah kita buat
const { editReply, readJson, writeJson } = require('./helpers.js');

// Definisikan path file database
const ALLOWED_GROUPS_FILE = './src/database/allowed_groups.json';
const PARTNER_FILE = './src/database/partner.json';
const RESELLER_FILE = './src/database/reseller.json';
const SELLER_FILE = './src/database/seller.json';
const OWNER_FILE = './owner.json';
const BACKUP_STATUS_FILE = './src/database/backup_status.json'; // File status backup

// --- Server Config ---
const handleSetServerConfig = async (context) => {
    const { command, isOwner, reply, mess, text, prefix } = context;
    if (!isOwner) return reply(mess.owner);

    const serverVersion = command.endsWith('v2') ? 'v2' : command.endsWith('v3') ? 'v3' : command.endsWith('v4') ? 'v4' : '';
    const configPath = './config/settings.js';

    let key;
    if (command.startsWith('seturl')) {
        key = `global.domain${serverVersion ? serverVersion.toUpperCase() : ''}`;
    } else if (command.startsWith('setplta')) {
        key = `global.plta${serverVersion ? serverVersion.toUpperCase() : ''}`;
    } else if (command.startsWith('setpltc')) {
        key = `global.pltc${serverVersion ? serverVersion.toUpperCase() : ''}`;
    }

    if (!text) {
        return reply(`<blockquote><b>Format salah!</b>\n\nPenggunaan:\n${prefix + command} [nilai_baru]\n\nContoh:\n${prefix + command} https://panel.contoh.com</blockquote>`, {
            parse_mode: 'HTML'
        });
    }

    let settingsContent = fs.readFileSync(configPath, 'utf8');
    const regex = new RegExp(`${key}\\s*=\\s*['"\`].*?['"\`]`, 's');

    if (regex.test(settingsContent)) {
        settingsContent = settingsContent.replace(regex, `${key} = '${text}'`);
        fs.writeFileSync(configPath, settingsContent, 'utf8');

        if (command.startsWith('seturl')) {
            global[`domain${serverVersion ? serverVersion.toUpperCase() : ''}`] = text;
        } else if (command.startsWith('setplta')) {
            global[`plta${serverVersion ? serverVersion.toUpperCase() : ''}`] = text;
        } else if (command.startsWith('setpltc')) {
            global[`pltc${serverVersion ? serverVersion.toUpperCase() : ''}`] = text;
        }

        reply(`<blockquote>✅ Nilai untuk <b>${key}</b> berhasil diubah menjadi: <code>${text}</code></blockquote>`, {
            parse_mode: 'HTML'
        });
    } else {
        reply(`<blockquote>❌ Variabel <b>${key}</b> tidak ditemukan di file settings.js.</blockquote>`, {
            parse_mode: 'HTML'
        });
    }
};

// --- Backup Management ---
const handleBackup = async (context) => {
    const { isOwner, reply, mess, exec, fs, InputFile, xy, path, generateReadableString, editReply } = context;
    if (!isOwner) return reply(mess.owner);

    const backupName = `backup.zip`;
    const backupPath = path.join(process.cwd(), backupName);
    
    const filesToBackup = 'config src index.js owner.json package.json sessions run.js'; 

    const sentMessage = await reply(`<blockquote>⏳ <b>Membuat file backup (${backupName})...</b>\n\nFile yang di-backup: <code>${filesToBackup}</code></blockquote>`, { parse_mode: 'HTML' });

    exec(`zip -r ${backupPath} ${filesToBackup}`, async (error, stdout, stderr) => {
        if (error) {
            console.error(`Error backup: ${error.message}`);
            // Menggunakan editReply untuk pesan loading yang sudah dikirim
            return editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal membuat backup: ${error.message.substring(0, 100)}...</blockquote>`);
        }
        
        if (fs.existsSync(backupPath)) {
            try {
                // 1. Kirim file ZIP ke Owner
                await xy.api.sendDocument(xy.from.id, new InputFile(backupPath, backupName), {
                    caption: `<blockquote>✅ <b>Backup Berhasil Dibuat!</b>\n\nIni adalah file ZIP backup bot Anda.</blockquote>`,
                    parse_mode: 'HTML'
                });


                await editReply(xy, sentMessage.message_id, `<blockquote>✅ <b>Backup Berhasil!</b>\n\nFile (<code>${backupName}</code>) telah dikirim di pesan pribadi Anda.</blockquote>`);
                
            } catch (sendError) {
                console.error(`Error mengirim backup: ${sendError.message}`);

                await editReply(xy, sentMessage.message_id, `<blockquote>⚠️ <b>Backup Berhasil Dibuat, tapi GAGAL dikirim!</b>\n\nAnda mungkin memblokir bot atau bot tidak bisa mengirim file dokumen. Coba di chat pribadi dengan bot.</blockquote>`);
            } finally {

                try {
                    fs.unlinkSync(backupPath);
                    console.log(`[BACKUP MANUAL] File ${backupName} berhasil dihapus dari server.`);
                } catch (unlinkError) {
                    console.error(`[BACKUP MANUAL] Gagal menghapus file ${backupName}:`, unlinkError.message);
                }
            }
        } else {
            await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal membuat file backup. File ZIP tidak ditemukan.</blockquote>`);
        }
    });
};

const handleAutobackupToggle = async (context) => {
    const { isOwner, reply, mess, command, readJson, writeJson, xy } = context;
    if (!isOwner) return reply(mess.owner);

    const isActivate = command === 'autobackupon';
    let statusData = readJson(BACKUP_STATUS_FILE, { active: false, ownerChatId: null });

    const statusText = isActivate ? 'DIAKTIFKAN' : 'DINONAKTIFKAN';
    const emoji = isActivate ? '✅' : '❌';

    if (isActivate) {
        statusData.active = true;
        statusData.ownerChatId = xy.from.id; // Simpan ID chat owner
        

        try {
            await xy.api.sendMessage(xy.from.id, `<blockquote>${emoji} Fitur Auto-Backup berhasil <b>${statusText}</b>! Backup akan dikirim ke ID chat ini setiap 30 menit.</blockquote>`, { parse_mode: 'HTML' });
            writeJson(BACKUP_STATUS_FILE, statusData);
            return reply(`<blockquote>${emoji} Auto-Backup berhasil <b>${statusText}</b>!\n\nNotifikasi dan file backup akan dikirim ke chat pribadi Anda.</blockquote>`, { parse_mode: 'HTML' });
        } catch (e) {
            statusData.active = false;
            statusData.ownerChatId = null;
            writeJson(BACKUP_STATUS_FILE, statusData);
            return reply(`<blockquote>❌ Gagal mengaktifkan Auto-Backup: Bot gagal mengirim pesan ke Anda. Pastikan Anda tidak memblokir bot dan sudah memulai chat.</blockquote>`, { parse_mode: 'HTML' });
        }

    } else {
        statusData.active = false;
        writeJson(BACKUP_STATUS_FILE, statusData);
        return reply(`<blockquote>${emoji} Auto-Backup berhasil <b>${statusText}</b>!</blockquote>`, { parse_mode: 'HTML' });
    }
};


// --- Owner Management ---
const handleAddOwner = async (context) => {
    const { isOwner, reply, mess, text, owners } = context;
    if (!isOwner) return reply(mess.owner);
    if (!text) return reply('<blockquote>📌 Penggunaan yang benar:\n/addowner ID_Telegram\n(ID harus berupa angka).</blockquote>', {
        parse_mode: 'HTML'
    });
    if (owners.includes(text)) {
        return reply(`<blockquote>⚠️ ID Telegram ${text} sudah menjadi Owner.</blockquote>`, {
            parse_mode: 'HTML'
        });
    }
    owners.push(text);
    fs.writeFileSync(OWNER_FILE, JSON.stringify(owners, null, 2));
    return reply(`<blockquote>✅ ID Telegram ${text} telah ditambahkan ke daftar Owner!</blockquote>`, {
        parse_mode: 'HTML'
    });
};
const handleDelOwner = async (context) => {
    const { isOwner, reply, mess, text, owners } = context;
    if (!isOwner) return reply(mess.owner);
    if (!text) return reply('<blockquote>📌 Penggunaan:\n/delowner ID_Telegram\nContoh: /delowner 1234567890</blockquote>', {
        parse_mode: 'HTML'
    });
    const index = owners.indexOf(text);
    if (index !== -1) {
        owners.splice(index, 1);
        fs.writeFileSync(OWNER_FILE, JSON.stringify(owners, null, 2));
        return reply(`<blockquote>✅ ID Telegram ${text} telah dihapus dari daftar Owner.</blockquote>`, {
            parse_mode: 'HTML'
        });
    } else {
        return reply(`<blockquote>⚠️ ID Telegram ${text} tidak ditemukan dalam daftar Owner.</blockquote>`, {
            parse_mode: 'HTML'
        });
    }
};
const handleListOwner = async (context) => {
    const { xy, isOwner, reply, mess, owners } = context;
    if (!isOwner) return reply(mess.owner);
    if (owners.length === 0) return reply('<blockquote>🚫 Belum ada Owner yang terdaftar.</blockquote>', {
        parse_mode: 'HTML'
    });
    const sentMessage = await reply(`<blockquote>⏳ <b>Memuat daftar Owner...</b></blockquote>`, {
        parse_mode: 'HTML'
    });
    (async () => {
        let list = [];
        for (let id of owners) {
            try {
                const user = await xy.api.getChat(id);
                const name = [user.first_name, user.last_name].filter(Boolean).join(' ');
                list.push(`🆔 <b>ID:</b> ${id}\n👑 <b>Nama:</b> ${name}`);
            } catch (e) {
                list.push(`🆔 <b>ID:</b> ${id}\n👑 <b>Nama:</b> Tidak ditemukan`);
            }
        }
        const daftar = `📜 <b>Daftar Owner:</b>\n\n${list.join('\n\n')}`;
        await editReply(xy, sentMessage.message_id, `<blockquote>${daftar}</blockquote>`);
    })();
};

// --- Group Management ---
const handleAddGrub = async (context) => {
    const { xy, isOwner, reply, mess, text } = context;
    if (!isOwner) return reply(mess.owner);
    const targetId = text.trim();
    if (!targetId || !/^-?\d+$/.test(targetId)) {
        return reply('<blockquote>❌ Format salah!\n\nPenggunaan: <code>/addgrub [ID Grup]</code></blockquote>', { parse_mode: 'HTML' });
    }
    const file = ALLOWED_GROUPS_FILE;
    let listData = readJson(file);
    if (listData.some(g => String(g.id) === targetId)) {
        return reply(`<blockquote>⚠️ Grup ID <b>${targetId}</b> sudah terdaftar sebagai grup yang diizinkan.</blockquote>`, { parse_mode: 'HTML' });
    }
    const sentMessage = await reply(`<blockquote>⏳ <b>Mencoba mengambil nama grup untuk ID ${targetId}...</b></blockquote>`, { parse_mode: 'HTML' });
    let groupName = `ID: ${targetId}`;
    try {
        const chatInfo = await xy.api.getChat(targetId);
        groupName = chatInfo.title || `Grup Tanpa Nama (ID: ${targetId})`;
    } catch (e) {
        console.error(`Gagal mendapatkan info grup ${targetId}:`, e.message);
        groupName = `Grup Tidak Dikenal (ID: ${targetId})`;
    }
    listData.push({ id: targetId, name: groupName, added_by: xy.from.id, date: new Date().toISOString() });
    writeJson(file, listData);
    await editReply(xy, sentMessage.message_id, `<blockquote>✅ Grup <b>${groupName}</b> (ID: <code>${targetId}</code>) berhasil ditambahkan ke daftar grup yang diizinkan.</blockquote>`);
};
const handleDelGrub = async (context) => {
    const { xy, isOwner, reply, mess, text } = context;
    if (!isOwner) return reply(mess.owner);
    const targetId = text.trim();
    if (!targetId || !/^-?\d+$/.test(targetId)) {
        return reply('<blockquote>❌ Format salah!\n\nPenggunaan: <code>/delgrub [ID Grup]</code> (Bisa di Private Chat)</blockquote>', { parse_mode: 'HTML' });
    }
    const isCurrentGroup = String(xy.chat.id) === targetId;
    const file = ALLOWED_GROUPS_FILE;
    let listData = readJson(file);
    const initialLength = listData.length;
    listData = listData.filter(g => String(g.id) !== targetId);
    if (listData.length === initialLength) {
        return reply(`<blockquote>⚠️ ID Grup <b>${targetId}</b> tidak ditemukan dalam daftar grup yang diizinkan.</blockquote>`, { parse_mode: 'HTML' });
    }
    writeJson(file, listData);
    let finalMsg = `✅ Grup ID <b>${targetId}</b> telah dihapus dari daftar yang diizinkan.`;
    try {
        await xy.api.leaveChat(targetId);
        finalMsg += `\n\n✅ Bot berhasil keluar dari grup <b>${targetId}</b>.`;
    } catch (e) {
        console.error(`Gagal keluar paksa dari grup ${targetId}:`, e.message);
        finalMsg += `\n\n⚠️ Gagal memaksa bot keluar dari grup <b>${targetId}</b>.\n(Pesan: Bot mungkin bukan admin di sana, atau ID salah).`;
        if (isCurrentGroup) {
            finalMsg += `\n\n[Eksekusi terjadi di grup ini.]`;
        }
    }
    reply(`<blockquote>${finalMsg}</blockquote>`, { parse_mode: 'HTML' });
};
const handleListGrub = async (context) => {
    const { xy, isOwner, reply, mess } = context;
    if (!isOwner) return reply(mess.owner);
    const file = ALLOWED_GROUPS_FILE;
    const listData = readJson(file);
    if (listData.length === 0) return reply('<blockquote>🚫 Belum ada grup yang diizinkan yang terdaftar.</blockquote>', { parse_mode: 'HTML' });
    const sentMessage = await reply(`<blockquote>⏳ <b>Memuat daftar Grup yang Diizinkan...</b></blockquote>`, { parse_mode: 'HTML' });
    (async () => {
        let list = [];
        for (let g of listData) {
            list.push(`🆔 <b>ID:</b> <code>${g.id}</code>\n📁 <b>Nama:</b> ${g.name || 'Tidak Dikenal'}\n`);
        }
        const daftar = `📜 <b>Daftar Grup yang Diizinkan:</b> (${listData.length} grup)\n\n${list.join('\n')}`;
        await editReply(xy, sentMessage.message_id, `<blockquote>${daftar}</blockquote>`);
    })();
};

// --- Seller Management ---
const handleAddSeller = async (context) => {
    const { isOwner, reply, mess, text, seller } = context; // 'seller' comes from context
    if (!isOwner) return reply(mess.owner);
    if (!text) return reply('<blockquote>Penggunaan: /addseller ID,durasi,waktu</blockquote>', {
        parse_mode: 'HTML'
    });
    const [id, dur, unit] = text.split(',');
    if (!id || !dur || !unit) return reply('<blockquote>Format salah! Contoh: /addseller 123456789,1,jam</blockquote>', {
        parse_mode: 'HTML'
    });
    const ms = {
        menit: 60000,
        jam: 3600000,
        hari: 86400000,
        bulan: 2592000000
    };
    const durasi = parseInt(dur);
    if (isNaN(durasi) || !ms[unit]) return reply('<blockquote>Durasi tidak valid atau waktu tidak dikenali.</blockquote>', {
        parse_mode: 'HTML'
    });
    if (seller.some(s => s.id === id)) return reply(`<blockquote>ID ${id} sudah jadi seller.</blockquote>`, {
        parse_mode: 'HTML'
    });
    seller.push({
        id,
        expiresAt: Date.now() + durasi * ms[unit]
    });
    fs.writeFileSync(SELLER_FILE, JSON.stringify(seller, null, 2));
    return reply(`<blockquote>ID ${id} ditambahkan selama ${durasi} ${unit}.</blockquote>`, {
        parse_mode: 'HTML'
    });
};
const handleDelSeller = async (context) => {
    const { isOwner, reply, mess, text, seller } = context;
    if (!isOwner) return reply(mess.owner);
    if (!text) return reply('<blockquote>Penggunaan: /delseller ID</blockquote>', {
        parse_mode: 'HTML'
    });
    const index = seller.findIndex(s => s.id === text);
    if (index === -1) return reply(`<blockquote>ID ${text} tidak ditemukan.</blockquote>`, {
        parse_mode: 'HTML'
    });
    seller.splice(index, 1);
    fs.writeFileSync(SELLER_FILE, JSON.stringify(seller, null, 2));
    return reply(`<blockquote>ID ${text} telah dihapus.</blockquote>`, {
        parse_mode: 'HTML'
    });
};
const handleListSeller = async (context) => {
    const { xy, isOwner, reply, mess, seller } = context;
    if (!isOwner) return reply(mess.owner);
    if (!seller.length) return reply('<blockquote>Belum ada seller.</blockquote>', {
        parse_mode: 'HTML'
    });
    const sentMessage = await reply(`<blockquote>⏳ <b>Memuat daftar Seller...</b></blockquote>`, {
        parse_mode: 'HTML'
    });
    (async () => {
        let list = [];
        let updatedSeller = [...seller];
        for (let s of updatedSeller) {
            const sisa = s.expiresAt - Date.now();
            if (sisa <= 0) {
                updatedSeller = updatedSeller.filter(x => x.id !== s.id);
                continue;
            }
            const jam = Math.floor(sisa / 3600000);
            const menit = Math.floor((sisa % 3600000) / 60000);
            const sisaWaktu = jam > 0 ? `${jam} jam ${menit} menit` : `${menit} menit`;
            try {
                const user = await xy.api.getChat(s.id);
                const nama = user.first_name + (user.last_name ? ' ' + user.last_name : '');
                list.push(`🆔 <b>ID:</b> ${s.id}\n👤 <b>Nama:</b> ${nama}\n⏳ <b>Waktu Tersisa:</b> ${sisaWaktu}`);
            } catch {
                list.push(`🆔 <b>ID:</b> ${s.id}\n👤 <b>Nama:</b> Tidak ditemukan\n⏳ <b>Waktu Tersisa:</b> ${sisaWaktu}`);
            }
        }
        fs.writeFileSync(SELLER_FILE, JSON.stringify(updatedSeller, null, 2));
        if (list.length === 0) {
            return editReply(xy, sentMessage.message_id, `<blockquote>🚫 Belum ada seller yang aktif.</blockquote>`);
        }
        const responseText = `📜 <b>Daftar Seller:</b>\n\n${list.join('\n\n')}`;
        await editReply(xy, sentMessage.message_id, `<blockquote>${responseText}</blockquote>`);
    })();
};

// --- Partner/Reseller Management ---
const handleAddRole = async (context) => {
    const { xy, command, isOwner, reply, mess } = context;
    if (!isOwner) return reply(mess.owner);
    const isResellerCommand = command.startsWith('rt');
    const file = isResellerCommand ? RESELLER_FILE : PARTNER_FILE;
    const panelName = isResellerCommand ? 'Reseller Panel' : 'Partner Panel';
    const serverVersion = command.endsWith('2') ? 'v2' : command.endsWith('3') ? 'v3' : command.endsWith('4') ? 'v4' : 'v1';
    if (!xy.message.reply_to_message) {
        return reply(`<blockquote>❌ Balas pesan pengguna yang ingin di-add ke ${panelName}.</blockquote>`, {
            parse_mode: 'HTML'
        });
    }
    const userId = xy.message.reply_to_message.from.id;
    const userName = xy.message.reply_to_message.from.first_name || 'Pengguna';
    let listData = readJson(file, []);
    if (!Array.isArray(listData)) {
        listData = [];
    }
    const existingUserIndex = listData.findIndex(u => u.id === userId && u.server === serverVersion);
    if (existingUserIndex !== -1) {
        return reply(`<blockquote>⚠️ Pengguna <b>${userName}</b> sudah terdaftar di ${panelName} server <b>${serverVersion}</b>.</blockquote>`, {
            parse_mode: 'HTML'
        });
    }
    listData.push({
        id: userId,
        server: serverVersion
    });
    writeJson(file, listData);
    return reply(`<blockquote>✅ Pengguna <b>${userName}</b> berhasil ditambahkan ke ${panelName} server <b>${serverVersion}</b>.</blockquote>`, {
        parse_mode: 'HTML'
    });
};
const handleAddAllRole = async (context) => {
    const { xy, command, isOwner, reply, mess } = context;
    if (!isOwner) return reply(mess.owner);
    const isResellerCommand = command.startsWith('addallrt');
    const file = isResellerCommand ? RESELLER_FILE : PARTNER_FILE;
    const panelName = isResellerCommand ? 'Reseller Panel' : 'Partner Panel';
    if (!xy.message.reply_to_message) {
        return reply(`<blockquote>❌ Balas pesan pengguna yang ingin di-add ke semua ${panelName}.</blockquote>`, {
            parse_mode: 'HTML'
        });
    }
    const userId = xy.message.reply_to_message.from.id;
    const userName = xy.message.reply_to_message.from.first_name || 'Pengguna';
    const servers = ['v1', 'v2', 'v3', 'v4'];
    let addedCount = 0;
    let listData = readJson(file, []);
    if (!Array.isArray(listData)) {
        listData = [];
    }
    for (const server of servers) {
        const existingUserIndex = listData.findIndex(u => u.id === userId && u.server === server);
        if (existingUserIndex === -1) {
            listData.push({
                id: userId,
                server: server
            });
            addedCount++;
        }
    }
    if (addedCount > 0) {
        writeJson(file, listData);
        return reply(`<blockquote>✅ Pengguna <b>${userName}</b> berhasil ditambahkan ke ${addedCount} ${panelName}!</blockquote>`, {
            parse_mode: 'HTML'
        });
    } else {
        return reply(`<blockquote>⚠️ Pengguna <b>${userName}</b> sudah terdaftar di semua ${panelName}.</blockquote>`, {
            parse_mode: 'HTML'
        });
    }
};
const handleDelAllRole = async (context) => {
    const { command, isOwner, reply, mess } = context;
    if (!isOwner) return reply(mess.owner);
    const isResellerCommand = command === 'delallrt';
    const file = isResellerCommand ? RESELLER_FILE : PARTNER_FILE;
    const roleName = isResellerCommand ? 'Reseller' : 'Partner';
    let listData = readJson(file);
    if (listData.length === 0) {
        return reply(`<blockquote>⚠️ Tidak ada pengguna yang terdaftar sebagai <b>${roleName}</b>.</blockquote>`, {
            parse_mode: 'HTML'
        });
    }
    const initialCount = listData.length;
    listData = [];
    writeJson(file, listData);
    return reply(`<blockquote>✅ Berhasil menghapus semua (${initialCount}) data <b>${roleName}</b> dari semua server (V1-4).</blockquote>`, {
        parse_mode: 'HTML'
    });
};
const handleDelRole = async (context) => {
    const { xy, command, isOwner, reply, mess } = context;
    if (!isOwner) return reply(mess.owner);
    const isResellerCommand = command.startsWith('delrt');
    const file = isResellerCommand ? RESELLER_FILE : PARTNER_FILE;
    const panelName = isResellerCommand ? 'Reseller Panel' : 'Partner Panel';
    const serverVersion = command.endsWith('2') ? 'v2' : command.endsWith('3') ? 'v3' : command.endsWith('4') ? 'v4' : 'v1';
    const replyToMessage = xy.message.reply_to_message;
    if (!replyToMessage) {
        return reply(`<blockquote>❌ Harap balas pesan pengguna yang ingin dihapus dari ${panelName}.</blockquote>`, {
            parse_mode: 'HTML'
        });
    }
    const userId = replyToMessage.from.id;
    const userName = replyToMessage.from.first_name || 'Pengguna';
    let listData = readJson(file, []);
    if (!Array.isArray(listData)) {
        listData = [];
    }
    const initialLength = listData.length;
    listData = listData.filter(u => u.id !== userId || u.server !== serverVersion);
    if (listData.length === initialLength) {
        return reply(`<blockquote>⚠️ Pengguna <b>${userName}</b> (ID: ${userId}) tidak ditemukan di ${panelName} server <b>${serverVersion}</b>.</blockquote>`, {
            parse_mode: 'HTML'
        });
    }
    writeJson(file, listData);
    return reply(`<blockquote>✅ Pengguna <b>${userName}</b> (ID: ${userId}) berhasil dihapus dari ${panelName} server <b>${serverVersion}</b>.</blockquote>`, {
        parse_mode: 'HTML'
    });
};
const handleListRole = async (context) => {
    const { xy, command, isOwner, reply, mess } = context;
    if (!isOwner) return reply(mess.owner);
    const isResellerCommand = command.startsWith('listrt');
    const file = isResellerCommand ? RESELLER_FILE : PARTNER_FILE;
    const panelName = isResellerCommand ? 'Reseller Panel' : 'Partner Panel';
    let listData = readJson(file, []);
    if (!Array.isArray(listData)) {
        listData = [];
    }
    if (listData.length === 0) {
        return reply(`<blockquote>🚫 Belum ada pengguna yang terdaftar di ${panelName}.</blockquote>`, {
            parse_mode: 'HTML'
        });
    }
    const sentMessage = await reply(`<blockquote>⏳ <b>Memuat daftar ${panelName}...</b></blockquote>`, {
        parse_mode: 'HTML'
    });
    (async () => {
        const servers = ['v1', 'v2', 'v3', 'v4'];
        let message = `📜 <b>Daftar ${panelName}:</b>\n\n`;
        for (const server of servers) {
            const usersOnServer = listData.filter(u => u.server === server);
            if (usersOnServer.length > 0) {
                message += `<b>Server ${server}:</b>\n`;
                for (const user of usersOnServer) {
                    try {
                        const chat = await xy.api.getChat(user.id);
                        const name = chat.first_name || 'Pengguna';
                        message += `  - 🆔 ${user.id} (👤 ${name})\n`;
                    } catch (e) {
                        message += `  - 🆔 ${user.id} (👤 Tidak ditemukan)\n`;
                    }
                }
                message += '\n';
            }
        }
        if (message.endsWith('\n\n')) {
            message = message.slice(0, -2);
        }
        await editReply(xy, sentMessage.message_id, `<blockquote>${message}</blockquote>`);
    })();
};

// Ekspor semua fungsi dalam satu objek
module.exports = {
    // Server Config
    seturl: handleSetServerConfig,
    seturlv2: handleSetServerConfig,
    seturlv3: handleSetServerConfig,
    seturlv4: handleSetServerConfig,
    setplta: handleSetServerConfig,
    setpltav2: handleSetServerConfig,
    setpltav3: handleSetServerConfig,
    setpltav4: handleSetServerConfig,
    setpltc: handleSetServerConfig,
    setpltcv2: handleSetServerConfig,
    setpltcv3: handleSetServerConfig,
    setpltcv4: handleSetServerConfig,
    // Owner
    addowner: handleAddOwner,
    delowner: handleDelOwner,
    listowner: handleListOwner,
    // Group
    addgrub: handleAddGrub,
    delgrub: handleDelGrub,
    listgrub: handleListGrub,
    // Seller
    addseller: handleAddSeller,
    delseller: handleDelSeller,
    listseller: handleListSeller,
    // Partner
    pt: handleAddRole,
    pt2: handleAddRole,
    pt3: handleAddRole,
    pt4: handleAddRole,
    addallpt: handleAddAllRole,
    delallpt: handleDelAllRole,
    delpt: handleDelRole,
    delpt2: handleDelRole,
    delpt3: handleDelRole,
    delpt4: handleDelRole,
    listpt: handleListRole,
    // Reseller
    rt: handleAddRole,
    rt2: handleAddRole,
    rt3: handleAddRole,
    rt4: handleAddRole,
    addallrt: handleAddAllRole,
    delallrt: handleDelAllRole,
    delrt: handleDelRole,
    delrt2: handleDelRole,
    delrt3: handleDelRole,
    delrt4: handleDelRole,
    listrt: handleListRole,
    // Backup
    backup: handleBackup, // <-- Command Backup Manual
    autobackupon: handleAutobackupToggle, // <-- Command Aktifkan Auto Backup
    autobackuoff: handleAutobackupToggle, // <-- Command Nonaktifkan Auto Backup
};

