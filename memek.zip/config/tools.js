// config/tools.js
// Berisi semua logika untuk perintah utilitas dan tools

const fs = require('fs');
const axios = require('axios');
const path = require('path');
const { exec } = require("child_process");
const { createCanvas, loadImage } = require('canvas');

// Impor helpers
const {
    editReply,
    checkUserRole,
    getPanelConfig,
    sendChunkedMessage
} = require('./helpers.js');

// --- CEK ID ---
const handleCekId = async (context) => {
    const { xy, reply, text, botToken, InputFile, editReply, checkUserRole, createCanvas, loadImage, axios, Buffer } = context;

    let targetId = null;
    let targetUser = null;
    const targetIdInput = text.trim();
    const msg = xy.message;

    if (targetIdInput && /^\d+$/.test(targetIdInput)) {
        targetId = targetIdInput;
    } else if (msg.reply_to_message) {
        targetUser = msg.reply_to_message.from;
        targetId = String(targetUser.id);
        if (msg.reply_to_message.forward_from) {
            targetUser = msg.reply_to_message.forward_from;
            targetId = String(targetUser.id);
        }
    } else {
        targetUser = xy.from;
        targetId = String(targetUser.id);
    }

    if (!targetId) {
        return reply(`<blockquote>❌ ID target tidak valid. Harap gunakan format: <code>/cekid ID_TELEGRAM</code> atau reply pesan pengguna.</blockquote>`, { parse_mode: 'HTML' });
    }

    const sentMessage = await reply(`<blockquote>⏳ <b>Membuat Kartu ID untuk ${targetId}...</b></blockquote>`, { parse_mode: 'HTML' });

    (async () => {
        let fullName = '';
        let username = '-';
        let today = new Date().toISOString().split('T')[0];
        let photoUrl = null;

        if (!targetUser) {
            try {
                targetUser = await xy.api.getChat(targetId);
            } catch (e) { /* Abaikan jika tidak ditemukan */ }
        }

        if (targetUser) {
            fullName = `${targetUser.first_name || ''} ${targetUser.last_name || ''}`.trim();
            username = targetUser.username ? `@${targetUser.username}` : '-';
            try {
                const photos = await xy.api.getUserProfilePhotos(targetId, { limit: 1 });
                if (photos.total_count > 0) {
                    const fileId = photos.photos[0][0].file_id;
                    const file = await xy.api.getFile(fileId);
                    photoUrl = `https://api.telegram.org/file/bot${botToken}/${file.file_path}`;
                }
            } catch (e) { console.log('Gagal ambil foto profil (cekid):', e.message); }
        } else {
            fullName = `ID: ${targetId}`;
        }

        const isSellerRole = checkUserRole(targetId, ['seller'], '');
        const isOwnerRole = checkUserRole(targetId, ['owner'], '');
        const botRole = isOwnerRole ? 'Owner' : isSellerRole ? 'Seller' : 'User';

        const canvas = createCanvas(800, 450);
        const ctx = canvas.getContext('2d');

        // Latar belakang gradien
        const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
        gradient.addColorStop(0, '#0a4f44');
        gradient.addColorStop(1, '#128C7E');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        // Card putih
        ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
        if (typeof ctx.roundRect === 'function') {
            ctx.roundRect(40, 40, canvas.width - 80, canvas.height - 80, 20);
        } else {
            ctx.rect(40, 40, canvas.width - 80, canvas.height - 80); // Fallback
        }
        ctx.fill();

        // Judul
        ctx.fillStyle = '#0a4f44';
        ctx.font = 'bold 32px Arial';
        ctx.textAlign = 'center';
        ctx.fillText('ID CARD TELEGRAM', canvas.width / 2, 80);

        // Garis pemisah
        ctx.strokeStyle = '#0a4f44';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(50, 100);
        ctx.lineTo(canvas.width - 50, 100);
        ctx.stroke();

        // Foto Profil
        if (photoUrl) {
            try {
                const response = await axios.get(photoUrl, { responseType: 'arraybuffer' });
                const avatar = await loadImage(Buffer.from(response.data));
                ctx.save();
                ctx.beginPath(); ctx.arc(150, 220, 70, 0, Math.PI * 2, true); ctx.closePath(); ctx.clip();
                ctx.drawImage(avatar, 80, 150, 140, 140);
                ctx.restore();
                ctx.strokeStyle = '#0a4f44'; ctx.lineWidth = 3;
                ctx.beginPath(); ctx.arc(150, 220, 70, 0, Math.PI * 2, true); ctx.stroke();
            } catch (e) {
                ctx.fillStyle = '#ccc'; ctx.beginPath(); ctx.arc(150, 220, 70, 0, Math.PI * 2, true); ctx.fill();
            }
        } else {
            ctx.fillStyle = '#ccc'; ctx.beginPath(); ctx.arc(150, 220, 70, 0, Math.PI * 2, true); ctx.fill();
        }

        // Teks Info
        ctx.textAlign = 'left';
        ctx.fillStyle = '#333';
        ctx.font = 'bold 24px Arial';
        ctx.fillText('Informasi Pengguna:', 280, 150);
        ctx.font = '20px Arial';
        ctx.fillText(`Nama: ${fullName}`, 280, 190);
        ctx.fillText(`User ID: ${targetId}`, 280, 220);
        ctx.fillText(`Username: ${username}`, 280, 250);
        ctx.fillText(`Tanggal: ${today}`, 280, 280);
        ctx.fillText(`Role Bot: ${botRole}`, 280, 310);

        // Footer
        ctx.textAlign = 'center';
        ctx.font = 'italic 16px Arial';
        ctx.fillStyle = '#666';
        ctx.fillText(`ID Card by Jhonaley Tech`, canvas.width / 2, 410);

        const buffer = canvas.toBuffer('image/png');
        const caption = `👤 *Nama:* ${fullName}\n🆔️ *User ID:* \`${targetId}\`\n🌐 *Username:* ${username}`;

        await xy.api.sendPhoto(xy.chat.id, new InputFile(buffer, 'id_card.png'), {
            caption,
            parse_mode: "Markdown",
            reply_to_message_id: xy.message.message_id,
        });

        await xy.api.deleteMessage(xy.chat.id, sentMessage.message_id);
    })();
};

// --- INFO USER ---
const handleInfo = async (context) => {
    // (Fungsi ini sudah benar)
    const { xy, reply, text, mess, editReply, checkUserRole } = context;

    if (xy.chat.type === 'private') {
        return reply(mess.group);
    }

    let targetId = null;
    let targetUser = null;
    const targetIdInput = text.trim();

    if (targetIdInput && /^\d+$/.test(targetIdInput)) {
        targetId = targetIdInput;
    } else if (xy.message.reply_to_message) {
        targetUser = xy.message.reply_to_message.from;
        targetId = String(targetUser.id);
    } else {
        targetUser = xy.from;
        targetId = String(targetUser.id);
    }

    if (!targetId) {
        return reply(`<blockquote>❌ ID target tidak valid.</blockquote>`, { parse_mode: 'HTML' });
    }

    const sentMessage = await reply(`<blockquote>⏳ <b>Mengecek status pengguna ID ${targetId}...</b></blockquote>`, { parse_mode: 'HTML' });

    (async () => {
        let nameToDisplay = `ID: ${targetId}`;
        let usernameToDisplay = '-';

        if (!targetUser) {
            try {
                const user = await xy.api.getChat(targetId);
                targetUser = user;
                nameToDisplay = user.first_name + (user.last_name ? ' ' + user.last_name : '');
                usernameToDisplay = user.username || '-';
            } catch (e) {
                nameToDisplay = `ID: ${targetId} (Tidak Ditemukan)`;
            }
        } else {
            nameToDisplay = targetUser.first_name + (targetUser.last_name ? ' ' + targetUser.last_name : '');
            usernameToDisplay = targetUser.username || '-';
        }

        const statusV1 = checkUserRole(targetId, ['owner', 'partner', 'reseller'], 'v1');
        const statusV2 = checkUserRole(targetId, ['owner', 'partner', 'reseller'], 'v2');
        const statusV3 = checkUserRole(targetId, ['owner', 'partner', 'reseller'], 'v3');
        const statusV4 = checkUserRole(targetId, ['owner', 'partner', 'reseller'], 'v4');
        const isSellerRole = checkUserRole(targetId, ['seller'], '');
        const isOwnerRole = checkUserRole(targetId, ['owner'], '');

        const checkMark = '✅';
        const xMark = '❌';
        let isBotStarted = false;
        let startBotMessage = 'ℹ️ Sedang mencoba menghubungi user...';

        try {
            await xy.api.sendMessage(targetId, '✅ Cek Dulu Bang!');
            isBotStarted = true;
        } catch (error) {
            if (error.description && error.description.includes('403')) {
                isBotStarted = false;
            }
        }

        if (isBotStarted) {
            startBotMessage = `${checkMark} Oke Lu udah chat bot!`;
        } else {
            startBotMessage = `${xMark} Lu belom Chat bot Di Private!`;
        }

        const infoMessage = `
<b>— ${nameToDisplay} | INFO —</b>

🆔 <b>ID</b>: <code>${targetId}</code>
👤 <b>Username</b>: @${usernameToDisplay}
⭐ <b>Status Global</b>: ${isOwnerRole ? 'Owner' : isSellerRole ? 'Seller' : 'User'}
            
<b>— Status Panel Akses —</b>
- <b>Server V1</b>: ${statusV1 ? checkMark : xMark}
- <b>Server V2</b>: ${statusV2 ? checkMark : xMark}
- <b>Server V3</b>: ${statusV3 ? checkMark : xMark}
- <b>Server V4</b>: ${statusV4 ? checkMark : xMark}

<b>— Status Chat Bot —</b>
${startBotMessage}

${isBotStarted ? '\nSilahkan create panel sekarang.' : '\nchat dan /start bot terlebih dahulu!'}
`;

        await editReply(xy, sentMessage.message_id, `<blockquote>${infoMessage}</blockquote>`);
    })();
};

// --- TOTAL SERVER ---
const handleTotalServer = async (context) => {
    const { xy, reply, command, editReply, checkUserRole, axios } = context;

    const serverVersion = command.endsWith('v2') ? 'v2' : command.endsWith('v3') ? 'v3' : command.endsWith('v4') ? 'v4' : 'v1';
    const panelConfig = getPanelConfig(serverVersion);
    const hasPanelAccess = checkUserRole(xy.from.id, ['owner'], serverVersion);
    const domainDisplay = hasPanelAccess ? panelConfig.panelDomain : '***Domain disembunyikan***';

    if (!panelConfig.panelDomain || !panelConfig.pltaKey) {
        return reply(`<blockquote>❌ Konfigurasi <b>Server ${serverVersion.toUpperCase()}</b> tidak ditemukan.</blockquote>`, { parse_mode: 'HTML' });
    }

    const sentMessage = await reply(`<blockquote>⏳ <b>Menghitung total server di Panel ${serverVersion.toUpperCase()}...</b></blockquote>`, { parse_mode: 'HTML' });

    (async () => {
        let currentServerCount = 0; let page = 1; let hasMore = true;
        try {
            while (hasMore) {
                const response = await axios.get(`${panelConfig.panelDomain}/api/application/servers?page=${page}`, {
                    headers: { 'Authorization': `Bearer ${panelConfig.pltaKey}` }
                });
                const result = response.data;
                currentServerCount += result.data.length;
                hasMore = result.meta.pagination.current_page < result.meta.pagination.total_pages;
                page++;
            }
            const summary = `📜 <b>Total Server Panel ${serverVersion.toUpperCase()}</b>\n\n🌐 <b>Domain:</b> ${domainDisplay}\n📊 <b>Total Server:</b> <code>${currentServerCount} Server</code>`;
            await editReply(xy, sentMessage.message_id, `<blockquote>${summary}</blockquote>`);
        } catch (err) {
            await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal mengambil total server ${serverVersion.toUpperCase()}.</blockquote>`);
        }
    })();
};

// --- CEK SERVER (UP/DOWN) ---
const handleCekServer = async (context) => {
    const { xy, reply, editReply, axios } = context; 


    const sentMessage = await reply(`<blockquote>⏳ <b>Mengecek Server V1-V4...</b></blockquote>`, { parse_mode: 'HTML' });
    (async () => {
        const servers = ['v1', 'v2', 'v3', 'v4'];
        let serverStatuses = [];
        for (const version of servers) {
            const panelConfig = getPanelConfig(version);
            const serverName = `SERVER ${version.slice(1)}`;
            if (!panelConfig.panelDomain || !panelConfig.pltaKey) {
                serverStatuses.push(`${serverName} OFF❌ (Konfigurasi hilang)`);
                continue;
            }
            try {
                const response = await axios.get(`${panelConfig.panelDomain}/api/application/servers?per_page=1`, {
                    headers: { 'Authorization': `Bearer ${panelConfig.pltaKey}` },
                    timeout: 5000
                });
                if (response.status === 200) {
                    serverStatuses.push(`${serverName} ON✅`);
                } else {
                    serverStatuses.push(`${serverName} OFF❌ (Status: ${response.status})`);
                }
            } catch (err) {
                let errorDetail = (err.response?.status === 403 || err.response?.status === 404) ? 'Key/URL Salah' : 'Timeout/Error';
                serverStatuses.push(`${serverName} OFF❌ (${errorDetail})`);
            }
        }
        const message = `🤖 <b>SERVER YANG ON</b>\n━━━━━━━━━━━━━━━━━\n${serverStatuses.join('\n')}`;
        
        await editReply(xy, sentMessage.message_id, `<blockquote>${message}</blockquote>`);
    })();
};

// --- TO URL ---
const handleToUrl = async (context) => {
    const { xy, reply, prefix, command, editReply, botToken, fs, axios, path, CatBox } = context;

    if (!xy.message?.reply_to_message || (!xy.message.reply_to_message.photo && !xy.message.reply_to_message.video)) {
        return reply(`<blockquote>📌 <b>Reply gambar/video dengan caption</b> <code>${prefix + command}</code></blockquote>`, { parse_mode: "HTML" });
    }
    const sentMessage = await reply(`<blockquote>⏳ <b>Sedang mengunggah file ke URL...</b></blockquote>`, { parse_mode: 'HTML' });

    (async () => {
        const fileId = xy.message.reply_to_message.photo ?
            xy.message.reply_to_message.photo.at(-1).file_id :
            xy.message.reply_to_message.video.file_id;
        try {
            const file = await xy.api.getFile(fileId);
            if (!file.file_path) throw new Error('Gagal mengambil file path');
            const fileUrl = `https://api.telegram.org/file/bot${botToken}/${file.file_path}`;
            
            const tempDir = path.resolve(__dirname);
            const filePath = path.join(tempDir, path.basename(file.file_path)); 
            
            const response = await axios({ url: fileUrl, responseType: 'stream' });
            const writer = fs.createWriteStream(filePath);
            response.data.pipe(writer);
            await new Promise((resolve, reject) => { writer.on('finish', resolve); writer.on('error', reject); });
            
            const uploaded = await CatBox(filePath);
            await editReply(xy, sentMessage.message_id, `<blockquote>✅ <b>Berhasil diunggah!</b>\n🔗 <b>URL:</b> ${uploaded}</blockquote>`);
            fs.unlinkSync(filePath);
        } catch (err) {
            console.error("ToUrl Error:", err);
            await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal mengambil/mengunggah file.</blockquote>`);
        }
    })();
};

// --- STICKER ---
const handleSticker = async (context) => {
    const { xy, reply, prefix, command, editReply, botToken, fs, axios, exec, InputFile } = context;

    if (!xy.message.reply_to_message || (!xy.message.reply_to_message.photo && !xy.message.reply_to_message.video)) {
        return reply(`<blockquote>📌 <b>Reply gambar/video dengan</b> <code>${prefix + command}</code></blockquote>`, { parse_mode: 'HTML' });
    }
    const sentMessage = await reply(`<blockquote>⏳ <b>Sedang membuat stiker...</b></blockquote>`, { parse_mode: 'HTML' });

    (async () => {
        let fileId, isVideo = false;
        if (xy.message.reply_to_message.photo) {
            fileId = xy.message.reply_to_message.photo.at(-1).file_id;
        } else if (xy.message.reply_to_message.video) {
            fileId = xy.message.reply_to_message.video.file_id;
            isVideo = true;
        }
        try {
            const file = await xy.api.getFile(fileId);
            const filePath = `https://api.telegram.org/file/bot${botToken}/${file.file_path}`;
            const inputPath = `./temp_input${isVideo ? ".mp4" : ".jpg"}`;
            const outputPath = `./temp_output.${isVideo ? "webm" : "webp"}`;
            const response = await axios.get(filePath, { responseType: "arraybuffer" });
            fs.writeFileSync(inputPath, response.data);

            const ffmpegCommand = `ffmpeg -i "${inputPath}" -vf "scale=512:512:force_original_aspect_ratio=decrease" -c:v ${isVideo ? 'libvpx-vp9 -b:v 500k -an' : ''} "${outputPath}"`;
            exec(ffmpegCommand, async (err) => {
                fs.unlinkSync(inputPath);
                if (err) return editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal mengonversi ke stiker.</blockquote>`);
                try {
                    const stickerBuffer = fs.readFileSync(outputPath);
                    await xy.api.sendSticker(xy.chat.id, new InputFile(stickerBuffer, outputPath));
                    await editReply(xy, sentMessage.message_id, `<blockquote>✅ Stiker berhasil dibuat!</blockquote>`);
                } catch (sendErr) {
                    await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal mengirim stiker.</blockquote>`);
                }
                fs.unlinkSync(outputPath);
            });
        } catch (err) {
            await editReply(xy, sentMessage.message_id, `<blockquote>❌ Terjadi kesalahan.</blockquote>`);
        }
    })();
};

// --- TO IMG ---
const handleToImg = async (context) => {
    const { xy, reply, prefix, command, editReply, botToken, fs, axios, exec, InputFile } = context;

    if (!xy.message.reply_to_message || !xy.message.reply_to_message.sticker) {
        return reply(`<blockquote>📌 <b>Reply stiker dengan</b> <code>${prefix + command}</code></blockquote>`, { parse_mode: 'HTML' });
    }
    const sentMessage = await reply(`<blockquote>⏳ <b>Sedang mengonversi stiker ke gambar...</b></blockquote>`, { parse_mode: 'HTML' });

    (async () => {
        const fileId = xy.message.reply_to_message.sticker.file_id;
        try {
            const file = await xy.api.getFile(fileId);
            const fileUrl = `https://api.telegram.org/file/bot${botToken}/${file.file_path}`;
            const inputPath = `./temp_sticker.webp`;
            const outputPath = `./temp_image.png`;
            const response = await axios.get(fileUrl, { responseType: "arraybuffer" });
            fs.writeFileSync(inputPath, response.data);
            
            exec(`ffmpeg -i "${inputPath}" "${outputPath}"`, async (err) => {
                fs.unlinkSync(inputPath);
                if (err) return editReply(xy, sentMessage.message_id, "<blockquote>❌ Gagal mengonversi stiker.</blockquote>");
                try {
                    const imageBuffer = fs.readFileSync(outputPath);
                    await xy.api.sendPhoto(xy.chat.id, new InputFile(imageBuffer, outputPath), { caption: "<blockquote>✅ <b>Berhasil dikonversi!</b></blockquote>", parse_mode: 'HTML' });
                    await editReply(xy, sentMessage.message_id, `<blockquote>✅ Proses konversi selesai.</blockquote>`);
                } catch (sendErr) {
                    await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal mengirim gambar.</blockquote>`);
                }
                fs.unlinkSync(outputPath);
            });
        } catch (err) {
            await editReply(xy, sentMessage.message_id, "<blockquote>❌ Terjadi kesalahan.</blockquote>");
        }
    })();
};

// --- TO VIDEO ---
const handleToVideo = async (context) => {
    const { xy, reply, prefix, command, editReply, botToken, fs, axios, exec, InputFile } = context;

    if (!xy.message.reply_to_message || !xy.message.reply_to_message.sticker) {
        return reply(`<blockquote>📌 <b>Reply stiker dengan</b> <code>${prefix + command}</code></blockquote>`, { parse_mode: 'HTML' });
    }
    const sentMessage = await reply(`<blockquote>⏳ <b>Sedang mengonversi stiker ke video...</b></blockquote>`, { parse_mode: 'HTML' });

    (async () => {
        const sticker = xy.message.reply_to_message.sticker;
        const ext = sticker.is_video ? ".webm" : ".webp";
        const inputPath = `./sticker${ext}`;
        const outputPath = `./video.mp4`;
        try {
            const file = await xy.api.getFile(sticker.file_id);
            const fileUrl = `https://api.telegram.org/file/bot${botToken}/${file.file_path}`;
            const response = await axios.get(fileUrl, { responseType: "arraybuffer" });
            fs.writeFileSync(inputPath, response.data);

            exec(`ffmpeg -i "${inputPath}" -movflags faststart -pix_fmt yuv420p -vf "scale=512:512:force_original_aspect_ratio=decrease" "${outputPath}"`, async (err) => {
                fs.unlinkSync(inputPath);
                if (err) return editReply(xy, sentMessage.message_id, "<blockquote>❌ Gagal mengonversi stiker.</blockquote>");
                try {
                    const videoBuffer = fs.readFileSync(outputPath);
                    await xy.api.sendVideo(xy.chat.id, new InputFile(videoBuffer, "video.mp4"), { caption: "<blockquote>✅ <b>Berhasil dikonversi!</b></blockquote>", parse_mode: 'HTML' });
                    await editReply(xy, sentMessage.message_id, `<blockquote>✅ Proses konversi selesai.</blockquote>`);
                } catch (sendErr) {
                    await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal mengirim video.</blockquote>`);
                }
                fs.unlinkSync(outputPath);
            });
        } catch (err) {
            await editReply(xy, sentMessage.message_id, "<blockquote>❌ Terjadi kesalahan.</blockquote>");
        }
    })();
};

// --- QC (QUOTED IMAGE) ---
const handleQc = async (context) => {
    const { xy, reply, text, isOwner, mess, editReply, botToken, fs, axios, exec, InputFile, Buffer } = context;

    if (!isOwner) return reply(mess.owner);
    const teks = xy.message.reply_to_message?.text || text;
    if (!teks) return reply("<blockquote>Cara penggunaan: /qc teks (atau reply pesan)</blockquote>", { parse_mode: 'HTML' });

    const sentMessage = await reply(`<blockquote>⏳ <b>Sedang membuat Quoted Image (QC)...</b></blockquote>`, { parse_mode: 'HTML' });

    (async () => {
        const targetUser = xy.message.reply_to_message?.from || xy.from;
        let avatarUrl = "https://i0.wp.com/telegra.ph/file/134ccbbd0dfc434a910ab.png"; // Default avatar
        try {
            const photos = await xy.api.getUserProfilePhotos(targetUser.id);
            if (photos.total_count > 0) {
                const file = await xy.api.getFile(photos.photos[0][0].file_id);
                if (file?.file_path) avatarUrl = `https://api.telegram.org/file/bot${botToken}/${file.file_path}`;
            }
        } catch (e) { /* Abaikan jika gagal ambil foto */ }

        try {
            const payload = { type: "quote", format: "png", backgroundColor: "#FFFFFF", width: 700, height: 580, scale: 2,
                messages: [{ entities: [], avatar: true, from: { id: 1, name: targetUser.first_name, photo: { url: avatarUrl } }, text: teks, replyMessage: {} }]
            };
            const { data } = await axios.post("https://bot.lyo.su/quote/generate", payload, { headers: { "Content-Type": "application/json" } });
            
            const pngBuffer = Buffer.from(data.result.image, "base64");
            const inputPath = './qc_input.png';
            const outputPath = './qc_output.webp';
            fs.writeFileSync(inputPath, pngBuffer);

            exec(`ffmpeg -y -i "${inputPath}" -vf "scale=512:-1" -vcodec libwebp -lossless 1 "${outputPath}"`, async (err) => {
                fs.unlinkSync(inputPath);
                if (err) return editReply(xy, sentMessage.message_id, "<blockquote>❌ Gagal konversi QC.</blockquote>");
                try {
                    const stickerBuffer = fs.readFileSync(outputPath);
                    await xy.api.sendSticker(xy.chat.id, new InputFile(stickerBuffer, outputPath));
                    await editReply(xy, sentMessage.message_id, `<blockquote>✅ QC berhasil dibuat!</blockquote>`);
                } catch (sendErr) {
                    await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal mengirim stiker QC.</blockquote>`);
                }
                fs.unlinkSync(outputPath);
            });
        } catch (err) {
            await editReply(xy, sentMessage.message_id, "<blockquote>❌ Gagal membuat QC.</blockquote>");
        }
    })();
};

// --- BRAT (STICKER MAKER) ---
const handleBrat = async (context) => {

    const { xy, reply, text, isOwner, mess, editReply, fs, axios, InputFile } = context;
    if (!text) return reply("<blockquote>Cara penggunaan: /brat [teks]</blockquote>", { parse_mode: 'HTML' });

    const sentMessage = await reply(`<blockquote>⏳ <b>Sedang membuat stiker Brat...</b></blockquote>`, { parse_mode: 'HTML' });

    (async () => {
        try {
            const url = `https://api.hanggts.xyz/imagecreator/brat?text=${encodeURIComponent(text)}`;
            const filepath = './tmp_brat.png';
            const response = await axios.get(url, { responseType: 'arraybuffer' });
            fs.writeFileSync(filepath, response.data);
            await xy.api.sendSticker(xy.chat.id, new InputFile(filepath));
            fs.unlinkSync(filepath);
            await editReply(xy, sentMessage.message_id, `<blockquote>✅ Stiker Brat berhasil dibuat.</blockquote>`);
        } catch (err) {
            await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal membuat stiker Brat.</blockquote>`);
        }
    })();
};


module.exports = {
    'cekid': handleCekId,
    'info': handleInfo,
    'totalserver': handleTotalServer,
    'totalserverv2': handleTotalServer,
    'totalserverv3': handleTotalServer,
    'totalserverv4': handleTotalServer,
    'cekserver': handleCekServer,
    'tourl': handleToUrl,
    'sticker': handleSticker,
    'toimg': handleToImg,
    'toimage': handleToImg,
    'tovideo': handleToVideo,
    'qc': handleQc,
    'brat': handleBrat,
};


