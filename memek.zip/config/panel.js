// config/panel.js
// Berisi semua logika untuk perintah yang terkait dengan Pterodactyl Panel

const fs = require('fs');
const axios = require('axios');
const path = require('path');
const { InlineKeyboard } = require("grammy"); // Diperlukan untuk pagination

// Impor helpers yang berisi fungsi-fungsi umum
const {
    getPanelConfig,
    editReply,
    checkUserRole,
    readJson,
    writeJson,
    getServerStatus, 
    CPU_CHECK_STATUS_FILE 
} = require('./helpers.js');

// --- FUNGSI HELPER UNTUK PESAN GAGAL KIRIM ---
/**
 * Membuat pesan notifikasi jika pengiriman detail panel/admin panel gagal.
 * @param {string} targetNumber - ID/Nomor tujuan pengiriman.
 * @param {string} sendType - Tipe pengiriman ('sendtele' atau 'sendwa').
 * @returns {string} Pesan dalam format HTML/blockquote.
 */
const failedDeliveryMessage = (targetNumber, sendType) => {
    const platform = (sendType === 'sendwa') ? 'WhatsApp' : 'Telegram';
    return `
<blockquote>
⚠️ <b>GAGAL KIRIM DETAIL PANEL</b>
━━━━━━━━━━━━━━━━━━━━━━━
Gagal mengirimkan detail panel/admin panel kepada <b>${platform} ID</b>: <code>${targetNumber}</code>.

<b>Penyebab Umum:</b>
1. User belum pernah <i>start</i> bot (untuk Telegram).
2. User telah memblokir bot (<i>blocked bot</i>).
3. ID tujuan salah (bukan ID ${platform}).

<b>Tindak Lanjut:</b>
Pastikan sudah chat bot terlebih dahulu atau cek dengan /info
</blockquote>`;
};

// --- FUNGSI UNTUK MEMBUAT SERVER (1GB, 2GB, ... UNLI) ---
const handleCreatePanel = async (context) => {
    const { xy, reply, text, command, prefix, mess, checkUserRole, sessions, editReply, InputFile, CatBox } = context;

    if (xy.chat.type === 'private') {
        return reply(mess.group);
    }

    const serverVersion = command.match(/v\d/)?.[0] || 'v1';
    const userId = xy.from.id;

    // Pengecekan role
    if (!checkUserRole(userId, ['owner', 'seller', 'partner', 'reseller'], serverVersion)) {
        return reply(mess.seller);
    }

    const sentMessage = await reply(`<blockquote>⏳ <b>Sedang membuat Panel ${command.toUpperCase()}...</b></blockquote>`, {
        parse_mode: 'HTML'
    });

    (async () => {
        const userInput = text;
        const commandType = command.replace(serverVersion, '');
        const panelConfig = getPanelConfig(serverVersion);
        const { panelDomain, pltaKey, pltcKey, nests, eggs, loc } = panelConfig;

        if (!panelDomain || !pltaKey || !pltcKey || !nests || !eggs || !loc) {
            return editReply(xy, sentMessage.message_id, `<blockquote>❌ Konfigurasi Server ${serverVersion.toUpperCase()} tidak lengkap (domain/api key/nest/egg/loc).</blockquote>`);
        }

        let ram, disk, cpu;
        switch (commandType) {
            case "1gb": ram = "1024"; disk = "1024"; cpu = "40"; break;
            case "2gb": ram = "2048"; disk = "2048"; cpu = "60"; break;
            case "3gb": ram = "3072"; disk = "3072"; cpu = "80"; break;
            case "4gb": ram = "4096"; disk = "4096"; cpu = "100"; break;
            case "5gb": ram = "5120"; disk = "5120"; cpu = "120"; break;
            case "6gb": ram = "6144"; disk = "6144"; cpu = "140"; break;
            case "7gb": ram = "7168"; disk = "7168"; cpu = "160"; break;
            case "8gb": ram = "8192"; disk = "8192"; cpu = "180"; break;
            case "9gb": ram = "9216"; disk = "9216"; cpu = "200"; break;
            case "10gb": ram = "10240"; disk = "10240"; cpu = "220"; break;
            case "unli": ram = "0"; disk = "0"; cpu = "0"; break;
            default:
                return editReply(xy, sentMessage.message_id, "<blockquote>Perintah tidak valid.</blockquote>");
        }

        let t = userInput.split(",");
        if (t.length < 3) {
            return editReply(xy, sentMessage.message_id, `<blockquote><b>Format salah!</b>\n\nPenggunaan:\n${prefix + command} sendwa/sendtele,username,nowa/idtele</blockquote>`);
        }

        let [sendType, username, targetNumberRaw] = t.map(a => a.trim());
        const targetNumber = targetNumberRaw.replace(/\D/g, "");

        if (!["sendwa", "sendtele"].includes(sendType)) {
            return editReply(xy, sentMessage.message_id, "<blockquote>Pilihan pengiriman hanya boleh 'sendwa' atau 'sendtele'.</blockquote>");
        }
        if (!targetNumber.match(/^\d+$/)) {
            return editReply(xy, sentMessage.message_id, `<blockquote>ID tele / No. WA tujuan tidak valid.</blockquote>`);
        }

        let email = `${username}@jhonaley.net`;
        let password = Math.random().toString(36).slice(-8);
        let user;
        let server;

        try {
            // 1. Cek User
            try {
                const checkResponse = await fetch(`${panelDomain}/api/application/users/email/${email}`, {
                    method: "GET",
                    headers: { Accept: "application/json", Authorization: `Bearer ${pltaKey}` }
                });
                if (checkResponse.ok) throw new Error("Email atau Username sudah digunakan!");
                if (checkResponse.status !== 404) throw new Error(`API Check Error: Status ${checkResponse.status}`);
            } catch (error) {
                if (error.message !== "Email atau Username sudah digunakan!") throw error;
                else throw new Error("Email atau Username sudah digunakan!");
            }

            // 2. Buat User
            let f = await fetch(`${panelDomain}/api/application/users`, {
                method: "POST",
                headers: { Accept: "application/json", "Content-Type": "application/json", Authorization: `Bearer ${pltaKey}` },
                body: JSON.stringify({ email: email, username: username, first_name: username, last_name: username, language: "en", password: password.toString() })
            });
            let userData = await f.json();
            if (userData.errors) throw new Error(`API Error (User): ${userData.errors[0].detail}`);
            user = userData.attributes; 

            // 3. Ambil Info Egg
            let f2 = await fetch(`${panelDomain}/api/application/nests/${nests}/eggs/${eggs}`, {
                method: "GET",
                headers: { Accept: "application/json", "Content-Type": "application/json", Authorization: `Bearer ${pltcKey}` }
            });
            let data2 = await f2.json();
            let startup_cmd = data2.attributes.startup;

            // 4. Buat Server
            let f3 = await fetch(`${panelDomain}/api/application/servers`, {
                method: "POST",
                headers: { Accept: "application/json", "Content-Type": "application/json", Authorization: `Bearer ${pltcKey}` },
                body: JSON.stringify({
                    name: username,
                    description: "panel pterodactyl",
                    user: user.id, 
                    egg: parseInt(eggs),
                    docker_image: "ghcr.io/parkervcp/yolks:nodejs_23", 
                    startup: startup_cmd,
                    environment: { INST: "npm", USER_UPLOAD: "0", AUTO_UPDATE: "0", CMD_RUN: "npm start", STARTUP_CMD: "pip install -r requirements.txt" },
                    limits: { memory: ram, swap: 0, disk: disk, io: 500, cpu: cpu },
                    feature_limits: { databases: 5, backups: 5, allocations: 5 },
                    deploy: { locations: [parseInt(loc)], dedicated_ip: false, port_range: [] }
                })
            });
            let res = await f3.json();
            if (res.errors) throw new Error(`API Error (Server): ${res.errors[0].detail}`);
            server = res.attributes;

            // 5. Kirim Pesan
            
            let messageToTelegram = `🎉 <b>Panel Berhasil Dibuat!</b>\n\nBerikut adalah detail akun Anda:\n\n<pre>SERVER ${serverVersion.toUpperCase()}</pre>\n\n• <b>Email:</b> ${email}\n• <b>Username:</b> <code>${user.username}</code>\n• <b>Password:</b> <code>${password.toString()}</code>\n• <b>Link Panel:</b> <a href="${panelDomain}">Klik untuk login</a>\n\n• <b>RAM:</b> ${ram} MB\n• <b>DISK:</b> ${disk} MB\n• <b>CPU:</b> ${cpu}%\n\n• <b>Server ID:</b> <code>${server.id}</code>\n• <b>User ID:</b> <code>${user.id}</code>\n\n<pre>NOTE: Silakan login dan ganti password Anda demi keamanan. Jangan berikan detail akun ini kepada siapa pun!</pre>`;
            
            let messageToWa = `🎉 *Panel Berhasil Dibuat!* 🎉\n\nBerikut adalah detail akun Anda:\n\n*SERVER ${serverVersion.toUpperCase()}*\n\n• *Link Panel:* ${panelDomain}\n• *Email:* ${email}\n• *Username:* ${user.username}\n• *Password:* ${password.toString()}\n\n• *RAM:* ${ram} MB\n• *DISK:* ${disk} MB\n• *CPU:* ${cpu}%\n\n• *Server ID:* ${server.id}\n• *User ID:* ${user.id}\n\n*NOTE: Silakan login dan ganti password Anda demi keamanan. Jangan berikan detail akun ini kepada siapa pun!*`;
  

            const detailImageUrl = global.panelDetailImage || "https://files.catbox.moe/ufov2b.jpg";
            let deliverySuccess = true;

            try {
                if (sendType === "sendtele") {
                    await xy.api.sendPhoto(targetNumber, detailImageUrl, {
                        caption: messageToTelegram,
                        parse_mode: 'HTML'
                    });
                } else if (sendType === "sendwa") {
                    const sessionNumber = Array.from(sessions.keys())[0];
                    const waClient = sessions.get(sessionNumber);
                    if (!waClient) throw new Error(`Sesi WhatsApp ${sessionNumber} tidak ditemukan.`);
                    const custwa = targetNumber.includes("@") ? targetNumber : `${targetNumber}@s.whatsapp.net`;
                    
                    await waClient.sendMessage(custwa, {
                        image: { url: detailImageUrl },
                        caption: messageToWa
                    });
                }
            } catch (deliveryError) {
                console.error(`❌ Gagal mengirim pesan ke ${sendType} ${targetNumber}:`, deliveryError.message);
                deliverySuccess = false;

            }


            let platform = (sendType === 'sendwa') ? 'WhatsApp' : 'Telegram';
            let specString;
            if (commandType === 'unli') {
                specString = "<b>Spek:</b> Unli RAM, Unli DISK, Unli CPU";
            } else {
                specString = `<b>Spek:</b> ${ram}MB RAM, ${disk}MB DISK, ${cpu}% CPU`;
            }

            if (deliverySuccess) {
                let messageToSender = `✅ Panel untuk username <b>${username}</b> telah berhasil dibuat dan data telah dikirim ke <b>${platform} ${targetNumber}</b>.\n\n${specString}\n<b>ID Server:</b> <code>${server.id}</code>`;
                await editReply(xy, sentMessage.message_id, `<blockquote>${messageToSender}</blockquote>`);
            } else {

                const failureNotif = failedDeliveryMessage(targetNumber, sendType);
                const messageToSender = `⚠️ Panel untuk username <b>${username}</b> berhasil dibuat, namun <b>GAGAL</b> dikirim ke <b>${platform} ${targetNumber}</b>.\n\n${specString}\n<b>ID Server:</b> <code>${server.id}</code>`;
                await editReply(xy, sentMessage.message_id, `<blockquote>${messageToSender}</blockquote>`);
                await xy.reply(failureNotif, { parse_mode: 'HTML' }); // Kirim notifikasi lengkap sebagai pesan baru
            }

        } catch (error) {
            console.error("❌ Panel Creation Error:", error.message);
            let errorMessage = error.message;


            if (errorMessage.includes("The email has already been taken.")) {
                errorMessage = "Email sudah digunakan. Silakan gunakan username/email lain.";
            } else if (errorMessage.includes("The username has already been taken.")) {
                errorMessage = "Username sudah digunakan. Silakan gunakan username/email lain.";
            } else if (errorMessage.includes("API Error (User): The email field is required.")) {
                 errorMessage = "Data email tidak ditemukan. Pastikan format input benar.";
            }


            await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal membuat Panel: ${errorMessage}</blockquote>`);
        }
    })();
};

// --- FUNGSI UNTUK MEMBUAT ADMIN PANEL (CADP) ---
const handleCreateAdminPanel = async (context) => {
    const { xy, reply, text, command, prefix, mess, checkUserRole, sessions, editReply } = context;

    if (xy.chat.type === 'private') {
        return reply(mess.group);
    }

    const serverVersion = command.endsWith('v2') ? 'v2' : command.endsWith('v3') ? 'v3' : command.endsWith('v4') ? 'v4' : 'v1';
    const userId = xy.from.id;

    // Pengecekan role (Hanya Owner/Partner)
    if (!checkUserRole(userId, ['owner', 'partner'], serverVersion)) {
        return reply(mess.owner);
    }

    const panelConfig = getPanelConfig(serverVersion);
    if (!text || text.split(",").length < 3) return reply(`<blockquote><b>Format salah!</b>\n\nPenggunaan:\n${prefix + command} sendwa/sendtele,nama,nomor_telepon</blockquote>`, { parse_mode: 'HTML' });

    const sentMessage = await reply(`<blockquote>⏳ <b>Sedang membuat Admin Panel...</b></blockquote>`, { parse_mode: 'HTML' });

    (async () => {
        const [sendType, username, targetNumberRaw] = text.split(",").map(a => a.trim());
        const targetNumber = targetNumberRaw.replace(/[^0-9]/g, "");
        const { panelDomain, pltaKey } = panelConfig;
        
        if (!panelDomain || !pltaKey) {
             return editReply(xy, sentMessage.message_id, `<blockquote>❌ Konfigurasi Server ${serverVersion.toUpperCase()} tidak lengkap.</blockquote>`);
        }

        if (!["sendwa", "sendtele"].includes(sendType)) {
            return editReply(xy, sentMessage.message_id, "<blockquote>Pilihan pengiriman hanya boleh 'sendwa' atau 'sendtele'.</blockquote>");
        }

        let password = Math.random().toString(36).slice(-8);
        let email = username + "@jhonaley.net";
        let user;

        try {
            // 1. Cek User
            try {
                const checkResponse = await fetch(`${panelDomain}/api/application/users/email/${email}`, {
                    method: "GET", headers: { Accept: "application/json", Authorization: `Bearer ${pltaKey}` }
                });
                if (checkResponse.ok) throw new Error("Email atau Username sudah digunakan!");
                if (checkResponse.status !== 404) throw new Error(`API Check Error: Status ${checkResponse.status}`);
            } catch (error) {
                if (error.message !== "Email atau Username sudah digunakan!") throw error;
                else throw new Error("Email atau Username sudah digunakan!");
            }

            // 2. Buat User Admin
            let f = await fetch(`${panelDomain}/api/application/users`, {
                method: "POST",
                headers: { Accept: "application/json", "Content-Type": "application/json", Authorization: `Bearer ${pltaKey}` },
                body: JSON.stringify({
                    email: email, username: username, first_name: username, last_name: username, language: "en",
                    root_admin: true, // <-- Ini yang membedakan
                    password: password.toString()
                })
            });
            let data = await f.json();
            if (data.errors) throw new Error(`API Error: ${data.errors[0].detail}`);
            user = data.attributes;

            // 3. Kirim Pesan
            let messageToTargetTele = `✓ <b>Admin Panel Berhasil Dibuat</b>\n\n- <b>ID:</b> <code>${user.id}</code>\n- <b>EMAIL:</b> ${user.email}\n- <b>USERNAME:</b> ${user.username}\n- <b>PASSWORD:</b> <code>${password.toString()}</code>\n- <b>LOGIN:</b> <a href="${panelDomain}">Klik untuk login</a>\n\n<pre>⚠️ Simpan informasi ini...</pre>`;
            let messageToTargetWa = `✓ *Admin Panel Berhasil Dibuat*\n\n- *ID:* ${user.id}\n- *EMAIL:* ${user.email}\n- *USERNAME:* ${user.username}\n- *PASSWORD:* ${password.toString()}\n- *LOGIN:* ${panelDomain}\n\n*⚠️ Simpan informasi ini...*`;
            
            const detailImageUrl = global.panelDetailImage || "https://files.catbox.moe/ufov2b.jpg";
            let deliverySuccess = true;

            try {
                if (sendType === "sendtele") {
                    await xy.api.sendPhoto(targetNumber, detailImageUrl, {
                        caption: messageToTargetTele,
                        parse_mode: 'HTML' 
                    });
                } else if (sendType === "sendwa") {
                    const sessionNumber = Array.from(sessions.keys())[0];
                    const waClient = sessions.get(sessionNumber);
                    if (!waClient) throw new Error(`Sesi WhatsApp ${sessionNumber} tidak ditemukan.`);
                    const custwa = targetNumber.includes("@") ? targetNumber : `${targetNumber}@s.whatsapp.net`;
                    
                    await waClient.sendMessage(custwa, {
                        image: { url: detailImageUrl },
                        caption: messageToTargetWa
                    });
                }
            } catch (deliveryError) {
                console.error(`❌ Gagal mengirim pesan ke ${sendType} ${targetNumber}:`, deliveryError.message);
                deliverySuccess = false;
                // Lanjutkan proses, tapi pesan ke pengirim akan berbeda
            }
 
            let platform = (sendType === 'sendwa') ? 'WhatsApp' : 'Telegram';
            
            if (deliverySuccess) {
                let messageToSender = `✅ Admin Panel <b>${username}</b> telah berhasil dibuat dan data telah dikirim ke <b>${platform} ${targetNumber}</b>.\n\n<b>ID Admin:</b> <code>${user.id}</code>`;
                await editReply(xy, sentMessage.message_id, `<blockquote>${messageToSender}</blockquote>`);
            } else {
                // Gunakan notifikasi gagal kirim yang baru
                const failureNotif = failedDeliveryMessage(targetNumber, sendType);
                const messageToSender = `⚠️ Admin Panel <b>${username}</b> berhasil dibuat, namun <b>GAGAL</b> dikirim ke <b>${platform} ${targetNumber}</b>.\n\n<b>ID Admin:</b> <code>${user.id}</code>`;
                await editReply(xy, sentMessage.message_id, `<blockquote>${messageToSender}</blockquote>`);
                await xy.reply(failureNotif, { parse_mode: 'HTML' }); // Kirim notifikasi lengkap sebagai pesan baru
            }

        } catch (error) {
            console.error("❌ CADP Error:", error.message);
            let errorMessage = error.message;
            
            // --- Penterjemahan Pesan Error ---
            if (errorMessage.includes("The email has already been taken.")) {
                errorMessage = "Email sudah digunakan. Silakan gunakan username/email lain.";
            } else if (errorMessage.includes("The username has already been taken.")) {
                errorMessage = "Username sudah digunakan. Silakan gunakan username/email lain.";
            } else if (errorMessage.includes("API Error: The email field is required.")) {
                 errorMessage = "Data email tidak ditemukan. Pastikan format input benar.";
            }
            // --- Akhir Penterjemahan Pesan Error ---

            await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal membuat Admin Panel: ${errorMessage}</blockquote>`);
        }
    })();
};

// --- FUNGSI UNTUK LIST (SERVER, USER, ADMIN) ---
const handleList = async (context) => {
    const { xy, reply, text, command, mess, checkUserRole, editReply, InlineKeyboard } = context;

    const serverVersion = command.endsWith('v2') ? 'v2' : command.endsWith('v3') ? 'v3' : command.endsWith('v4') ? 'v4' : 'v1';
    const userId = xy.from.id;

    if (!checkUserRole(userId, ['owner', 'partner'], serverVersion)) {
        return reply(mess.owner);
    }

    const panelConfig = getPanelConfig(serverVersion);
    if (!panelConfig.panelDomain || !panelConfig.pltaKey) return reply("<blockquote>❌ Konfigurasi server tidak ditemukan.</blockquote>", { parse_mode: 'HTML' });

    const pageText = text || '1';
    let halaman = parseInt(pageText) || 1;

    const sentMessage = await reply(`<blockquote>⏳ <b>Sedang mengambil daftar ${command.includes('srv') ? 'Server' : 'User/Admin'} (Halaman ${halaman})...</b></blockquote>`, { parse_mode: 'HTML' });

    (async () => {
        try {
            const isServerList = command.includes('srv');
            const isAdminList = command.includes('admin');
            const endpoint = isServerList ? 'servers' : 'users';

            let response = await fetch(`${panelConfig.panelDomain}/api/application/${endpoint}?page=${halaman}&per_page=25`, {
                method: "GET", headers: { Accept: "application/json", "Content-Type": "application/json", Authorization: `Bearer ${panelConfig.pltaKey}` }
            });

            let hasil = await response.json();
            if (!response.ok) throw new Error(`Kode error: ${response.status}`);
            if (hasil.errors) throw new Error(`Kesalahan: ${hasil.errors[0].detail}`);
            if (!hasil.data || hasil.data.length === 0) return editReply(xy, sentMessage.message_id, "<blockquote>📌 Tidak ada data yang terdaftar.</blockquote>");

            let filteredData = hasil.data;
            let title = isServerList ? 'Daftar Server' : 'Daftar Pengguna';

            if (isAdminList) {
                filteredData = hasil.data.filter(user => user.attributes.root_admin === true);
                title = 'Daftar Administrator';
            }

            if (filteredData.length === 0) return editReply(xy, sentMessage.message_id, `<blockquote>🚫 Tidak ada ${isAdminList ? 'admin' : 'data'} di halaman ini.</blockquote>`);

            let daftar = `📡 <b>${title} (${serverVersion})</b> 📡\n`;
            daftar += `<b>URL Panel:</b> ${panelConfig.panelDomain}\n`;
            daftar += "━━━━━━━━━━━━━━━━━━━━━━━\n";

            for (let item of filteredData) {
                let info = item.attributes;
                daftar += `<b>${isServerList ? 'Server ID' : 'User ID'}</b>: <code>${info.id}</code>\n`;
                daftar += `<b>Nama</b>: ${info.name || info.username}\n`;
                daftar += "───────────────────────\n";
            }

            const { total_pages, current_page, total } = hasil.meta.pagination;
            daftar += `📄 <b>Halaman</b>: ${current_page}/${total_pages}\n`;
            daftar += `📊 <b>Total Keseluruhan</b>: ${total}`;

            let buttons = new InlineKeyboard();
            if (current_page > 1) buttons.text("⬅️ Sebelumnya", `${command} ${current_page - 1}`);
            if (current_page < total_pages) buttons.text("Berikutnya ➡️", `${command} ${current_page + 1}`);

            await xy.api.editMessageText(xy.chat.id, sentMessage.message_id, `<blockquote>${daftar}</blockquote>`, {
                parse_mode: "HTML", reply_markup: buttons.row(),
            });

        } catch (err) {
            await editReply(xy, sentMessage.message_id, `<blockquote>⚠️ Terjadi kesalahan: ${err.message}</blockquote>`);
        }
    })();
};

// --- FUNGSI UNTUK HAPUS (SERVER, USER, ADMIN) ---
const handleDelete = async (context) => {
    const { xy, reply, text, command, prefix, mess, isOwner, editReply } = context;

    if (!isOwner) return reply(mess.owner);

    const serverVersion = command.endsWith('v2') ? 'v2' : command.endsWith('v3') ? 'v3' : command.endsWith('v4') ? 'v4' : 'v1';
    const panelConfig = getPanelConfig(serverVersion);
    const targetType = command.includes('srv') ? 'server' : 'user'; // 'user' mencakup admin

    if (!text || !/^\d+$/.test(text)) {
        return reply(`<blockquote><b>Format salah!</b>\n\nContoh: <code>${prefix + command} 1</code></blockquote>`, { parse_mode: 'HTML' });
    }

    let targetId = text;
    const sentMessage = await reply(`<blockquote>⏳ <b>Sedang menghapus ${targetType} ID ${targetId}...</b></blockquote>`, { parse_mode: 'HTML' });

    (async () => {
        try {
            if (!panelConfig.panelDomain || !panelConfig.pltaKey) throw new Error("Konfigurasi server tidak ditemukan.");
            
            let f = await fetch(`${panelConfig.panelDomain}/api/application/${targetType}s/${targetId}`, {
                method: "DELETE", headers: { Accept: "application/json", "Content-Type": "application/json", Authorization: `Bearer ${panelConfig.pltaKey}` }
            });

            if (f.status === 204) {
                await editReply(xy, sentMessage.message_id, `<blockquote>✅ ${targetType} ID ${targetId} berhasil dihapus.</blockquote>`);
            } else {
                let data = await f.json();
                throw new Error(`Gagal: ${data.errors[0].detail}`);
            }
        } catch (err) {
            await editReply(xy, sentMessage.message_id, `<blockquote>❌ Terjadi kesalahan: ${err.message}</blockquote>`);
        }
    })();
};

// --- FUNGSI HAPUS SEMUA SERVER (DELALLPANEL) ---
const handleDeleteAllServers = async (context) => {
    const { xy, reply, text, command, prefix, mess, isOwner, editReply, axios } = context;
    
    if (!isOwner) return reply(mess.owner);
    const serverVersion = command.endsWith('v2') ? 'v2' : command.endsWith('v3') ? 'v3' : command.endsWith('v4') ? 'v4' : 'v1';
    const targetType = 'servers';
    const excludedIdsRaw = text.trim();

    if (!excludedIdsRaw) return reply(`<blockquote>❌ Format salah!\nContoh: <code>${prefix + command} 1,2,3</code> (ID dikecualikan)</blockquote>`, { parse_mode: 'HTML' });
    
    const excludedIds = excludedIdsRaw.split(',').map(id => id.trim()).filter(id => /^\d+$/.test(id)).map(id => String(id));
    if (excludedIds.length === 0) return reply(`<blockquote>❌ ID dikecualikan tidak valid.</blockquote>`, { parse_mode: 'HTML' });
    
    const panelConfig = getPanelConfig(serverVersion);
    if (!panelConfig.panelDomain || !panelConfig.pltaKey) return reply("<blockquote>❌ Konfigurasi server tidak ditemukan.</blockquote>", { parse_mode: 'HTML' });
    
    const excludedIdsList = excludedIds.join(', ');
    const sentMessage = await reply(`<blockquote>⏳ Mengambil daftar semua server (${serverVersion})...\nID dikecualikan: ${excludedIdsList}</blockquote>`, { parse_mode: 'HTML' });

    (async () => {
        try {
            let allItems = []; let page = 1; let hasMore = true;
            while (hasMore) {
                const response = await axios.get(`${panelConfig.panelDomain}/api/application/${targetType}?page=${page}`, { headers: { 'Authorization': `Bearer ${panelConfig.pltaKey}` } });
                allItems = allItems.concat(response.data.data);
                hasMore = response.data.meta.pagination.current_page < response.data.meta.pagination.total_pages;
                page++;
            }

            let serversToDelete = allItems.filter(item => !excludedIds.includes(String(item.attributes.id)));
            const totalToDelete = serversToDelete.length;
            if (totalToDelete === 0) return editReply(xy, sentMessage.message_id, `<blockquote>✅ Tidak ada server yang perlu dihapus.</blockquote>`);

            let deletedCount = 0; let failedCount = 0; const itemsPerChunk = 45;
            const totalChunks = Math.ceil(totalToDelete / itemsPerChunk);
            
            for (let i = 0; i < totalChunks; i++) {
                const serversChunk = serversToDelete.slice(i * itemsPerChunk, (i + 1) * itemsPerChunk);
                let summary = `🗑️ <b>Proses Hapus Server Panel (${serverVersion.toUpperCase()})</b> [${i + 1}/${totalChunks}]\n`;
                let currentChunkDeleted = 0; let currentChunkFailed = 0;

                for (const srv of serversChunk) {
                    try {
                        await axios.delete(`${panelConfig.panelDomain}/api/application/${targetType}/${srv.attributes.id}`, { headers: { 'Authorization': `Bearer ${panelConfig.pltaKey}` } });
                        summary += `✅ Hapus: <b>${srv.attributes.name}</b> (ID: <code>${srv.attributes.id}</code>)\n`;
                        currentChunkDeleted++;
                    } catch (err) {
                        summary += `❌ Gagal: <b>${srv.attributes.name}</b> (ID: <code>${srv.attributes.id}</code>)\n`;
                        currentChunkFailed++;
                    }
                }
                deletedCount += currentChunkDeleted; failedCount += currentChunkFailed;
                summary += `───────────────────────\n(Dihapus: ${currentChunkDeleted}, Gagal: ${currentChunkFailed})`;
                
                if (i === 0) await editReply(xy, sentMessage.message_id, `<blockquote>${summary}</blockquote>`, null);
                else await xy.reply(`<blockquote>${summary}</blockquote>`, { parse_mode: 'HTML' });
            }

            const finalMessage = `✅ <b>Selesai menghapus server di ${serverVersion}!</b>\n\nTotal Dihapus: <b>${deletedCount}</b>\nGagal Hapus: <b>${failedCount}</b>\nID Dikecualikan: <code>${excludedIdsList}</code>`;
            await xy.reply(`<blockquote>${finalMessage}</blockquote>`, { parse_mode: 'HTML' });

        } catch (err) {
            await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal mengambil daftar server: ${err.message}</blockquote>`);
        }
    })();
};

// --- FUNGSI HAPUS SEMUA ADMIN (DELALLADMIN) ---
const handleDeleteAllAdmins = async (context) => {
    const { xy, reply, text, command, prefix, mess, isOwner, editReply, axios } = context;
    
    if (!isOwner) return reply(mess.owner);
    const serverVersion = command.endsWith('v2') ? 'v2' : command.endsWith('v3') ? 'v3' : command.endsWith('v4') ? 'v4' : 'v1';
    const targetType = 'users';
    const excludedIdsRaw = text.trim();

    if (!excludedIdsRaw) return reply(`<blockquote>❌ Format salah!\nContoh: <code>${prefix + command} 1,2,3</code> (ID Admin dikecualikan)</blockquote>`, { parse_mode: 'HTML' });
    
    const excludedIds = excludedIdsRaw.split(',').map(id => id.trim()).filter(id => /^\d+$/.test(id)).map(id => String(id));
    if (excludedIds.length === 0) return reply(`<blockquote>❌ ID Admin dikecualikan tidak valid.</blockquote>`, { parse_mode: 'HTML' });

    const panelConfig = getPanelConfig(serverVersion);
    if (!panelConfig.panelDomain || !panelConfig.pltaKey) return reply("<blockquote>❌ Konfigurasi server tidak ditemukan.</blockquote>", { parse_mode: 'HTML' });
    
    const excludedIdsList = excludedIds.join(', ');
    const sentMessage = await reply(`<blockquote>⏳ Mengambil daftar Admin Panel (${serverVersion})...\nID dikecualikan: ${excludedIdsList}</blockquote>`, { parse_mode: 'HTML' });

    (async () => {
        try {
            let allItems = []; let page = 1; let hasMore = true;
            while (hasMore) {
                const response = await axios.get(`${panelConfig.panelDomain}/api/application/${targetType}?page=${page}&include=servers`, { headers: { 'Authorization': `Bearer ${panelConfig.pltaKey}` } });
                allItems = allItems.concat(response.data.data);
                hasMore = response.data.meta.pagination.current_page < response.data.meta.pagination.total_pages;
                page++;
            }

            let adminsToProcess = allItems.filter(item =>
                item.attributes.root_admin === true && !excludedIds.includes(String(item.attributes.id))
            );
            
            const totalToProcess = adminsToProcess.length;
            if (totalToProcess === 0) return editReply(xy, sentMessage.message_id, `<blockquote>✅ Tidak ada Admin Panel yang perlu dihapus.</blockquote>`);

            let deletedAdminCount = 0; let deletedServerCount = 0; let failedAdminCount = 0;
            const itemsPerChunk = 25;
            const totalChunks = Math.ceil(totalToProcess / itemsPerChunk);
            
            for (let i = 0; i < totalChunks; i++) {
                const adminsChunk = adminsToProcess.slice(i * itemsPerChunk, (i + 1) * itemsPerChunk);
                let summary = `👑 <b>Proses Hapus Admin (${serverVersion.toUpperCase()})</b> [${i + 1}/${totalChunks}]\n`;
                
                for (const admin of adminsChunk) {
                    let log = `\n👤 Admin: <b>${admin.attributes.username}</b> (ID: <code>${admin.attributes.id}</code>)\n`;
                    let serverDel = 0;
                    const servers = admin.attributes.relationships.servers.data;

                    if (servers.length > 0) {
                        for (const srv of servers) {
                            try {
                                await axios.delete(`${panelConfig.panelDomain}/api/application/servers/${srv.attributes.id}`, { headers: { 'Authorization': `Bearer ${panelConfig.pltaKey}` } });
                                log += `  ✅ Server ${srv.attributes.id} dihapus.\n`;
                                serverDel++;
                            } catch (err) { log += `  ❌ Gagal hapus Server ${srv.attributes.id}.\n`; }
                        }
                    } else { log += `  -> Tidak ada server terkait.\n`; }
                    
                    try {
                        await axios.delete(`${panelConfig.panelDomain}/api/application/${targetType}/${admin.attributes.id}`, { headers: { 'Authorization': `Bearer ${panelConfig.pltaKey}` } });
                        log += `  ✅ Admin berhasil dihapus!\n`;
                        deletedAdminCount++;
                        deletedServerCount += serverDel;
                    } catch (err) {
                        log += `  ❌ Gagal hapus Admin!\n`;
                        failedAdminCount++;
                    }
                    summary += log + "───────────────────────\n";
                }

                if (i === 0) await editReply(xy, sentMessage.message_id, `<blockquote>${summary}</blockquote>`, null);
                else await xy.reply(`<blockquote>${summary}</blockquote>`, { parse_mode: 'HTML' });
            }

            const finalMessage = `✅ <b>Selesai menghapus Admin Panel di ${serverVersion}!</b>\n\nTotal Admin Dihapus: <b>${deletedAdminCount}</b>\nTotal Server Terkait Dihapus: <b>${deletedServerCount}</b>\nGagal Hapus Admin: <b>${failedAdminCount}</b>\nID Dikecualikan: <code>${excludedIdsList}</code>`;
            await xy.reply(`<blockquote>${finalMessage}</blockquote>`, { parse_mode: 'HTML' });

        } catch (err) {
            await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal mengambil data: ${err.message}</blockquote>`);
        }
    })();
};

// --- FUNGSI HAPUS SEMUA USER (DELALLUSR) ---
const handleDeleteAllUsers = async (context) => {
    const { xy, reply, text, command, prefix, mess, isOwner, editReply, axios, getPanelConfig } = context;
    
    if (!isOwner) return reply(mess.owner);
    const serverVersion = command.endsWith('v2') ? 'v2' : command.endsWith('v3') ? 'v3' : command.endsWith('v4') ? 'v4' : 'v1';
    const targetType = 'users';
    const excludedIdsRaw = text.trim();

    if (!excludedIdsRaw) {
        return reply(`<blockquote>❌ Format salah!\n\nContoh: <code>${prefix + command} 1,2,3</code> (ID yang dikecualikan, dipisahkan koma)</blockquote>`, {
            parse_mode: 'HTML'
        });
    }
    
    const excludedIds = excludedIdsRaw
        .split(',')
        .map(id => id.trim())
        .filter(id => /^\d+$/.test(id))
        .map(id => String(id)); 
    if (excludedIds.length === 0) {
        return reply(`<blockquote>❌ ID yang dikecualikan tidak valid. Harap masukkan satu atau lebih ID user yang dipisahkan koma.</blockquote>`, {
            parse_mode: 'HTML'
        });
    }

    const panelConfig = getPanelConfig(serverVersion);
    if (!panelConfig.panelDomain || !panelConfig.pltaKey) return reply("<blockquote>❌ Konfigurasi server tidak ditemukan.</blockquote>", {
      parse_mode: 'HTML'
    });

    const excludedIdsList = excludedIds.join(', ');

    const sentMessage = await reply(`<blockquote>⏳ Mengambil daftar semua user di server ${serverVersion}...\n\nID yang dikecualikan: ${excludedIdsList}</blockquote>`, { 
      parse_mode: 'HTML'
    });

    (async () => {
      try {
          let allItems = [];
          let page = 1;
          let hasMore = true;

          // 1. Ambil Semua User (termasuk server yang mereka miliki)
          while (hasMore) {
              const response = await axios.get(`${panelConfig.panelDomain}/api/application/${targetType}?page=${page}&include=servers`, { 
                  headers: { 'Authorization': `Bearer ${panelConfig.pltaKey}` }
              });

              const result = response.data;
              allItems = allItems.concat(result.data);
              hasMore = result.meta.pagination.current_page < result.meta.pagination.total_pages;
              page++;
          }

          let usersToDelete = [];
          let skippedUserCount = 0;

          // Filter user yang boleh dihapus (tanpa server dan tidak dikecualikan)
          allItems.forEach(item => {
              const userIdToDelete = String(item.attributes.id);
              const userName = item.attributes.username;
              const serverCount = item.attributes.relationships.servers.data.length;

              if (excludedIds.includes(userIdToDelete)) return; 
              
              if (serverCount === 0) {
                  usersToDelete.push({ id: userIdToDelete, name: userName, servers: 0 });
              } else {
                  skippedUserCount++;
              }
          });
          
          const totalToDelete = usersToDelete.length;
          if (totalToDelete === 0) {
               return editReply(xy, sentMessage.message_id, `<blockquote>✅ Tidak ada user yang memenuhi kriteria penghapusan (tanpa server aktif & tidak dikecualikan).</blockquote>`);
          }


          let deletedCount = 0;
          let failedCount = 0;
          const itemsPerChunk = 45;
          let firstMessageId = sentMessage.message_id;
          
          // 2. Proses Penghapusan (Chunking)
          const totalChunks = Math.ceil(totalToDelete / itemsPerChunk);
          
          for (let i = 0; i < totalChunks; i++) {
              const startIndex = i * itemsPerChunk;
              const usersChunk = usersToDelete.slice(startIndex, startIndex + itemsPerChunk);
              
              let summary = `🗑️ <b>Proses Hapus User Panel (${serverVersion.toUpperCase()})</b> 🗑️\n`;
              summary += `[Bagian ${i + 1}/${totalChunks}]\n`;
              summary += `ID Dikecualikan: <code>${excludedIdsList}</code>\n`;
              summary += "━━━━━━━━━━━━━━━━━━━━━━━\n";

              let currentChunkDeleted = 0;
              let currentChunkFailed = 0;
              
              for (const usr of usersChunk) {
                  try {
                    await axios.delete(`${panelConfig.panelDomain}/api/application/${targetType}/${usr.id}`, {
                      headers: {
                        'Authorization': `Bearer ${panelConfig.pltaKey}`
                      }
                    });
                    summary += `✅ Hapus: <b>${usr.name}</b> (ID: <code>${usr.id}</code>)\n`;
                    currentChunkDeleted++;
                  } catch (err) {
                    // Penanganan error yang lebih informatif
                    const errorStatus = err.response ? err.response.status : 'Unknown';
                    summary += `❌ Gagal: <b>${usr.name}</b> (ID: <code>${usr.id}</code>). Status: ${errorStatus}\n`;
                    currentChunkFailed++;
                  }
              }
              
              deletedCount += currentChunkDeleted;
              failedCount += currentChunkFailed;
              summary += "───────────────────────\n";
              summary += `(Dihapus di chunk ini: ${currentChunkDeleted}, Gagal: ${currentChunkFailed})`;

              
              if (i === 0) {
                   await editReply(xy, firstMessageId, `<blockquote>${summary}</blockquote>`, null);
              } else {
                   await xy.reply(`<blockquote>${summary}</blockquote>`, { parse_mode: 'HTML' });
              }
          }


          // 3. Pesan Akhir Konfirmasi
          const finalMessage = `
✅ <b>Selesai menghapus User di server ${serverVersion}!</b>

Total User Diambil: <b>${allItems.length}</b>
Total User Dikecualikan: <b>${excludedIds.length}</b>
User Dilewati (Ada Server Aktif): <b>${skippedUserCount}</b>
Total User Dihapus: <b>${deletedCount}</b>
Total User Gagal Hapus: <b>${failedCount}</b>

ID yang Dikecualikan: <code>${excludedIdsList}</code>
`;

          await xy.reply(`<blockquote>${finalMessage}</blockquote>`, { parse_mode: 'HTML' });

      } catch (err) {
        console.error(`Error fetching ${targetType}:`, err);
        await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal mengambil daftar ${targetType}. Pastikan API key dan domain sudah benar. Error: ${err.message}</blockquote>`);
      }
    })();
};

// --- FUNGSI ON/OFF AUTOCPU ---
const handleAutoCpuToggle = async (context) => {
    const { reply, command, isOwner, mess, xy } = context;

    if (!isOwner) return reply(mess.owner);

    const serverVersion = command.endsWith('v2') ? 'v2' : command.endsWith('v3') ? 'v3' : command.endsWith('v4') ? 'v4' : 'v1';
    const action = command.includes('on');
    let statusData = readJson(CPU_CHECK_STATUS_FILE, {});

    if (!statusData[serverVersion]) {
        statusData[serverVersion] = { active: false, auto_stop: {}, chat_id: null };
    }

    if (action) {
        if (xy.chat.type === 'group' || xy.chat.type === 'supergroup') {
            statusData[serverVersion].chat_id = xy.chat.id;
        } else if (!statusData[serverVersion].chat_id) {
            return reply(`<blockquote>❌ Fitur Auto-Check CPU ${serverVersion.toUpperCase()} tidak dapat diaktifkan tanpa ID Grup.</blockquote>`, { parse_mode: 'HTML' });
        }
    } else {
        statusData[serverVersion].chat_id = null; // Hapus chat_id saat 'off'
    }

    statusData[serverVersion].active = action;
    writeJson(CPU_CHECK_STATUS_FILE, statusData);

    const statusText = action ? 'DIAKTIFKAN' : 'DINONAKTIFKAN';
    const emoji = action ? '✅' : '❌';
    const destinationText = action && statusData[serverVersion].chat_id ? `Notifikasi akan dikirim ke Grup ini.` : '';
    
    const info = `${emoji} Fitur Auto-Check CPU & Auto-Stop (Server ${serverVersion.toUpperCase()}) berhasil <b>${statusText}</b>!\n${destinationText}`;
    reply(`<blockquote>${info}</blockquote>`, { parse_mode: 'HTML' });
};

// --- FUNGSI CEK CPU MANUAL (SERVERCPU) ---
const handleServerCpuCheck = async (context) => {
    const { reply, text, editReply, axios } = context;

    const serverVersion = text || 'v1';
    const panelConfig = getPanelConfig(serverVersion);
    if (!panelConfig.panelDomain || !panelConfig.pltaKey || !panelConfig.pltcKey) {
        return reply(`<blockquote>❌ Konfigurasi server ${serverVersion} tidak ditemukan.</blockquote>`, { parse_mode: 'HTML' });
    }

    const sentMessage = await reply(`<blockquote>⏳ Memeriksa CPU server di panel <b>${serverVersion}</b>... (Batas Wajar: 80%)</blockquote>`, { parse_mode: 'HTML' });

    (async () => {
        try {
            let servers = []; let page = 1; let hasMore = true;
            while (hasMore) {
                const response = await axios.get(`${panelConfig.panelDomain}/api/application/servers?page=${page}`, { headers: { 'Authorization': `Bearer ${panelConfig.pltaKey}` } });
                servers = servers.concat(response.data.data);
                hasMore = response.data.meta.pagination.current_page < response.data.meta.pagination.total_pages;
                page++;
            }

            let abnormalCpuServers = [];
            for (const server of servers) {
                const { id: serverId, name: serverName, uuid: serverUuid } = server.attributes;
                try {
                    const resourceResponse = await axios.get(`${panelConfig.panelDomain}/api/client/servers/${serverUuid}/resources`, { headers: { 'Authorization': `Bearer ${panelConfig.pltcKey}` } });
                    const resources = resourceResponse.data.attributes.resources;
                    const cpuUsage = resources.cpu_absolute;
                    const cpuLimit = resources.cpu_limit;
                    const effectiveLimit = cpuLimit > 0 ? cpuLimit : 100;

                    if (cpuUsage > 80 && effectiveLimit <= 100 || (cpuLimit > 100 && cpuUsage > (cpuLimit * 0.8))) {
                        abnormalCpuServers.push({ id: serverId, name: serverName, usage: cpuUsage, limit: cpuLimit });
                    }
                } catch (error) {/* Abaikan server yang gagal dicek */}
            }

            if (abnormalCpuServers.length === 0) {
                return editReply(xy, sentMessage.message_id, `<blockquote>✅ Tidak ditemukan server CPU di atas batas wajar (80%) di panel <b>${serverVersion}</b>.</blockquote>`);
            }

            let message = `🚨 <b>Daftar Server CPU Tidak Wajar (${serverVersion})</b> 🚨\n\n`;
            abnormalCpuServers.forEach(srv => {
                message += `🆔 <b>ID</b>: <code>${srv.id}</code>\n`;
                message += `🔹 <b>Nama</b>: ${srv.name}\n`;
                message += `📈 <b>Penggunaan</b>: ${srv.usage.toFixed(2)}% dari ${srv.limit}% \n`;
                message += "───────────────────────\n";
            });
            message += `📊 <b>Total Server Tidak Wajar</b>: ${abnormalCpuServers.length}`;
            await editReply(xy, sentMessage.message_id, `<blockquote>${message}</blockquote>`);
        } catch (err) {
            await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal mengambil data server: ${err.message}</blockquote>`);
        }
    })();
};

// --- FUNGSI HAPUS SERVER OFFLINE (DELSRVOFF) ---
const handleDeleteSrvOff = async (context) => {
    const { xy, reply, command, mess, checkUserRole, editReply, axios, getServerStatus } = context;

    const serverVersion = command.endsWith('v2') ? 'v2' : command.endsWith('v3') ? 'v3' : command.endsWith('v4') ? 'v4' : 'v1';
    const userId = xy.from.id;
    
    if (!checkUserRole(userId, ['owner'], serverVersion)) return reply(mess.owner);

    const panelConfig = getPanelConfig(serverVersion);
    if (!panelConfig.panelDomain || !panelConfig.pltaKey || !panelConfig.pltcKey) return reply("<blockquote>❌ Konfigurasi server tidak ditemukan.</blockquote>", { parse_mode: 'HTML' });

    const sentMessage = await reply(`<blockquote>⏳ Mencari & menghapus server offline/stopped dari panel <b>${serverVersion.toUpperCase()}</b>...</blockquote>`, { parse_mode: 'HTML' });

    (async () => {
        try {
            let allServers = []; let hasMore = true; let page = 1;
            while (hasMore) {
                const response = await axios.get(`${panelConfig.panelDomain}/api/application/servers?page=${page}`, { headers: { 'Authorization': `Bearer ${panelConfig.pltaKey}` } });
                allServers = allServers.concat(response.data.data);
                hasMore = response.data.meta.pagination.current_page < response.data.meta.pagination.total_pages;
                page++;
            }

            let inactiveServers = [];
            for (const server of allServers) {
                const status = await getServerStatus(server.attributes.uuid, panelConfig);
                if (status === 'offline' || status === 'stopped') {
                    inactiveServers.push({ id: server.attributes.id, name: server.attributes.name });
                }
            }
            
            const totalServers = inactiveServers.length;
            if (totalServers === 0) return editReply(xy, sentMessage.message_id, `<blockquote>✅ Tidak ada server <b>Offline/Stopped</b> di server <b>${serverVersion.toUpperCase()}</b>.</blockquote>`);

            let deletedCount = 0; const itemsPerChunk = 50;
            const totalChunks = Math.ceil(totalServers / itemsPerChunk);
            
            for (let i = 0; i < totalChunks; i++) {
                const serversToProcess = inactiveServers.slice(i * itemsPerChunk, (i + 1) * itemsPerChunk);
                let summary = `⚠️ <b>Proses Hapus Server Offline (${serverVersion.toUpperCase()})</b> [${i + 1}/${totalChunks}]\n`;
                for (const srv of serversToProcess) {
                    try {
                        await axios.delete(`${panelConfig.panelDomain}/api/application/servers/${srv.id}`, { headers: { 'Authorization': `Bearer ${panelConfig.pltaKey}` } });
                        summary += `🗑️ Hapus: <b>${srv.name}</b> (ID: <code>${srv.id}</code>)\n`;
                        deletedCount++;
                    } catch (err) {
                        summary += `❌ Gagal: <b>${srv.name}</b> (ID: <code>${srv.id}</code>)\n`;
                    }
                }
                if (i === 0) await editReply(xy, sentMessage.message_id, `<blockquote>${summary}</blockquote>`, null);
                else await xy.reply(`<blockquote>${summary}</blockquote>`, { parse_mode: 'HTML' });
            }
            
            await xy.reply(`<blockquote>✅ Proses penghapusan selesai. Total <b>${deletedCount}</b> server dihapus.</blockquote>`, { parse_mode: 'HTML' });

        } catch (err) {
            await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal menjalankan proses: ${err.message}</blockquote>`);
        }
    })();
};

// --- FUNGSI LIST SERVER OFFLINE (LISTSRVOFF) ---
const handleListSrvOff = async (context) => {
    const { xy, reply, command, mess, checkUserRole, editReply, axios, getServerStatus, getPanelConfig } = context;

    const serverVersion = command.endsWith('v2') ? 'v2' : command.endsWith('v3') ? 'v3' : command.endsWith('v4') ? 'v4' : 'v1';
    const userId = xy.from.id;
    
    // 1. Pengecekan Akses: Owner, Partner, Reseller
    if (!checkUserRole(userId, ['owner', 'partner', 'reseller'], serverVersion)) { 
        return reply(mess.seller);
    }

    const panelConfig = getPanelConfig(serverVersion);
    if (!panelConfig.panelDomain || !panelConfig.pltaKey || !panelConfig.pltcKey) {
        return reply("<blockquote>❌ Konfigurasi server tidak ditemukan.</blockquote>", {
            parse_mode: 'HTML'
        });
    }

    // Ubah pesan awal untuk menunjukkan waktu tunggu yang lebih singkat (jika pengecekan status server cepat)
    // Jika tidak, pertahankan 'Tunggu 2 Menit' atau sesuaikan dengan estimasi waktu yang sebenarnya.
    const sentMessage = await reply(`<blockquote>⏳ Mencari semua server yang offline/stopped dari panel <b>${serverVersion.toUpperCase()}</b>... (Tunggu sebentar)</blockquote>`, {
        parse_mode: 'HTML'
    });

    (async () => {
        try {
            let allServers = [];
            let hasMore = true;
            let page = 1;

            // Mengambil semua server dari semua halaman API
            while (hasMore) {
                const response = await axios.get(`${panelConfig.panelDomain}/api/application/servers?page=${page}`, {
                    headers: {
                        'Authorization': `Bearer ${panelConfig.pltaKey}`
                    }
                });
                const result = response.data;
                if (result.errors) throw new Error(`Gagal mengambil daftar server: ${result.errors[0].detail}`);
                allServers = allServers.concat(result.data);
                hasMore = result.meta.pagination.current_page < result.meta.pagination.total_pages;
                page++;
            }

            let inactiveServers = [];

            // Memeriksa status setiap server
            for (const server of allServers) {
                const serverUuid = server.attributes.uuid;
                const serverName = server.attributes.name;
                const serverId = server.attributes.id;

                const status = await getServerStatus(serverUuid, panelConfig); 

                if (status === 'offline' || status === 'stopped') {
                    inactiveServers.push({
                        id: serverId,
                        name: serverName,
                        status: status,
                    });
                }
            }
            

            const itemsPerChunk = 50; 
            const totalServers = inactiveServers.length;
            
            if (totalServers === 0) {
                // Gunakan editReply untuk pesan pertama
                return editReply(xy, sentMessage.message_id, `<blockquote>✅ Tidak ada server yang <b>Offline/Stopped</b> di server <b>${serverVersion.toUpperCase()}</b>.</blockquote>`);
            }

            // Total chunk yang dibutuhkan
            const totalChunks = Math.ceil(totalServers / itemsPerChunk);
            let firstMessageId = sentMessage.message_id;

            for (let i = 0; i < totalChunks; i++) {
                const startIndex = i * itemsPerChunk;
                const endIndex = startIndex + itemsPerChunk;
                const serversToDisplay = inactiveServers.slice(startIndex, endIndex);

                // --- Membangun Pesan ---
                let summary = `⚠️ <b>Daftar Server Offline/Stopped (${serverVersion.toUpperCase()})</b> ⚠️\n`;
                summary += `[Bagian ${i + 1}/${totalChunks}]\n`;
                summary += `Total Server Offline: ${totalServers}\n`;
                summary += "━━━━━━━━━━━━━━━━━━━━━━━\n";

                // Iterasi item untuk chunk saat ini
                serversToDisplay.forEach(srv => { 
                    summary += `🆔 <b>ID</b>: <code>${srv.id}</code>\n`;
                    summary += `🔹 <b>Nama</b>: ${srv.name}\n`;
                    summary += `💤 <b>Status</b>: ${srv.status.toUpperCase()}\n`;
                    summary += "───────────────────────\n";
                });
                

                if (i === 0) {
                    // Edit pesan pertama
                    await editReply(xy, firstMessageId, `<blockquote>${summary}</blockquote>`, null);
                } else {
                    // Kirim pesan baru untuk chunk berikutnya
                    await xy.reply(`<blockquote>${summary}</blockquote>`, { parse_mode: 'HTML' });
                }
            }
            
            // Kirim pesan penutup jika ada lebih dari satu chunk
            if (totalChunks > 1) {
                await xy.reply(`<blockquote>✅ Selesai menampilkan semua ${totalServers} server offline/stopped dalam ${totalChunks} pesan.</blockquote>`, { parse_mode: 'HTML' });
            }


        } catch (err) {
            console.error("Error fetching servers for status check:", err);
            // Pastikan menggunakan editReply untuk pesan error pertama
            await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal mengambil status server: ${err.message}</blockquote>`);
        }
    })();
};


// --- EKSPOR SEMUA FUNGSI ---
module.exports = {
    // Helper function (tidak diekspor sebagai command)
    failedDeliveryMessage: failedDeliveryMessage, 
    
    // Pembuatan Panel
    '1gb': handleCreatePanel, '2gb': handleCreatePanel, '3gb': handleCreatePanel, '4gb': handleCreatePanel, '5gb': handleCreatePanel,
    '6gb': handleCreatePanel, '7gb': handleCreatePanel, '8gb': handleCreatePanel, '9gb': handleCreatePanel, '10gb': handleCreatePanel, 'unli': handleCreatePanel,
    '1gbv2': handleCreatePanel, '2gbv2': handleCreatePanel, '3gbv2': handleCreatePanel, '4gbv2': handleCreatePanel, '5gbv2': handleCreatePanel,
    '6gbv2': handleCreatePanel, '7gbv2': handleCreatePanel, '8gbv2': handleCreatePanel, '9gbv2': handleCreatePanel, '10gbv2': handleCreatePanel, 'unliv2': handleCreatePanel,
    '1gbv3': handleCreatePanel, '2gbv3': handleCreatePanel, '3gbv3': handleCreatePanel, '4gbv3': handleCreatePanel, '5gbv3': handleCreatePanel,
    '6gbv3': handleCreatePanel, '7gbv3': handleCreatePanel, '8gbv3': handleCreatePanel, '9gbv3': handleCreatePanel, '10gbv3': handleCreatePanel, 'unliv3': handleCreatePanel,
    '1gbv4': handleCreatePanel, '2gbv4': handleCreatePanel, '3gbv4': handleCreatePanel, '4gbv4': handleCreatePanel, '5gbv4': handleCreatePanel,
    '6gbv4': handleCreatePanel, '7gbv4': handleCreatePanel, '8gbv4': handleCreatePanel, '9gbv4': handleCreatePanel, '10gbv4': handleCreatePanel, 'unliv4': handleCreatePanel,

    // Pembuatan Admin Panel
    'cadp': handleCreateAdminPanel, 'cadpv2': handleCreateAdminPanel, 'cadpv3': handleCreateAdminPanel, 'cadpv4': handleCreateAdminPanel,

    // List
    'listsrv': handleList, 'listsrvv2': handleList, 'listsrvv3': handleList, 'listsrvv4': handleList,
    'listusr': handleList, 'listusrv2': handleList, 'listusrv3': handleList, 'listusrvv4': handleList,
    'listadmin': handleList, 'listadminv2': handleList, 'listadminv3': handleList, 'listadminv4': handleList,
    'listsrvoff': handleListSrvOff, 'listsrvoffv2': handleListSrvOff, 'listsrvoffv3': handleListSrvOff, 'listsrvoffv4': handleListSrvOff,

    // Hapus Satuan
    'delusr': handleDelete, 'delusrv2': handleDelete, 'delusrv3': handleDelete, 'delusrv4': handleDelete,
    'deladmin': handleDelete, 'deladminv2': handleDelete, 'deladminv3': handleDelete, 'deladminv4': handleDelete,
    'delsrv': handleDelete, 'delsrvv2': handleDelete, 'delsrvv3': handleDelete, 'delsrv4': handleDelete,
    'delsrvoff': handleDeleteSrvOff, 'delsrvoffv2': handleDeleteSrvOff, 'delsrvoffv3': handleDeleteSrvOff, 'delsrvoffv4': handleDeleteSrvOff,

    // Hapus Massal
    'delallpanel': handleDeleteAllServers, 'delallpanelv2': handleDeleteAllServers, 'delallpanelv3': handleDeleteAllServers, 'delallpanelv4': handleDeleteAllServers,
    'delalladmin': handleDeleteAllAdmins, 'delalladminv2': handleDeleteAllAdmins, 'delalladminv3': handleDeleteAllAdmins, 'delalladminv4': handleDeleteAllAdmins,
    'delallusr': handleDeleteAllUsers, 'delallusrv2': handleDeleteAllUsers, 'delallusrv3': handleDeleteAllUsers, 'delallusrv4': handleDeleteAllUsers,

    // CPU & Status
    'autocpuon': handleAutoCpuToggle, 'autocpuonv2': handleAutoCpuToggle, 'autocpuonv3': handleAutoCpuToggle, 'autocpuonv4': handleAutoCpuToggle,
    'autocpuoff': handleAutoCpuToggle, 'autocpuoffv2': handleAutoCpuToggle, 'autocpuoffv3': handleAutoCpuToggle, 'autocpuoffv4': handleAutoCpuToggle,
    'servercpu': handleServerCpuCheck,
};

