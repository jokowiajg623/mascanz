// config/wa.js
// Berisi semua logika untuk koneksi WhatsApp

const { startWhatsAppSession } = require("../src/lib/connectwa"); // Impor fungsi spesifik
const { editReply } = require('./helpers.js');

const handleConnect = async (context) => {
    const { xy, reply, text, isOwner, mess, sessions } = context;
    if (!isOwner) return reply(mess.owner);
    if (!text) return reply('<blockquote>Gunakan: <code>/connect nomor_telepon</code></blockquote>', { parse_mode: 'HTML' });
    const sentMessage = await reply(`<blockquote>🔄 <b>Memulai koneksi ke WhatsApp ${text}...</b></blockquote>`, { parse_mode: 'HTML' });
    (async () => {
        const number = text.trim();
        if (sessions.has(number)) {
            return editReply(xy, sentMessage.message_id, `<blockquote>❗ WhatsApp ${number} sudah terhubung.</blockquote>`);
        }
        try {
            // Panggil startWhatsAppSession dari lib connectwa
            await startWhatsAppSession(number, xy.chat.id, sentMessage.message_id);
            // Penanganan QR/sukses ada di dalam startWhatsAppSession
        } catch (e) {
            console.error("Gagal koneksi WhatsApp:", e);
            await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal menghubungkan WhatsApp ${number}: ${e.message}</blockquote>`);
        }
    })();
};

const handleDisconnect = async (context) => {
    const { xy, reply, text, isOwner, mess, sessions, editReply } = context;
    if (!isOwner) return reply(mess.owner);
    if (!text) return reply('<blockquote>Gunakan: <code>/disconnect nomor_telepon</code></blockquote>', { parse_mode: 'HTML' });
    const sentMessage = await reply(`<blockquote>⏳ <b>Mencoba memutus koneksi WhatsApp ${text}...</b></blockquote>`, { parse_mode: 'HTML' });
    (async () => {
        const number = text.trim();
        if (!sessions.has(number)) {
            return editReply(xy, sentMessage.message_id, `<blockquote>❌ Session WhatsApp ${number} tidak ditemukan.</blockquote>`);
        }
        try {
            const waClient = sessions.get(number);
            if (waClient && waClient.ws.readyState === waClient.ws.OPEN) {
                await waClient.logout();
            }
            sessions.delete(number);
            await editReply(xy, sentMessage.message_id, `<blockquote>✅ Session WhatsApp ${number} berhasil diputus.</blockquote>`);
        } catch (error) {
            console.error("Error disconnecting WhatsApp session:", error);
            sessions.delete(number);
            await editReply(xy, sentMessage.message_id, `<blockquote>⚠️ Session WhatsApp ${number} dihapus paksa.\nError: ${error.message}</blockquote>`);
        }
    })();
};

const handleSend = async (context) => {
    const { xy, reply, text, isOwner, mess, sessions, editReply } = context;
    if (!isOwner) return reply(mess.owner);
    if (text.length < 2) return reply('<blockquote>Gunakan: <code>/send nomor_tujuan, teks_pesan</code></blockquote>', { parse_mode: 'HTML' });
    const sentMessage = await reply(`<blockquote>⏳ <b>Mencoba mengirim pesan WhatsApp...</b></blockquote>`, { parse_mode: 'HTML' });
    (async () => {
        let [targetNumber, textMessage] = text.split(",").map(a => a.trim());
        targetNumber = targetNumber.replace(/\D/g, ''); 
        if (!targetNumber) return editReply(xy, sentMessage.message_id, '<blockquote>Nomor tujuan tidak valid.</blockquote>');
        if (!textMessage) return editReply(xy, sentMessage.message_id, '<blockquote>Pesan tidak boleh kosong.</blockquote>');
        if (sessions.size === 0) return editReply(xy, sentMessage.message_id, '<blockquote>Tidak ada sesi WhatsApp yang aktif.</blockquote>');

        const sessionNumber = Array.from(sessions.keys())[0];
        const waClient = sessions.get(sessionNumber);
        if (!waClient) return editReply(xy, sentMessage.message_id, `<blockquote>Sesi WhatsApp ${sessionNumber} tidak ditemukan.</blockquote>`);

        try {
            const jid = targetNumber.includes("@") ? targetNumber : `${targetNumber}@s.whatsapp.net`;
            await waClient.sendMessage(jid, { text: textMessage });
            await editReply(xy, sentMessage.message_id, `<blockquote>✅ Pesan berhasil dikirim ke ${targetNumber}</blockquote>`);
        } catch (error) {
            await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal mengirim pesan. Error: ${error.message}</blockquote>`);
        }
    })();
};

module.exports = {
    'connect': handleConnect,
    'disconnect': handleDisconnect,
    'send': handleSend,
};

