// config/group.js
// Berisi semua logika untuk manajemen grup Telegram

const { readJson, writeJson } = require('./helpers.js');

const WELEAVE_FILE = './src/database/weleave.json';
const ANTILINK_FILE = './src/database/antilink.json';


// --- Group Settings (Open/Close) ---
const handleOpenGroup = async (context) => {
    const { xy, reply, mess, isGroupAdmins, isBotGroupAdmins } = context;
    if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
    if (!isGroupAdmins) return reply(mess.admin);
    if (!isBotGroupAdmins) return reply(mess.botAdmin);

    try {
        await xy.api.setChatPermissions(xy.chat.id, {
            can_send_messages: true,
            can_send_audios: true,
            can_send_photos: true,
            can_send_videos: true,
            can_send_voice_notes: true,
            can_send_video_notes: true,
            can_send_stickers: true,
            can_send_animations: true,
            can_send_polls: true,
            can_send_other_messages: true,
            can_add_web_page_previews: true,
        });
        reply(`<blockquote>✅ Grup <b>${xy.chat.title}</b> berhasil <b>DIBUKA</b>!\n\nSemua anggota sekarang dapat mengirim pesan.</blockquote>`, { parse_mode: 'HTML' });
    } catch (e) {
        console.error("Error /open:", e);
        reply(`<blockquote>❌ Gagal membuka grup.\n\nPastikan bot memiliki hak admin untuk <b>mengubah izin grup</b>.</blockquote>`, { parse_mode: 'HTML' });
    }
};

const handleCloseGroup = async (context) => {
    const { xy, reply, mess, isGroupAdmins, isBotGroupAdmins } = context;
    if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
    if (!isGroupAdmins) return reply(mess.admin);
    if (!isBotGroupAdmins) return reply(mess.botAdmin);

    try {
        await xy.api.setChatPermissions(xy.chat.id, {
            can_send_messages: false,
        });
        reply(`<blockquote>🔒 Grup <b>${xy.chat.title}</b> berhasil <b>DITUTUP</b>!\n\nHanya admin yang dapat mengirim pesan.</blockquote>`, { parse_mode: 'HTML' });
    } catch (e) {
        console.error("Error /close:", e);
        reply(`<blockquote>❌ Gagal menutup grup.\n\nPastikan bot memiliki hak admin untuk <b>mengubah izin grup</b>.</blockquote>`, { parse_mode: 'HTML' });
    }
};

// --- Group Info (Title, Desk, Link) ---
const handleChangeTitle = async (context) => {
    const { xy, reply, mess, isGroupAdmins, isBotGroupAdmins, text, prefix, command } = context;
    if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
    if (!isGroupAdmins) return reply(mess.admin);
    if (!isBotGroupAdmins) return reply(mess.botAdmin);
    if (!text) return reply(`<blockquote>❌ Format salah! Gunakan: <code>${prefix + command} [Judul Baru]</code></blockquote>`, { parse_mode: 'HTML' });

    try {
        await xy.api.setChatTitle(xy.chat.id, text);
        reply(`<blockquote>✅ Nama grup berhasil diubah menjadi: <b>${text}</b></blockquote>`, { parse_mode: 'HTML' });
    } catch (e) {
        console.error("Error /changetitle:", e);
        reply(`<blockquote>❌ Gagal mengubah nama grup.\n\nPastikan bot memiliki hak admin untuk <b>mengubah judul</b>.</blockquote>`, { parse_mode: 'HTML' });
    }
};

const handleChangeDesk = async (context) => {
    const { xy, reply, mess, isGroupAdmins, isBotGroupAdmins, text } = context;
    if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
    if (!isGroupAdmins) return reply(mess.admin);
    if (!isBotGroupAdmins) return reply(mess.botAdmin);
    
    const newDescription = text.trim() || "Tidak ada deskripsi.";
    try {
        await xy.api.setChatDescription(xy.chat.id, newDescription);
        reply(`<blockquote>✅ Deskripsi grup berhasil diubah:\n\n<i>${newDescription}</i></blockquote>`, { parse_mode: 'HTML' });
    } catch (e) {
        console.error("Error /changedesk:", e);
        reply(`<blockquote>❌ Gagal mengubah deskripsi grup.\n\nPastikan bot memiliki hak admin untuk <b>mengubah deskripsi</b>.</blockquote>`, { parse_mode: 'HTML' });
    }
};

const handleLinkGroup = async (context) => {
    const { xy, reply, mess, isGroupAdmins, isBotGroupAdmins } = context;
    if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
    if (!isGroupAdmins) return reply(mess.admin);
    if (!isBotGroupAdmins) return reply(mess.botAdmin);

    try {
        const inviteLink = await xy.api.exportChatInviteLink(xy.chat.id);
        reply(`<blockquote>🔗 Link Undangan Grup <b>${xy.chat.title}</b>:\n\n${inviteLink}</blockquote>`, { parse_mode: 'HTML' });
    } catch (e) {
        console.error("Error /linkgroup:", e);
        reply(`<blockquote>❌ Gagal mendapatkan link grup. Pastikan bot memiliki hak admin untuk <b>mengundang pengguna</b>.</blockquote>`, { parse_mode: 'HTML' });
    }
};

// --- Message Management (Pin, Unpin, Delete) ---
const handlePinMessage = async (context) => {
    const { xy, reply, mess, isGroupAdmins, isBotGroupAdmins } = context;
    if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
    if (!isGroupAdmins) return reply(mess.admin);
    if (!isBotGroupAdmins) return reply(mess.botAdmin);
    if (!xy.message.reply_to_message) return reply('<blockquote>❌ Harap balas pesan yang ingin Anda <b>sematkan</b>.</blockquote>', { parse_mode: 'HTML' });

    try {
        const messageId = xy.message.reply_to_message.message_id;
        await xy.api.pinChatMessage(xy.chat.id, messageId, { disable_notification: true }); 
        reply(`<blockquote>📌 Pesan berhasil <b>disematkan</b>.</blockquote>`, { parse_mode: 'HTML' });
    } catch (e) {
        console.error("Error /pin:", e);
        reply(`<blockquote>❌ Gagal menyematkan pesan.\n\nPastikan bot memiliki hak admin untuk <b>menyematkan pesan</b>.</blockquote>`, { parse_mode: 'HTML' });
    }
};

const handleUnpinMessage = async (context) => {
    const { xy, reply, mess, isGroupAdmins, isBotGroupAdmins } = context;
    if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
    if (!isGroupAdmins) return reply(mess.admin);
    if (!isBotGroupAdmins) return reply(mess.botAdmin);

    try {
        if (xy.message.reply_to_message) {
            const messageId = xy.message.reply_to_message.message_id;
            await xy.api.unpinChatMessage(xy.chat.id, messageId);
            reply(`<blockquote>📌 Sematan pesan berhasil <b>dilepaskan</b>.</blockquote>`, { parse_mode: 'HTML' });
        } else {
            await xy.api.unpinAllChatMessages(xy.chat.id);
            reply(`<blockquote>📌 Semua pesan sematan berhasil <b>dilepaskan</b>.</blockquote>`, { parse_mode: 'HTML' });
        }
    } catch (e) {
        console.error("Error /unpin:", e);
        reply(`<blockquote>❌ Gagal melepaskan sematan pesan.\n\nPastikan bot memiliki hak admin untuk <b>menyematkan pesan</b>.</blockquote>`, { parse_mode: 'HTML' });
    }
};

const handleDeleteMessage = async (context) => {
    const { xy, reply, mess, isGroupAdmins, isBotGroupAdmins } = context;
    if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
    if (!isGroupAdmins) return reply(mess.admin);
    if (!isBotGroupAdmins) return reply(mess.botAdmin);
    if (!xy.message.reply_to_message) return reply('<blockquote>❌ Harap balas pesan yang ingin Anda <b>hapus</b>.</blockquote>', { parse_mode: 'HTML' });
    
    try {
        await xy.api.deleteMessage(xy.chat.id, xy.message.reply_to_message.message_id);
        await xy.api.deleteMessage(xy.chat.id, xy.message.message_id); // Hapus perintah user
    } catch (e) {
        console.error("Error /delete:", e);
        reply(`<blockquote>❌ Gagal menghapus pesan. Pastikan bot memiliki hak admin untuk <b>menghapus pesan</b>.</blockquote>`, { parse_mode: 'HTML' });
    }
};

// --- Member Management (Kick, Promote, Demote) ---
const handleAddKick = async (context) => {
    const { xy, reply, mess, isGroupAdmins, isBotGroupAdmins, command } = context;
    if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
    if (!isGroupAdmins) return reply(mess.admin);
    if (!isBotGroupAdmins) return reply(mess.botAdmin);

    const targetUser = xy.message.reply_to_message?.from;
    if (!targetUser) return reply(`<blockquote>❌ Harap balas pesan anggota yang ingin di${command}.</blockquote>`, { parse_mode: 'HTML' });

    try {
        if (command === 'add') {
            return reply(`<blockquote>Untuk menambahkan <b>${targetUser.first_name}</b>, kirim link undangan grup ini kepadanya.</blockquote>`, { parse_mode: 'HTML' });
        } else if (command === 'kick') {
            await xy.api.banChatMember(xy.chat.id, targetUser.id);
            reply(`<blockquote>✅ Anggota <b>${targetUser.first_name}</b> telah berhasil dikeluarkan dari grup.</blockquote>`, { parse_mode: 'HTML' });
        }
    } catch (e) {
        console.error(`Error /${command}:`, e);
        reply(`<blockquote>❌ Gagal menjalankan perintah /${command}. Pastikan bot memiliki hak admin yang sesuai.</blockquote>`, { parse_mode: 'HTML' });
    }
};

const handlePromoteDemote = async (context) => {
    const { xy, reply, mess, isGroupAdmins, isBotGroupAdmins, command } = context;
    if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
    if (!isGroupAdmins) return reply(mess.admin);
    if (!isBotGroupAdmins) return reply(mess.botAdmin);

    const targetUser = xy.message.reply_to_message?.from;
    if (!targetUser) return reply(`<blockquote>❌ Harap balas pesan anggota yang ingin di${command}.</blockquote>`, { parse_mode: 'HTML' });
    
    try {
        if (command === 'promote') {
            await xy.api.promoteChatMember(xy.chat.id, targetUser.id, {
                can_change_info: true,
                can_delete_messages: true,
                can_invite_users: true,
                can_restrict_members: true,
                can_pin_messages: true,
                can_manage_topics: true,
                can_manage_video_chats: true,
                can_promote_members: false 
            });
            reply(`<blockquote>✅ Anggota <b>${targetUser.first_name}</b> telah berhasil diangkat menjadi Admin.</blockquote>`, { parse_mode: 'HTML' });
        } else if (command === 'demote') {
            await xy.api.promoteChatMember(xy.chat.id, targetUser.id, {
                can_change_info: false,
                can_delete_messages: false,
                can_invite_users: false,
                can_restrict_members: false,
                can_pin_messages: false,
                can_manage_topics: false,
                can_manage_video_chats: false,
                can_promote_members: false
            });
            reply(`<blockquote>✅ Admin <b>${targetUser.first_name}</b> telah berhasil diturunkan pangkatnya.</blockquote>`, { parse_mode: 'HTML' });
        }
    } catch (e) {
        console.error(`Error /${command}:`, e);
        reply(`<blockquote>❌ Gagal menjalankan perintah /${command}. Pastikan bot memiliki hak admin yang lebih tinggi dari target.</blockquote>`, { parse_mode: 'HTML' });
    }
};

// --- Group Features (Welcome, Leave, Antilink) ---
const handleWelcomeLeave = async (context) => {
    const { xy, reply, mess, isGroupAdmins, text, command } = context;
    if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
    if (!isGroupAdmins) return reply(mess.admin);

    const groupID = xy.chat.id;
    let listData = readJson(WELEAVE_FILE, []);
    let foundIndex = listData.findIndex(item => item.id === groupID);
    const action = text.toLowerCase().trim();
    const statusKey = command === 'welcome' ? 'welcome' : 'leave';

    if (action === 'on') {
        if (foundIndex === -1) {
            listData.push({ id: groupID, welcome: command === 'welcome', leave: command === 'leave' });
        } else {
            listData[foundIndex][statusKey] = true;
        }
        writeJson(WELEAVE_FILE, listData);
        reply(`<blockquote>✅ Pesan ${statusKey} berhasil <b>DIAKTIFKAN</b> di grup ini.</blockquote>`, { parse_mode: 'HTML' });
    } else if (action === 'off') {
        if (foundIndex !== -1) {
            listData[foundIndex][statusKey] = false;
            writeJson(WELEAVE_FILE, listData);
        }
        reply(`<blockquote>❌ Pesan ${statusKey} berhasil <b>DINONAKTIFKAN</b> di grup ini.</blockquote>`, { parse_mode: 'HTML' });
    } else {
        reply(`<blockquote>📌 Penggunaan: <code>/${command} on</code> atau <code>/${command} off</code></blockquote>`, { parse_mode: 'HTML' });
    }
};

const handleAntilink = async (context) => {
    const { xy, reply, mess, isGroupAdmins, text, command } = context;
    if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
    if (!isGroupAdmins) return reply(mess.admin);

    const groupID = xy.chat.id;
    let listData = readJson(ANTILINK_FILE, []);
    let foundIndex = listData.findIndex(item => item.id === groupID);
    const action = text.toLowerCase().trim();

    if (action === 'on') {
        if (foundIndex === -1) {
            listData.push({ id: groupID, active: true });
        } else {
            listData[foundIndex].active = true;
        }
        writeJson(ANTILINK_FILE, listData);
        reply(`<blockquote>✅ Fitur Anti-Link berhasil <b>DIAKTIFKAN</b>. Bot akan menghapus pesan yang mengandung link (kecuali admin).</blockquote>`, { parse_mode: 'HTML' });
    } else if (action === 'off') {
        if (foundIndex !== -1) {
            listData[foundIndex].active = false;
            writeJson(ANTILINK_FILE, listData);
        }
        reply(`<blockquote>❌ Fitur Anti-Link berhasil <b>DINONAKTIFKAN</b>.</blockquote>`, { parse_mode: 'HTML' });
    } else {
        const status = foundIndex !== -1 && listData[foundIndex].active ? 'AKTIF' : 'NONAKTIF';
        reply(`<blockquote>⚙️ Status Anti-Link saat ini: <b>${status}</b>\n\n📌 Penggunaan: <code>/${command} on</code> atau <code>/${command} off</code></blockquote>`, { parse_mode: 'HTML' });
    }
};

// --- Warning System ---
const handleWarn = async (context) => {
    const { xy, reply, mess, isGroupAdmins, warnDB, saveWarnDB } = context;
    if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
    if (!isGroupAdmins) return reply(mess.admin);
    
    const targetUser = xy.message.reply_to_message?.from;
    if (!targetUser) return reply(`<blockquote>❌ Harap balas pesan anggota yang ingin diwarn.</blockquote>`, { parse_mode: 'HTML' });
    
    const targetId = String(targetUser.id);
    const groupID = String(xy.chat.id);
    const maxWarn = 3;

    let groupWarns = warnDB[groupID] || {};
    let userWarns = groupWarns[targetId] || 0;
    userWarns++;
    groupWarns[targetId] = userWarns;
    warnDB[groupID] = groupWarns;
    saveWarnDB(warnDB); // Panggil fungsi saveWarnDB dari context

    if (userWarns >= maxWarn) {
        try {
            await xy.api.banChatMember(xy.chat.id, targetUser.id);
            delete groupWarns[targetId];
            warnDB[groupID] = groupWarns;
            saveWarnDB(warnDB);
            reply(`<blockquote>⚠️ <b>PERINGATAN!</b> (${userWarns}/${maxWarn})\n\nAnggota <b>${targetUser.first_name}</b> telah mencapai batas peringatan dan dikeluarkan dari grup.</blockquote>`, { parse_mode: 'HTML' });
        } catch (e) {
            console.error("Error kick warn:", e);
            reply(`<blockquote>⚠️ <b>PERINGATAN!</b> (${userWarns}/${maxWarn})\n\nAnggota <b>${targetUser.first_name}</b> telah mencapai batas peringatan, namun gagal dikeluarkan.</blockquote>`, { parse_mode: 'HTML' });
        }
    } else {
        reply(`<blockquote>⚠️ <b>PERINGATAN!</b> (${userWarns}/${maxWarn})\n\nAnggota <b>${targetUser.first_name}</b> menerima peringatan. Jika mencapai ${maxWarn} kali, dia akan dikeluarkan.</blockquote>`, { parse_mode: 'HTML' });
    }
};

const handleWarns = async (context) => {
    const { xy, reply, mess, warnDB } = context;
    if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
    
    const targetUser = xy.message.reply_to_message?.from || xy.from;
    const targetId = String(targetUser.id);
    const groupID = String(xy.chat.id);
    const maxWarn = 3;

    const groupWarns = warnDB[groupID] || {};
    const userWarns = groupWarns[targetId] || 0;
    
    reply(`<blockquote>👤 <b>${targetUser.first_name}</b>\n\nTotal Peringatan: <b>${userWarns}/${maxWarn}</b></blockquote>`, { parse_mode: 'HTML' });
};

const handleResetWarn = async (context) => {
    const { xy, reply, mess, isGroupAdmins, warnDB, saveWarnDB } = context;
    if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
    if (!isGroupAdmins) return reply(mess.admin);

    const targetUser = xy.message.reply_to_message?.from;
    if (!targetUser) return reply(`<blockquote>❌ Harap balas pesan anggota untuk me-reset peringatannya.</blockquote>`, { parse_mode: 'HTML' });

    const targetId = String(targetUser.id);
    const groupID = String(xy.chat.id);

    let groupWarns = warnDB[groupID] || {};
    if (groupWarns[targetId]) {
        delete groupWarns[targetId];
        warnDB[groupID] = groupWarns;
        saveWarnDB(warnDB);
        reply(`<blockquote>✅ Peringatan anggota <b>${targetUser.first_name}</b> telah di-reset (0/3).</blockquote>`, { parse_mode: 'HTML' });
    } else {
        reply(`<blockquote>⚠️ Anggota <b>${targetUser.first_name}</b> tidak memiliki peringatan untuk di-reset.</blockquote>`, { parse_mode: 'HTML' });
    }
};

// --- WIP/Not Implemented ---
const handleNotImplemented = async (context) => {
    const { reply, command } = context;
    reply(`<blockquote>Fitur <b>/${command}</b> (Grup) memerlukan integrasi API atau proses yang lebih kompleks dan masih dalam tahap pengembangan.</blockquote>`, { parse_mode: 'HTML' });
};


// Ekspor semua fungsi
module.exports = {
    // Settings
    'open': handleOpenGroup,
    'close': handleCloseGroup,
    'changetitle': handleChangeTitle,
    'changedesk': handleChangeDesk,
    'linkgroup': handleLinkGroup,
    // Messages
    'pin': handlePinMessage,
    'unpin': handleUnpinMessage,
    'delete': handleDeleteMessage,
    // Members
    'add': handleAddKick,
    'kick': handleAddKick,
    'promote': handlePromoteDemote,
    'demote': handlePromoteDemote,
    // Features
    'welcome': handleWelcomeLeave,
    'leave': handleWelcomeLeave,
    'antilink': handleAntilink,
    // Warning System
    'warn': handleWarn,
    'warns': handleWarns,
    'resetwarn': handleResetWarn,
    // WIP
    'createpolling': handleNotImplemented,
    'groupstats': handleNotImplemented,
};

