const fs = require('fs');
const axios = require('axios');
const path = require('path');
const { exec, spawn } = require("child_process");
const crypto = require('crypto');
const { createCanvas, loadImage } = require('canvas');
const { Client } = require('ssh2'); 
const {
  startWhatsAppSession,
  sessions,
  restoreWhatsAppSessions,
  updateActiveSessions
} = require("../src/lib/connectwa");
const {
  addResponList1,
  delResponList1,
  isAlreadyResponList1,
  isAlreadyResponList1Group,
  sendResponList1,
  updateResponList1,
  getDataResponList1
} = require('../src/lib/addlist'); 

// Impor semua helper
const helpers = require('./helpers.js');

// Impor SEMUA file command handler
const panelHandlers = require('./panel.js');
const ownerHandlers = require('./owner.js');
const installerHandlers = require('./installer.js');
const groupHandlers = require('./group.js');
const toolsHandlers = require('./tools.js');
const downloaderHandlers = require('./downloader.js');
const aiHandlers = require('./ai.js');
const storeHandlers = require('./store.js');
const waHandlers = require('./wa.js');
const systemHandlers = require('./system.js');
const miscHandlers = require('./misc.js');
const protectHandlers = require('./protect.js'); 

// Gabungkan semua command handlers menjadi SATU objek besar
const commandHandlers = {
  ...panelHandlers,
  ...ownerHandlers,
  ...installerHandlers,
  ...groupHandlers,
  ...toolsHandlers,
  ...downloaderHandlers,
  ...aiHandlers,
  ...storeHandlers,
  ...waHandlers,
  ...systemHandlers,
  ...miscHandlers,
  ...protectHandlers, 
};


async function handleMessage(
    xy, command, sleep, 
    isOwner, isSeller, isPartner, isReseller, 
    reply, owners, seller, sellerPath, 
    q, text, InlineKeyboard, paket, 
    isGroupAdmins, mess, 
    warnDB, saveWarnDB, pendingWarns, 
    InputFile, botToken, CatBox, 
    sender, db_respon_list, 
    generateReadableString, isBotGroupAdmins
) { 


  const runCommand = (cmd, sshInstance) => new Promise((resolve, reject) => {
      let output = '';
      sshInstance.exec(cmd, (err, stream) => {
          if (err) return reject(err);
          stream.on('close', (code) => {
              if (code !== 0) reject(new Error(`Command failed with code ${code}. Output: ${output.substring(0, 4000)}`));
              else resolve(output);
          }).on('data', (data) => { output += data.toString(); }).stderr.on('data', (data) => { output += data.toString(); });
      });
  });


  const context = {

    xy, command, sleep, isOwner, isSeller, isPartner, isReseller, reply, owners, seller, sellerPath, q, text, InlineKeyboard, paket, isGroupAdmins, mess, warnDB, saveWarnDB, pendingWarns, InputFile, botToken, CatBox, sender, db_respon_list, generateReadableString, isBotGroupAdmins,
    
    // Semua fungsi helper
    ...helpers,
    
    // Variabel/Fungsi Global & Lib
    prefix: global.prefix || "/",
    runCommand,
    sessions, 
    startWhatsAppSession,
    

    fs: require('fs'), 
    axios: require('axios'), 
    path: require('path'),
    exec: require('child_process').exec, 
    spawn: require('child_process').spawn,
    crypto: require('crypto'),
    createCanvas: require('canvas').createCanvas,
    loadImage: require('canvas').loadImage,
    Buffer: Buffer,
    InputFile: InputFile, 
    readJson: helpers.readJson,
    writeJson: helpers.writeJson,
  };

  // Cek handler dinamis
  if (commandHandlers[command]) {
    try {
      await commandHandlers[command](context);
    } catch (e) {
      console.error(`Error executing command ${command}:`, e);
      reply(`<blockquote>❌ Terjadi error internal saat menjalankan perintah ${command}.</blockquote>`, { parse_mode: 'HTML' });
    }
    return; 
  }


}


module.exports = {
  handleMessage
};

