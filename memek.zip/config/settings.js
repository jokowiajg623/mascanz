const fs = require('fs');

global.prefix = '/';

// Konfigurasi Bot
global.namabot = 'zayx Cpanel'
global.idowner = '7023596660'
global.apikeyhost = ``

// --- Konfigurasi Server 1 ---
global.domain = 'https://zayxofc.privatboy.biz.id' // Isi domain panel
global.plta = 'ptla_h8xhgH8FJdGp61ocQKETjnxmC8TmCHM2hj3U1xZ7WRk' // Isi API Key PLTA
global.pltc = 'ptlc_6BEzpAZXT4DVZC5yA5R2zW6Qwl9EWcVVoMqdbGRKeHZ' // Isi API Key PLTC
global.loc = '1' // Lokasi default
global.eggs = '15' // Egg default 
global.nests = '5' // Nests Default 

// --- Konfigurasi Server 2 ---
global.domainV2 = 'https://' 
global.pltaV2 = 'ptla_OLah09Xf8QI65Q9zyc4s3hkM71NMbOjEanGAZaelG5p' 
global.pltcV2 = 'ptlc_tHTF7RqzHeLmi0hmjZHD4mLRyFcA7C1EHuFGCskT0sU'
global.locV2 = '1' // Lokasi default Server 2
global.eggsV2 = '15' // Egg default Server 2
global.nestsV2 = '5' // Nests Default Server 2

// --- Konfigurasi Server 3 ---
global.domainV3 = 'https://' 
global.pltaV3 = 'ptla_tkzNt4ZmSfSceYwKxCnQDuJNtVazd2FBTVp8NNXS40t'
global.pltcV3 = 'ptlc_w2EtMl56eZm7Fv9jzoMPqposiyGrp5OSmxMt1LRBJzB'
global.locV3 = '1' 
global.eggsV3 = '15'
global.nestsV3 = '5'

// --- Konfigurasi Server 4 ---
global.domainV4 = 'https://' 
global.pltaV4 = ''
global.pltcV4 = 'ptlc_3hssvjUpmd4KY6MdSdXIp88lHyAjgRdMiDzBpCTzV7J'
global.locV4 = '1' 
global.eggsV4 = '15' 
global.nestsV4 = '5'


global.thumbnailPath = "https://files.catbox.moe/b3q17t.jpg"
global.paket = "https://files.catbox.moe/nbfba0.jpg"
global.startMenuPhoto = "https://files.catbox.moe/b3q17t.jpg" // Image /start 
global.panelDetailImage = "https://files.catbox.moe/ufov2b.jpg" // GAMBAR DETAIL PANEL

global.subdomain = { 
    "manzzkontolaktolakan.my.id": {
        zone: "34a42a0bcfecc5325ff121f1f03872ee",
        apitoken: 'sWUX4cUk2MGSPsoqAjiwptocx07PE9WB15DU8sj7',
    },
    "jhonaley.web.id": {
        zone: "dd00b76d94af1e8d5f37f4253f77861f",
        apitoken: 'MHXAKlSaWbFcCLDqo7t-A-KFx1N89vUOwjvSgVTt',
    },
    "jhonaleyhost.web.id": { 
        zone: "d2d72f4164b3e18c455dd2b0660d85a1",
        apitoken: 'J_Nb9wERFSu-Bqfvu6zOY8js9V4rKKcszZtsZJxm',
    },
    "naell.cloud": { 
        zone: "1b662cae2a8214a8468c97fb552070d0",
        apitoken: 'EX4ezkgaSvD3JeXeKoDQzfmqI_Mh0yUek7WmDO0u',
    },
    "privateeserverr.my.id": {
        zone: "2b47743c5a3afecde36ffa0f52073270",
        apitoken: '2ltJMUmL2QZ-H3IQ0NGM8n84zxoJlU1D8Wwj26AB',
    },
    "publicserverr.my.id": {
        zone: "b23d82b98aa932317c93571a3846240a",
        apitoken: '2ltJMUmL2QZ-H3IQ0NGM8n84zxoJlU1D8Wwj26AB',
    }, 
    "panelku-ptero.my.id": {
        zone: "ea719beeec3cfe39b58f0195f848498f",
        apitoken: 'Gb8j0xFasrWB1k80b4BFrIL_f2IgAQ5n66CamFbP',
    }, 
    "sainsproject.biz.id": {
        zone: "8211830a7911e9028f38018243ea360d",
        apitoken: 'XLllrPcIOIC-S4yQP2iaJ9GELQVrL5agcAtEyGXN',
    }, 
    "barmodsdomain.my.id": {
        zone: "05478e906fa1556f81ae0eaf86816060",
        apitoken: 'nkIplLsfGW-FSUYEpbSt3_I2-a9JIWZIvGO5W6xN',
    }, 
    "rikionline.shop": {
        zone: "082ec80d7367d6d4f7c52600034ac635",
        apitoken: 'r3XUyNYtxNQYwZtGUIAChRqe0uTzwV4eVO7JpJ_l',
    }
}; 

global.mess = {
    wait: "⏳ Sabar ya... lagi diproses, jangan ditinggal dulu!",
    success: "✅ Mantap! Permintaan kamu berhasil diproses.",
    on: "🟢 Oke! Fitur ini sekarang aktif, silakan gunakan.",
    off: "🔴 Sip! Fitur ini dimatikan sementara.",
    text: "✍️ Ups! Kamu belum kasih teks, coba isi dulu ya.",
    link: "🔗 Hmmm... link-nya mana? Kirim dulu yang valid ya.",
    fitur: "⚠️ Wah, fitur ini lagi error. Sabar dulu atau lapor ke owner ya!",
    seller: "🛒 Eits! Fitur ini khusus buat Seller & Owner aja ya.",
    atmin: "🛡️ Maaf, fitur ini hanya dapat digunakan oleh Admin atau Owner!",
    private: "📩 Fitur ini cuma bisa dipakai di chat pribadi, kirim lewat private dong!",
    owner: "👑 Waduh! Cuma yang punya bot alias owner yang bisa akses ini.",
    admin: "🛑 Fitur ini hanya bisa digunakan oleh admin grup!",
    group: "👥 Fitur ini hanya bisa digunakan dalam grup!"
};

