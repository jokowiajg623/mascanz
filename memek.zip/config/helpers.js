const fs = require('fs');
const axios = require('axios');

// Fungsi pembantu untuk membaca JSON
function readJson(filePath, defaultValue = []) {
    try {
        if (!fs.existsSync(filePath)) return defaultValue;
        const content = fs.readFileSync(filePath, 'utf8');
        return JSON.parse(content);
    } catch (e) {
        console.error(`Error reading ${filePath}:`, e);
        return defaultValue;
    }
}

// Fungsi pembantu untuk menulis JSON
function writeJson(filePath, data) {
    try {
        fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
        return true;
    } catch (e) {
        console.error(`Error writing to ${filePath}:`, e);
        return false;
    }
}

// Fungsi untuk mengirim pesan panjang dalam beberapa bagian
async function sendChunkedMessage(xy, text, messageIdToEdit = null) {
  const MAX_LENGTH = 4000; 
  let parts = [];
  let currentPart = '';

  const lines = text.split('\n');
  for (const line of lines) {
    if ((currentPart + line + '\n').length > MAX_LENGTH) {
      parts.push(currentPart);
      currentPart = line + '\n';
    } else {
      currentPart += line + '\n';
    }
  }
  if (currentPart.trim()) {
    parts.push(currentPart);
  }
  
  if (parts.length > 0) {
      if (messageIdToEdit) {
          try {
              await xy.api.editMessageText(xy.chat.id, messageIdToEdit, parts[0], { parse_mode: 'HTML' });
          } catch(e) {
               await xy.api.sendMessage(xy.chat.id, parts[0], { parse_mode: 'HTML' });
          }
      } else {
          await xy.api.sendMessage(xy.chat.id, parts[0], { parse_mode: 'HTML' });
      }
      
      for (let i = 1; i < parts.length; i++) {
          await xy.api.sendMessage(xy.chat.id, parts[i], { parse_mode: 'HTML' });
      }
  }
}

// Fungsi untuk mengedit balasan (dengan fallback kirim baru)
async function editReply(xy, messageId, text, replyMarkup = null) {
  const MAX_EDIT_LENGTH = 4096;
  if (text.length > MAX_EDIT_LENGTH) {
      console.warn(`Pesan terlalu panjang (${text.length} karakter). Mengirim pesan dalam chunks...`);
      await sendChunkedMessage(xy, text, messageId);
      
      if (replyMarkup) {
          await xy.api.sendMessage(xy.chat.id, 'Berikut tombol navigasinya:', { reply_markup: replyMarkup });
      }
      return; 
  }
  
  try {
    await xy.api.editMessageText(xy.chat.id, messageId, text, {
      parse_mode: 'HTML',
      reply_markup: replyMarkup
    });
  } catch (e) {
    console.error(`Gagal mengedit pesan ${messageId}:`, e.message);
    

    if (e.message.includes('message is not modified')) {
        return; 
    }
    
    // Fallback: kirim pesan baru jika edit gagal
    if (e.message) {
        await xy.api.sendMessage(xy.chat.id, text, {
          parse_mode: 'HTML',
          reply_markup: replyMarkup
        });
    }
  }
}

// Fungsi untuk mengecek role pengguna
function checkUserRole(userId, requiredRoles, serverVersion) {
  const ownerFile = './owner.json';
  const partnerFile = './src/database/partner.json';
  const resellerFile = './src/database/reseller.json';
  const sellerFile = './src/database/seller.json';

  let owners = readJson(ownerFile, []);
  let partners = readJson(partnerFile, []);
  let resellers = readJson(resellerFile, []);
  let sellers = readJson(sellerFile, []);

  const isOwner = owners.includes(String(userId));
  if (isOwner && requiredRoles.includes('owner')) return true;

  if (requiredRoles.includes('partner') && Array.isArray(partners)) {
    const isPartner = partners.some(p => String(p.id) === String(userId) && p.server === serverVersion);
    if (isPartner) return true;
  }

  if (requiredRoles.includes('reseller') && Array.isArray(resellers)) {
    const isReseller = resellers.some(r => String(r.id) === String(userId) && r.server === serverVersion);
    if (isReseller) return true;
  }

  if (requiredRoles.includes('seller') && Array.isArray(sellers)) {
    const isSeller = sellers.some(s => String(s.id) === String(userId));
    if (isSeller) return true;
  }

  return false;
}

// Fungsi untuk mendapatkan status server (client API)
async function getServerStatus(serverUuid, panelConfig) {
  try {
    const response = await axios.get(`${panelConfig.panelDomain}/api/client/servers/${serverUuid}/resources`, {
      headers: {
        'Authorization': `Bearer ${panelConfig.pltcKey}`
      }
    });
    return response.data.attributes.current_state;
  } catch (error) {
    return 'error';
  }
}

// Fungsi untuk menghentikan server (client API)
async function stopServer(serverUuid, panelDomain, pltcKey) {
  try {
    await axios.post(`${panelDomain}/api/client/servers/${serverUuid}/power`, {
      signal: 'stop'
    }, {
      headers: {
        'Authorization': `Bearer ${pltcKey}`,
        'Content-Type': 'application/json'
      }
    });
    return true;
  } catch (error) {
    console.error(`Gagal menghentikan server ${serverUuid}:`, error.message);
    return false;
  }
}

// Fungsi untuk mendapatkan konfigurasi panel
function getPanelConfig(version) {
  switch (version) {
    case 'v1':
      return {
        name: 'Server V1',
        panelDomain: global.domain,
        pltaKey: global.plta,
        pltcKey: global.pltc,
        nests: global.nests,
        eggs: global.eggs,
        loc: global.loc
      };
    case 'v2':
      return {
        name: 'Server V2',
        panelDomain: global.domainV2,
        pltaKey: global.pltaV2,
        pltcKey: global.pltcV2,
        nests: global.nestsV2,
        eggs: global.eggsV2,
        loc: global.locV2
      };
    case 'v3':
      return {
        name: 'Server V3',
        panelDomain: global.domainV3,
        pltaKey: global.pltaV3,
        pltcKey: global.pltcV3,
        nests: global.nestsV3,
        eggs: global.eggsV3,
        loc: global.locV3
      };
    case 'v4':
      return {
        name: 'Server V4',
        panelDomain: global.domainV4,
        pltaKey: global.pltaV4,
        pltcKey: global.pltcV4,
        nests: global.nestsV4,
        eggs: global.eggsV4,
        loc: global.locV4
      };
    default:
      return {};
  }
}

const CPU_CHECK_STATUS_FILE = './src/database/cpu_check_status.json';

// Fungsi untuk cek CPU (sebelumnya di xy.js)
async function checkAndStopAbnormalCpu(botInstance) {
    const statusData = readJson(CPU_CHECK_STATUS_FILE, {});
    const now = Date.now();
    
    for (const key in statusData) {
        if (!key.startsWith('v') || !statusData[key].active) continue;

        const serverVersion = key;
        const panelConfig = getPanelConfig(serverVersion);
        const { panelDomain, pltaKey, pltcKey } = panelConfig;
        const targetChatId = statusData[serverVersion].chat_id; 
        const recipientId = targetChatId || global.idowner; 
        
        if (!panelDomain || !pltaKey || !pltcKey || !recipientId) continue;

        let servers = [];
        let page = 1;
        let hasMore = true;
        let abnormalCpuServers = [];
        let totalServersChecked = 0;
        let serversFailedToStop = 0;
        let serversSkippedStop = 0;
        let initialMessageId = null;

        try {
            const loadingMsg = await botInstance.api.sendMessage(recipientId, `<blockquote>⏳ [AUTO-CHECK CPU] - ${serverVersion.toUpperCase()}\n\nMemulai pengecekan. Mohon tunggu...</blockquote>`, { parse_mode: 'HTML' });
            initialMessageId = loadingMsg.message_id;

            while (hasMore) {
                const response = await axios.get(`${panelDomain}/api/application/servers?page=${page}`, {
                    headers: { 'Authorization': `Bearer ${pltaKey}` }
                });
                const result = response.data;
                servers = servers.concat(result.data);
                hasMore = result.meta.pagination.current_page < result.meta.pagination.total_pages;
                page++;
            }

            for (const server of servers) {
                const { id: serverId, name: serverName, uuid: serverUuid } = server.attributes;
                try {
                    const resourceResponse = await axios.get(`${panelDomain}/api/client/servers/${serverUuid}/resources`, {
                        headers: { 'Authorization': `Bearer ${pltcKey}` }
                    });
                    const resources = resourceResponse.data.attributes.resources;
                    if (resources && resources.cpu_absolute !== undefined) {
                        const cpuUsage = resources.cpu_absolute;
                        const cpuLimit = resources.cpu_limit;
                        const limitToCompare = cpuLimit > 100 ? (cpuLimit * 0.8) : 80;
                        totalServersChecked++; 
                        if (cpuUsage > limitToCompare) {
                            abnormalCpuServers.push({ serverId, serverName, serverUuid, cpuUsage, cpuLimit, limitToCompare });
                        }
                    }
                } catch (error) {
                    // Abaikan server yang gagal dicek resources-nya
                }
            }
            
            for (const srv of abnormalCpuServers) {
                const stopTime = statusData[serverVersion].auto_stop[srv.serverId];
                if (stopTime && (now - stopTime < 5 * 60 * 1000)) { 
                    serversSkippedStop++;
                    continue; 
                }
                const isStopped = await stopServer(srv.serverUuid, panelDomain, pltcKey);
                if (isStopped) {
                    const notification = `
🚨 <b>[AUTO-STOP CPU] - ${serverVersion.toUpperCase()}</b> 🚨
Server <b>${srv.serverName}</b> (ID: <code>${srv.serverId}</code>) secara otomatis <b>dihentikan</b>!
📈 <b>CPU Usage</b>: ${srv.cpuUsage.toFixed(2)}% (Limit: ${srv.cpuLimit}%)
⚠️ Melebihi batas wajar (${srv.limitToCompare.toFixed(0)}%).
`;
                    try {
                        await botInstance.api.sendMessage(recipientId, `<blockquote>${notification}</blockquote>`, { parse_mode: 'HTML' });
                    } catch (e) { 
                        console.error(`Gagal kirim notif auto-stop ke ID ${recipientId}:`, e.message); 
                    }
                    statusData[serverVersion].auto_stop[srv.serverId] = now;
                } else {
                    serversFailedToStop++;
                }
            }
            
            let finalMessage = `
✅ <b>[AUTO-CHECK CPU] - ${serverVersion.toUpperCase()}</b> ✅

Total Server yang Dicek: <b>${totalServersChecked}</b>

`;
            if (abnormalCpuServers.length > 0) {
                const stoppedCount = abnormalCpuServers.length - serversFailedToStop - serversSkippedStop;
                finalMessage = `
⚠️ <b>[AUTO-CHECK SELESAI] - ${serverVersion.toUpperCase()}</b> ⚠️
Total Server Abnormal: <b>${abnormalCpuServers.length}</b>
- Dihentikan: <b>${stoppedCount}</b>
- Gagal Dihentikan: <b>${serversFailedToStop}</b>
- Dilewati (Baru distop): <b>${serversSkippedStop}</b>
`;
                abnormalCpuServers.forEach(srv => {
                    const status = statusData[serverVersion].auto_stop[srv.serverId] ? 'DiSTOP' : 'Gagal STOP';
                    finalMessage += `\n• <code>${srv.serverId}</code> (${srv.name}) - ${srv.cpuUsage.toFixed(2)}% (${status})`;
                });
            } else {
                 finalMessage += `Semua server yang dicek berada dalam batas CPU wajar.`;
            }
            

            await editReply({ api: botInstance.api, chat: { id: recipientId } }, initialMessageId, `<blockquote>${finalMessage}</blockquote>`);


            const updatedAutoStop = {};
            for(const id in statusData[serverVersion].auto_stop) {
                if(abnormalCpuServers.some(srv => String(srv.serverId) === id)) {
                    updatedAutoStop[id] = statusData[serverVersion].auto_stop[id];
                }
            }
            statusData[serverVersion].auto_stop = updatedAutoStop;

        } catch (err) {
            console.error(`Error auto-check CPU ${serverVersion}:`, err.message);
            let errorDetail = err.message;
            if (err.response && err.response.status === 403) errorDetail = "API Key PLTA/PLTC salah (403 Forbidden).";
            else if (err.code === 'ECONNREFUSED' || err.code === 'ENOTFOUND') errorDetail = "Domain Panel salah atau Node Wings offline.";
            else if (err.message) errorDetail = err.message.substring(0, 150);

            const errorNotification = `
❌ <b>[AUTO-CHECK GAGAL TOTAL] - ${serverVersion.toUpperCase()}</b> ❌
Gagal melakukan pengecekan server.
Pesan Error: <code>${errorDetail}</code>
`;
            try {
                if (initialMessageId) {
                    await editReply({ api: botInstance.api, chat: { id: recipientId } }, initialMessageId, `<blockquote>${errorNotification}</blockquote>`);
                } else {
                    await botInstance.api.sendMessage(recipientId, `<blockquote>${errorNotification}</blockquote>`, { parse_mode: 'HTML' });
                }
            } catch (e) { 
                console.error("Gagal kirim notif error auto-check:", e.message); 
            }
        }
    }
    
    writeJson(CPU_CHECK_STATUS_FILE, statusData); 
}


module.exports = {
  readJson,
  writeJson,
  sendChunkedMessage,
  editReply,
  checkUserRole,
  getServerStatus,
  stopServer,
  getPanelConfig,
  checkAndStopAbnormalCpu,
  CPU_CHECK_STATUS_FILE
};

