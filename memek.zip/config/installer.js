const fs = require('fs');
const axios = require('axios');
const { Client } = require('ssh2');
const { editReply } = require('./helpers.js');

// --- INSTALL DEPENDENCIES ---
const handleInstallDepend = async (context) => {
    const { xy, isOwner, reply, mess, text } = context;
    if (!isOwner) return reply(mess.owner);

    if (!text || !text.includes(',')) {
        return reply("<blockquote>⚠️ Format: <code>/installdepend IpVps,PwVps</code></blockquote>", { parse_mode: 'HTML' });
    }
    const [ipvps, passwd] = text.split(",").map(item => item.trim());
    if (!ipvps || !passwd) {
        return reply("<blockquote>⚠️ Format: <code>/installdepend IpVps,PwVps</code></blockquote>", { parse_mode: 'HTML' });
    }
    
    const loadingMsg = await reply("<blockquote>🔍 <b>Memeriksa koneksi VPS...</b></blockquote>", { reply_to_message_id: xy.message.message_id, parse_mode: 'HTML' });
    const connSettings = { host: ipvps, port: 22, username: "root", password: passwd, readyTimeout: 15000 };
    const commandSSH = `bash <(curl -s https://raw.githubusercontent.com/KiwamiXq1031/installer-premium/refs/heads/main/zero.sh)`;
    const conn = new Client();
    let logs = "🔍 <b>Memeriksa koneksi VPS...</b>";

    conn
        .on("ready", async () => {
            logs = `✅ Koneksi Berhasil!
Silahkan tunggu 10-20 menit...
⏳ <b>MEMPROSES INSTALL DEPENDENSI</b>`;
            await editReply(xy, loadingMsg.message_id, `<blockquote>${logs}</blockquote>`);

            conn.exec(commandSSH, (err, stream) => {
                if (err) {
                    editReply(xy, loadingMsg.message_id, `<blockquote>❌ GAGAL MENG-EKSEKUSI COMMAND!</blockquote>`);
                    return conn.end();
                }
                let progressUpdated = false;
                stream
                    .on("close", async () => {
                        try {
                            await xy.api.deleteMessage(xy.chat.id, loadingMsg.message_id);
                            await reply(`<blockquote>✅ <b>BERHASIL INSTALL DEPENDENSI!</b>\n\nVPS: <code>${ipvps}</code></blockquote>`, { parse_mode: 'HTML' });
                        } catch (error) {
                            console.error('Delete message error:', error.message);
                        }
                        conn.end();
                    })
                    .on("data", (data) => {
                        const output = data.toString();
                        console.log("OUTPUT:", output);
                        if (!progressUpdated && output.includes("INSTALLER") && output.includes("PTERODACTYL")) {
                            logs = "📦 MEMASUKKAN PILIHAN '13' (INSTALL DEPENDENSI)...";
                            editReply(xy, loadingMsg.message_id, `<blockquote>${logs}</blockquote>`);
                            progressUpdated = true;
                            stream.write("13\n"); 
                        }
                        if (output.includes("Pilih opsi lain") || output.includes("y/n") || output.includes("Y/n")) {
                            stream.write("Y\n"); 
                        }
                    })
                    .stderr.on("data", (data) => console.log("STDERR:", data.toString()));
            });
        })
        .on("error", async (err) => {
            console.error("SSH Error:", err.message);
            await editReply(xy, loadingMsg.message_id, `<blockquote>❌ <b>Kata sandi/IP tidak valid!</b>\n\nError: <code>${err.message}</code></blockquote>`);
        })
        .on("end", () => console.log("SSH Connection closed"))
        .connect(connSettings);
};

// --- HACKBACK PANEL ---
const handleHbPanel = async (context) => {
    const { xy, isOwner, reply, mess, text, command, generateReadableString } = context;
    if (!isOwner) return reply(mess.owner);
    if (!text || !text.includes(',')) return reply("<blockquote>❌ Format salah! Harap gunakan: <code>/hbpanel ipvps,pwvps</code></blockquote>", { 
        parse_mode: 'HTML'
    });

    const sentMessage = await reply(`<blockquote>🔄 <b>Memulai proses SSH untuk HACKBACKPANEL...</b> (Ini akan memakan waktu)</blockquote>`, {
        parse_mode: 'HTML'
    });

    (async () => {
        let [vpsIP, vpsPassword] = text.split(',').map(a => a.trim());
        const ssh = new Client();
        const connSettings = { host: vpsIP, port: 22, username: 'root', password: vpsPassword, readyTimeout: 15000 };
        let connectionError = null;
        
        const commandClearCache = `cd /var/www/pterodactyl && php artisan cache:clear && php artisan config:clear`;
        const newuser = "admin" + generateReadableString(4);
        const newpw = "admin" + generateReadableString(4);

        try {
            await new Promise((resolve, reject) => {
                ssh.on('ready', resolve).on('error', reject).connect(connSettings);
            });
            
            await editReply(xy, sentMessage.message_id, `<blockquote>🔄 <b>Membuat Admin Panel Baru via Artisan Command...</b>\n\nIP: <code>${vpsIP}</code>\n<b>Username Baru:</b> <code>${newuser}</code>\n<b>Password Baru:</b> <code>${newpw}</code></blockquote>`);

            const artisanCommand = `cd /var/www/pterodactyl && php artisan p:user:make --email="${newuser}@jhonhack.net" --username="${newuser}" --name-first="Hack" --name-last="Back" --password="${newpw}" --admin=1`;
            
            let outputArtisan = '';
            await new Promise((resolve, reject) => {
                ssh.exec(artisanCommand, (err, stream) => {
                    if (err) return reject(err);
                    stream.on('close', (code) => {
                        if (code !== 0) reject(new Error(`Artisan command failed. Output: ${outputArtisan.substring(0, 1000)}`));
                        else resolve();
                    }).on('data', (data) => outputArtisan += data.toString())
                      .stderr.on('data', (data) => outputArtisan += data.toString());
                });
            });

            await editReply(xy, sentMessage.message_id, `<blockquote>🔄 <b>Admin berhasil dibuat. Membersihkan cache Panel...</b></blockquote>`);
            
            await new Promise((resolve, reject) => {
                ssh.exec(commandClearCache, (err, stream) => {
                    if (err) return reject(err);
                    stream.on('close', (code) => code !== 0 ? reject(new Error('Clear cache gagal')) : resolve());
                });
            });

            const finalMessage = `✅ <b>Hackback Panel di VPS ${vpsIP} berhasil!</b>\n\n* <b>Username :</b> <code>${newuser}</code>\n* <b>Password :</b> <code>${newpw}</code>`;
            await editReply(xy, sentMessage.message_id, `<blockquote>${finalMessage}</blockquote>`);

        } catch (err) {
            connectionError = err;
            if (err.message.includes("user with that username already exists")) err.message = `Gagal: Username <code>${newuser}</code> sudah ada. Coba lagi!`;
            console.error(`❌ SSH Error ${command.toUpperCase()}:`, err.message);
        } finally {
            ssh.end();
        }

        if (connectionError) {
            await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal menjalankan ${command.toUpperCase()}: ${connectionError.message || 'Koneksi SSH gagal.'}</blockquote>`);
        }
    })();
};

// --- CLEAR ALL (USERS & SERVERS) ---
const handleClearAll = async (context) => {
    const { xy, isOwner, reply, mess, text, command } = context;
    if (!isOwner) return reply(mess.owner);
    if (!text || !text.includes(',')) return reply("<blockquote>❌ Format salah! Harap gunakan: <code>/clearall ipvps,pwvps</code></blockquote>", {
        parse_mode: 'HTML'
    });

    const sentMessage = await reply(`<blockquote>🔄 <b>Memulai proses SSH untuk ${command.toUpperCase()}...</b> (Ini akan memakan waktu)</blockquote>`, {
        parse_mode: 'HTML'
    });

    (async () => {
        let [vpsIP, vpsPassword] = text.split(',').map(a => a.trim());
        const ssh = new Client();
        const connSettings = { host: vpsIP, port: 22, username: 'root', password: vpsPassword };
        let connectionError = null;
        let finalMessage = "";

        try {
            await new Promise((resolve, reject) => {
                ssh.on('ready', resolve).on('error', reject).connect(connSettings);
            });
            
            await editReply(xy, sentMessage.message_id, `<blockquote>🔄 <b>Menghapus semua User dan Server di Panel Pterodactyl...</b></blockquote>`);
        
            const cleanupCommand = `cd /var/www/pterodactyl && php artisan tinker --execute="DB::statement('SET FOREIGN_KEY_CHECKS=0;'); \\\\Pterodactyl\\\\Models\\\\User::query()->forceDelete(); \\\\Pterodactyl\\\\Models\\\\Server::query()->forceDelete(); DB::statement('SET FOREIGN_KEY_CHECKS=1;'); echo 'Clear all berhasil dilakukan!';"`;
            
            await new Promise((resolve, reject) => {
                ssh.exec(cleanupCommand, (err, stream) => {
                    if (err) return reject(err);
                    stream.on('close', (code) => code !== 0 ? reject(new Error('Command failed')) : resolve());
                });
            });

            finalMessage = `✅ <b>Pterodactyl Panel di VPS ${vpsIP} berhasil DIBERSIHKAN!</b>\n\nDisarankan clear cache: <code>cd /var/www/pterodactyl && php artisan cache:clear</code>`;

        } catch (err) {
            connectionError = err;
            console.error(`❌ SSH Error ${command.toUpperCase()}:`, err.message);
        } finally {
            ssh.end();
        }

        if (connectionError) {
            await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal menjalankan ${command.toUpperCase()}: ${connectionError.message || 'Koneksi SSH gagal.'}</blockquote>`);
        } else {
            await editReply(xy, sentMessage.message_id, `<blockquote>${finalMessage}</blockquote>`);
        }
    })();
};

// --- UNINSTALL PANEL ---
const handleUninstallPanel = async (context) => {
    const { xy, isOwner, reply, mess, text, command } = context;
    if (!isOwner) return reply(mess.owner);
    if (!text || !text.includes(',')) return reply(`<blockquote>❌ Format salah! <code>/uninstallpanel ipvps,pwvps</code></blockquote>`, {
        parse_mode: 'HTML'
    });
    
    const sentMessage = await reply(`<blockquote>🔄 <b>Memulai proses SSH untuk UNINSTALLPANEL...</b></blockquote>`, {
        parse_mode: 'HTML'
    });

    (async () => {
        let [vpsIP, vpsPassword] = text.split(',').map(a => a.trim());
        const ssh = new Client();
        const connSettings = { host: vpsIP, port: 22, username: 'root', password: vpsPassword, readyTimeout: 20000 };
        let connectionError = null;
        const commandInstaller = `bash <(curl -s https://pterodactyl-installer.se)`;

        try {
            await new Promise((resolve, reject) => {
                ssh.on('ready', resolve).on('error', reject).connect(connSettings);
            });
            
            await editReply(xy, sentMessage.message_id, `<blockquote>🔄 <b>Menjalankan script uninstalasi panel...</b></blockquote>`);

            await new Promise((resolve, reject) => {
                ssh.exec(commandInstaller, (err, stream) => {
                    if (err) return reject(err);
                    stream.on('close', (code) => code !== 0 ? reject(new Error('Script gagal')) : resolve());
                    stream.on('data', (data) => {
                        const output = data.toString();
                        console.log("Uninstall Logger:", output);
                        if (output.includes('Input 0-6')) stream.write('6\n'); 
                        else if (output.includes('(y/N)')) stream.write('y\n'); 
                        else if (output.includes('Choose the panel user') || output.includes('Choose the panel database')) stream.write('\n');
                    });
                    stream.stderr.on('data', (data) => console.error("Uninstall STDERR:", data.toString()));
                });
            });
            await editReply(xy, sentMessage.message_id, `<blockquote>✅ <b>Uninstalasi Panel di VPS ${vpsIP} berhasil!</b></blockquote>`);
        
        } catch (err) {
            connectionError = err;
            console.error(`❌ SSH Error ${command.toUpperCase()}:`, err.message);
        } finally {
            ssh.end();
        }
        if (connectionError) {
            await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal menjalankan ${command.toUpperCase()}: ${connectionError.message || 'Koneksi SSH gagal.'}</blockquote>`);
        }
    })();
};

// --- START WINGS ---
const handleStartWings = async (context) => {
    const { xy, isOwner, reply, mess, text, command } = context;
    if (!isOwner) return reply(mess.owner);
    if (!text || text.split(',').length < 3) {
        return reply(`<blockquote>❌ Format salah! Harap gunakan: <code>/startwings ipvps,pwvps,token_node</code></blockquote>`, {
            parse_mode: 'HTML'
        });
    }

    const sentMessage = await reply(`<blockquote>🔄 <b>Memulai koneksi SSH untuk menjalankan Wings...</b></blockquote>`, {
        parse_mode: 'HTML'
    });

    (async () => {
        let [ipvps, passwd, token] = text.split(',').map(a => a.trim());
        const connSettings = { host: ipvps, port: 22, username: 'root', password: passwd, readyTimeout: 15000 };
        const commandSSH = `${token} && systemctl start wings`;
        const ssh = new Client();
        let connectionError = null;

        try {
            await new Promise((resolve, reject) => {
                ssh.on('ready', resolve).on('error', reject).connect(connSettings);
            });
            await editReply(xy, sentMessage.message_id, `<blockquote>🔄 <b>Menjalankan konfigurasi Wings...</b></blockquote>`);
            
            await new Promise((resolve, reject) => {
                ssh.exec(commandSSH, (err, stream) => {
                    if (err) return reject(err);
                    stream.on('close', (code) => code !== 0 ? reject(new Error('Command failed')) : resolve());
                });
            });
            await editReply(xy, sentMessage.message_id, `<blockquote>✅ <b>Wings berhasil dikonfigurasi dan dijalankan!</b></blockquote>`);

        } catch (err) {
            connectionError = err;
            console.error(`❌ SSH Error ${command.toUpperCase()}:`, err.message);
        } finally {
            ssh.end();
        }
        if (connectionError) {
            await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal menjalankan ${command.toUpperCase()}: ${connectionError.message || 'Koneksi SSH gagal.'}</blockquote>`);
        }
    })();
};

// --- INSTALL PANEL ---
const handleInstallPanel = async (context) => {
    const { xy, isOwner, reply, mess, text, command, generateReadableString, prefix } = context;
    if (!isOwner) return reply(mess.owner);
    
    if (!text || text.split('|').length < 5) {
        return reply(`<blockquote>❌ Format salah! <code>/installpanel ipvps|pwvps|panel.com|node.com|ramserver</code></blockquote>`, {
            parse_mode: 'HTML'
        });
    }
    
    const sentMessage = await reply(`<blockquote>🔄 <b>Memulai proses SSH untuk ${command.toUpperCase()}...</b> (Ini akan memakan waktu)</blockquote>`, {
        parse_mode: 'HTML'
    });

    (async () => {
        let [vpsIP, vpsPassword, domainpanel, domainnode, ramserver] = text.split('|').map(a => a.trim());
        const ssh = new Client();
        const connSettings = { host: vpsIP, port: 22, username: 'root', password: vpsPassword };
        let connectionError = null;
        
        const user = "jhon" + generateReadableString(4); 
        const pass = "jhon" + generateReadableString(4); 
        const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`;
        const commandCreateNode = `bash <(curl -s https://raw.githubusercontent.com/Bangsano/Autoinstaller-Theme-Pterodactyl/main/createnode.sh)`;
        
        try {
            await new Promise((resolve, reject) => {
                ssh.on('ready', resolve).on('error', reject).connect(connSettings);
            });
            
            await editReply(xy, sentMessage.message_id, `<blockquote>🔄 <b>Menginstal Panel..(tunggu 5 menit).</b></blockquote>`);
            
            // 1. Install Panel
            await new Promise((resolve, reject) => {
                ssh.exec(commandPanel, (err, stream) => {
                    if (err) return reject(err);
                    stream.on('close', resolve); 
                    stream.on('data', (data) => {
                        console.log("Panel Logger:", data.toString());
                        if (data.toString().includes('Input 0-6')) stream.write('0\n');
                        else if (data.toString().includes('Database name')) stream.write('\n'); 
                        else if (data.toString().includes('Database username')) stream.write('\n'); 
                        else if (data.toString().includes('Password')) stream.write('\n');
                        else if (data.toString().includes('Select timezone')) {
                            stream.write('Asia/Jakarta\n'); 
                            stream.write('jhon@gmail.com\n');
                            stream.write('jhon@gmail.com\n');
                            stream.write(`${user}\n`);
                            stream.write('jhon\n');
                            stream.write('jhon\n');
                            stream.write(`${pass}\n`);
                            stream.write(`${domainpanel}\n`);
                        }
                        else if (data.toString().includes('(y/N)')) stream.write('y\n');
                        else if (data.toString().includes('Set the FQDN')) stream.write(`${domainpanel}\n`);
                    });
                    stream.stderr.on('data', (data) => console.error("Panel STDERR:", data.toString()));
                });
            });

            await editReply(xy, sentMessage.message_id, `<blockquote>✅ Panel OK! Instalasi Wings...</blockquote>`);

            // 2. Install Wings
            await new Promise((resolve, reject) => {
                ssh.exec(commandPanel, (err, stream) => {
                    if (err) return reject(err);
                    stream.on('close', resolve);
                    stream.on('data', (data) => {
                        console.log("Wings Logger:", data.toString());
                        if (data.toString().includes('Input 0-6')) stream.write('1\n');
                        else if (data.toString().includes('Enter the panel address')) stream.write(`${domainpanel}\n`);
                        else if (data.toString().includes('Database host username')) stream.write(`${user}\n`);
                        else if (data.toString().includes('Database host password')) stream.write(`${pass}\n`);
                        else if (data.toString().includes('Set the FQDN')) stream.write(`${domainnode}\n`);
                        else if (data.toString().includes('Enter email address')) stream.write('syah@gmail.com\n');
                        else if (data.toString().includes('(y/N)')) stream.write('y\n');
                    });
                    stream.stderr.on('data', (data) => console.error("Wings STDERR:", data.toString()));
                });
            });

            await editReply(xy, sentMessage.message_id, `<blockquote>✅ Wings OK! Create Node...</blockquote>`);

            // 3. Create Node
            await new Promise((resolve, reject) => {
                ssh.exec(commandCreateNode, (err, streamNode) => {
                    if (err) return reject(err);
                    streamNode.on('close', resolve);
                    streamNode.on('data', (data) => {
                        console.log("CreateNode Logger:", data.toString());
                        if (data.toString().includes("Masukkan nama lokasi: ")) streamNode.write('SGP\n');
                        else if (data.toString().includes("Masukkan deskripsi lokasi: ")) streamNode.write('Jhonaley Tech\n');
                        else if (data.toString().includes("Masukkan domain: ")) streamNode.write(`${domainnode}\n`);
                        else if (data.toString().includes("Masukkan nama node: ")) streamNode.write('NODE BY JHON\n');
                        else if (data.toString().includes("Masukkan RAM (dalam MB): ")) streamNode.write(`${ramserver}\n`);
                        else if (data.toString().includes("Masukkan jumlah maksimum disk space (dalam MB): ")) streamNode.write(`${ramserver}\n`);
                        else if (data.toString().includes("Masukkan Locid: ")) streamNode.write('1\n');
                    });
                    streamNode.stderr.on('data', (data) => console.error("CreateNode STDERR:", data.toString()));
                });
            });
            
            const finalMessage = `✅ <b>Instalasi Panel dan Node berhasil!</b>\n* <b>Username :</b> <code>${user}</code>\n* <b>Password :</b> <code>${pass}</code>\n* <b>Domain Panel:</b> ${domainpanel}\n* <b>Domain Node:</b> ${domainnode}\n\n*Note :* Silahkan Buat Allocation & Ambil Token Wings.\n*Cara Menjalankan Wings:* <code>${prefix}startwings ${vpsIP},${vpsPassword},tokenwings</code>`;
            await editReply(xy, sentMessage.message_id, `<blockquote>${finalMessage}</blockquote>`);

        } catch (err) {
            connectionError = err;
            console.error(`❌ SSH Error ${command.toUpperCase()}:`, err.message);
        } finally {
            ssh.end();
        }
        if (connectionError) {
            await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal ${command.toUpperCase()}: ${connectionError.message || 'Koneksi SSH gagal.'}</blockquote>`);
        }
    })();
};

// --- (UN)INSTALL THEMES ---
// (Ini adalah gabungan logika dari case block installtema... di xy.js)
const handleThemeInstall = async (context) => {
    const { xy, isOwner, reply, mess, text, command } = context;
    if (!isOwner) return reply(mess.owner);
    if (!text || !text.includes(',')) return reply(`<blockquote>❌ Format salah! <code>/${command} ipvps,pwvps</code></blockquote>`, {
        parse_mode: 'HTML'
    });

    const sentMessage = await reply(`<blockquote>🔄 <b>Memulai proses SSH untuk ${command.toUpperCase()}...</b></blockquote>`, {
        parse_mode: 'HTML'
    });

    (async () => {
        let [vpsIP, vpsPassword] = text.split(',').map(a => a.trim());
        const ssh = new Client();
        const connSettings = { host: vpsIP, port: 22, username: 'root', password: vpsPassword };
        let connectionError = null;

        const temaMap = {
            "installtemastellar": { id: 1, script: `bash <(curl -s https://raw.githubusercontent.com/Bangsano/Autoinstaller-Theme-Pterodactyl/refs/heads/main/install.sh)` },
            "installtemanebula": { id: 2, script: `bash <(curl -s https://raw.githubusercontent.com/Bangsano/Autoinstaller-Theme-Pterodactyl/refs/heads/main/install.sh)` },
            "installtemadarknate": { id: 3, script: `bash <(curl -s https://raw.githubusercontent.com/Bangsano/Autoinstaller-Theme-Pterodactyl/refs/heads/main/install.sh)` },
            "installtemaenigma": { id: 4, script: `bash <(curl -s https://raw.githubusercontent.com/Bangsano/Autoinstaller-Theme-Pterodactyl/refs/heads/main/install.sh)` },
            "installtemabilling": { id: 5, script: `bash <(curl -s https://raw.githubusercontent.com/Bangsano/Autoinstaller-Theme-Pterodactyl/refs/heads/main/install.sh)` },
            "installtemaiceminecraft": { id: 6, script: `bash <(curl -s https://raw.githubusercontent.com/Bangsano/Autoinstaller-Theme-Pterodactyl/refs/heads/main/install.sh)` },
            "installtemanook": { id: 7, script: `bash <(curl -s https://raw.githubusercontent.com/Bangsano/Autoinstaller-Theme-Pterodactyl/refs/heads/main/install.sh)` },
            "installtemanightcore": { id: 8, script: `bash <(curl -s https://raw.githubusercontent.com/Bangsano/Autoinstaller-Theme-Pterodactyl/refs/heads/main/install.sh)` },
            "uninstalltema": { id: 9, script: `bash <(curl -s https://raw.githubusercontent.com/Bangsano/Autoinstaller-Theme-Pterodactyl/refs/heads/main/install.sh)` },
        };
        
        const theme = temaMap[command];
        if (!theme) {
            return editReply(xy, sentMessage.message_id, "<blockquote>❌ Perintah tema tidak dikenal.</blockquote>");
        }

        try {
            await new Promise((resolve, reject) => {
                ssh.on('ready', resolve).on('error', reject).connect(connSettings);
            });
            
            await editReply(xy, sentMessage.message_id, `<blockquote>🔄 <b>Menjalankan script ${command}...</b></blockquote>`);
            
            await new Promise((resolve, reject) => {
                ssh.exec(theme.script, (err, stream) => {
                    if (err) return reject(err);
                    stream.on('close', resolve);
                    stream.on('data', (data) => {
                        const output = data.toString();
                        console.log("Theme Logger:", output);
                        if (output.includes('Pilih tema')) {
                            stream.write(theme.id + '\n');
                        } else if (output.includes('(y/n)')) {
                            stream.write('y\n');
                        }
                    });
                    stream.stderr.on('data', (data) => console.error("Theme STDERR:", data.toString()));
                });
            });

            const action = command === 'uninstalltema' ? 'Dihapus' : 'Diinstal';
            await editReply(xy, sentMessage.message_id, `<blockquote>✅ <b>Tema berhasil ${action}!</b></blockquote>`);

        } catch (err) {
            connectionError = err;
            console.error(`❌ SSH Error ${command.toUpperCase()}:`, err.message);
        } finally {
            ssh.end();
        }
        if (connectionError) {
            await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal ${command.toUpperCase()}: ${connectionError.message || 'Koneksi SSH gagal.'}</blockquote>`);
        }
    })();
};

// --- SUBDOMAIN ---
const handleSubdo = async (context) => {
    const { isOwner, reply, mess, text, InlineKeyboard } = context;
    if (!isOwner) return reply(mess.owner);
    if (!text || !text.includes(',')) {
        return reply('<blockquote>❌ Format salah! Gunakan: <code>/subdo nama_host,ipvps</code></blockquote>', {
            parse_mode: 'HTML'
        });
    }

    const [host, ip] = text.split(',').map(a => a.trim());
    const dom = Object.keys(global.subdomain || {});
    if (dom.length === 0) {
        return reply('<blockquote>❌ Konfigurasi <b>global.subdomain</b> tidak ditemukan di settings.js.</blockquote>', {
            parse_mode: 'HTML'
        });
    }

    const inlineKeyboard = [];
    for (let i = 0; i < dom.length; i += 2) {
        const row = dom.slice(i, i + 2).map((d, index) => ({
            text: d,
            callback_data: `subdo ${i + index} ${host}|${ip}` 
        }));
        inlineKeyboard.push(row);
    }

    const opts = {
        reply_markup: {
            inline_keyboard: inlineKeyboard
        },
        parse_mode: "HTML"
    };

    await reply(`<blockquote>🔹 <b>Subdomain yang tersedia</b>
Host: ${host}
IP: ${ip}
Silahkan pilih Domain:</blockquote>`, opts);
};


// Ekspor semua fungsi
module.exports = {
    'installdepend': handleInstallDepend,
    'hbpanel': handleHbPanel,
    'hackbackpanel': handleHbPanel,
    'clearall': handleClearAll,
    'uninstallpanel': handleUninstallPanel,
    'startwings': handleStartWings,
    'configurewings': handleStartWings,
    'installpanel': handleInstallPanel,
    // Tema
    'installtemastellar': handleThemeInstall,
    'installtemanebula': handleThemeInstall,
    'installtemadarknate': handleThemeInstall,
    'installtemaenigma': handleThemeInstall,
    'installtemabilling': handleThemeInstall,
    'installtemaiceminecraft': handleThemeInstall,
    'installtemanook': handleThemeInstall,
    'installtemanightcore': handleThemeInstall,
    'uninstalltema': handleThemeInstall,
    // Subdo
    'subdo': handleSubdo,
};

