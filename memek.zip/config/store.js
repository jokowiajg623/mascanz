// config/store.js
// Berisi semua logika untuk store, payment, dan list produk

const fs = require('fs');
const axios = require('axios');
const path = require('path');
const { readJson, writeJson, editReply } = require('./helpers.js'); // Impor helpers
const toqrcode = require('../src/lib/qrcode'); // Asumsi path

const LIST_FILE = './src/database/list.json';

// --- PAYMENT ---
const handlePay = async (context) => {
    const { xy, reply, text, sender, sleep, InputFile } = context;
    if (!text) return reply('<blockquote>Lengkapi Command kamu!\n\nContoh: <code>.pay 1000</code></blockquote>', { parse_mode: 'HTML' });
    if (parseFloat(text) < global.minimalDeposit) return reply(`<blockquote>Minimal Transaksi harus Rp ${global.minimalDeposit}</blockquote>`, { parse_mode: 'HTML' });

    const sentMessage = await reply(`<blockquote>⏳ <b>Memproses pembayaran...</b></blockquote>`, { parse_mode: 'HTML' });
    (async () => {
        let val = text.replace(/[^0-9\-\/+*×÷πEe()piPI/]/g, '').replace(/×/g, '*').replace(/÷/g, '/').replace(/π|pi/gi, 'Math.PI').replace(/e/gi, 'Math.E').replace(/\/+/g, '/').replace(/\++/g, '+').replace(/-+/g, '-');
        let deponya;
        try {
            deponya = (new Function('return ' + val))();
            if (!deponya) throw new Error('Format perhitungan salah');
        } catch (e) { return editReply(xy, sentMessage.message_id, '<blockquote>Format salah, hanya 0-9 dan simbol -, +, *, /, ×, ÷, π, e, (, ) yang disupport</blockquote>'); }

        let ref = Math.floor(Math.random() * 100000000);
        let h2hkey = global.apikeyhost; // Ambil dari global

        try {
            let config = { method: 'POST', url: 'https://atlantich2h.com/deposit/create', data: new URLSearchParams({ api_key: h2hkey, reff_id: ref, nominal: deponya, type: 'ewallet', metode: 'qris' }) };
            const res = await axios(config);
            if (!res.data.status) throw new Error(res.data.message || 'Unknown error');
            
            const qrData = res.data.data.qr_string;
            const qrMessage = `Silahkan scan Qriss diatas untuk membayar sejumlah:\n\nBill: ${res.data.data.nominal}\nStatus: ${res.data.data.status}\n\nJika ingin cancel transaksi ketik :\n<code>/cancelpay</code>\n(note: reply pesan ini, khusus owner)`;
            
            const qrImageUrl = await toqrcode(qrData); // Gunakan lib qrcode
            const sentQR = await xy.api.sendPhoto(sender, qrImageUrl, { caption: qrMessage, parse_mode: 'HTML' });
            await xy.api.deleteMessage(xy.chat.id, sentMessage.message_id);

            let obj = { id: sender, ref: res.data.data.id, messageId: sentQR.message_id, status: res.data.data.status };
            if (!fs.existsSync('./src/database/datasaldo')) fs.mkdirSync('./src/database/datasaldo');
            fs.writeFileSync(`./src/database/datasaldo/${sender}.json`, JSON.stringify(obj));

            let status = res.data.data.status;
            const topup = { method: 'POST', url: 'https://atlantich2h.com/deposit/status', data: new URLSearchParams({ api_key: h2hkey, id: res.data.data.id }) };
            const acc = { method: 'POST', url: 'https://atlantich2h.com/deposit/instant', data: new URLSearchParams({ api_key: h2hkey, id: res.data.data.id, action: 'true' }) };

            while (status !== 'processing') {
                await sleep(1000);
                const response = await axios(topup);
                status = response.data.data.status;
                if (status === 'cancel' || status === 'expired') {
                    await xy.api.sendMessage(xy.chat.id, `<blockquote>Transaksi ${status}</blockquote>`, { parse_mode: 'HTML' });
                    break;
                }
                if (status === 'processing') {
                    await axios(acc);
                    status = 'success';
                    await xy.api.deleteMessage(sender, sentQR.message_id);
                    await xy.api.sendMessage(xy.chat.id, `<blockquote>Transaksi telah sukses\n\nTerimakasih atas pembelian Anda</blockquote>`, { parse_mode: 'HTML' });
                    fs.unlinkSync(`./src/database/datasaldo/${sender}.json`);
                    break;
                }
            }
        } catch (error) {
            console.log('Deposit error:', error.message);
            await editReply(xy, sentMessage.message_id, `<blockquote>Terjadi error saat membuat deposit. Error: ${error.message}</blockquote>`);
        }
    })();
};

const handleCancelPay = async (context) => {
    const { xy, reply, sender, isOwner, mess, editReply } = context;
    if (!isOwner) return reply(mess.owner);
    const dbPath = `./src/database/datasaldo/${sender}.json`;
    if (!fs.existsSync(dbPath)) {
        return reply("<blockquote>❌ Kamu tidak memiliki deposit yang sedang berlangsung.</blockquote>", { parse_mode: 'HTML' });
    }
    const sentMessage = await reply(`<blockquote>⏳ <b>Membatalkan pembayaran...</b></blockquote>`, { parse_mode: 'HTML' });
    (async () => {
        const data = JSON.parse(fs.readFileSync(dbPath, "utf8"));
        const config = { method: "POST", url: "https://atlantich2h.com/deposit/cancel", data: new URLSearchParams({ api_key: global.apikeyhost, id: data.ref }) };
        try {
            await axios(config);
            await xy.api.deleteMessage(sender, data.messageId);
            fs.unlinkSync(dbPath);
            await editReply(xy, sentMessage.message_id, "<blockquote>✅ Deposit berhasil dibatalkan.</blockquote>");
        } catch (error) {
            await editReply(xy, sentMessage.message_id, "<blockquote>❌ Gagal membatalkan deposit.</blockquote>");
        }
    })();
};

const handleSaldo = async (context) => {
    const { reply, isOwner, mess, editReply, xy } = context;
    if (!isOwner) return reply(mess.owner);
    const sentMessage = await reply(`<blockquote>⏳ <b>Mengecek saldo...</b></blockquote>`, { parse_mode: 'HTML' });
    (async () => {
        try {
            const response = await axios("https://atlantich2h.com/get_profile", { method: "POST", data: new URLSearchParams({ api_key: global.apikeyhost }) });
            const res = response.data;
            if (!res.status || !res.data) throw new Error("Gagal mengambil data profil.");
            const { name, username, balance, status } = res.data;
            const message = `💼 Informasi Akun\n\n👤 Nama: ${name}\n🆔 Username: ${username}\n💰 Saldo: Rp${Number(balance).toLocaleString("id-ID")}\n📌 Status: ${status}`;
            await editReply(xy, sentMessage.message_id, `<blockquote>${message}</blockquote>`);
        } catch (err) {
            await editReply(xy, sentMessage.message_id, "<blockquote>❌ Terjadi kesalahan saat mengambil data saldo.</blockquote>");
        }
    })();
};

// --- LIST PRODUK ---
const handleAddList = async (context) => {
    const { xy, reply, text, mess, prefix, command } = context;
    if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
    const productInfo = text.split('|');
    if (productInfo.length < 2) return reply(`<blockquote>❌ Format salah!\n\nPenggunaan: <code>${prefix + command} [Key] | [Respon]</code>\n(Opsional: Reply foto/video)</blockquote>`, { parse_mode: 'HTML' });
    const [key, responseText] = productInfo.map(s => s.trim());
    const groupID = xy.chat.id;
    let listData = readJson(LIST_FILE);
    if (listData.some(item => item.id === groupID && item.key.toLowerCase() === key.toLowerCase())) return reply(`<blockquote>⚠️ Key "<b>${key}</b>" sudah ada.</blockquote>`, { parse_mode: 'HTML' });

    const newItem = { id: groupID, key: key, response: responseText, isImage: false, image_url: '' };
    const replyMessage = xy.message.reply_to_message;
    if (replyMessage && (replyMessage.photo || replyMessage.video)) {
        const mediaType = replyMessage.photo ? 'Photo' : 'Video';
        newItem.isImage = true;
        // TODO: Implement actual image upload logic here instead of placeholder
        newItem.image_url = 'https://telegra.ph/file/134ccbbd0dfc434a910ab.png'; // Placeholder
        listData.push(newItem);
        writeJson(LIST_FILE, listData);
        reply(`<blockquote>✅ Produk <b>${key}</b> berhasil ditambahkan dengan ${mediaType}!</blockquote>`, { parse_mode: 'HTML' });
    } else {
        listData.push(newItem);
        writeJson(LIST_FILE, listData);
        reply(`<blockquote>✅ Produk <b>${key}</b> berhasil ditambahkan (Teks saja).</blockquote>`, { parse_mode: 'HTML' });
    }
};

const handleDelList = async (context) => {
    const { xy, reply, text, mess, prefix, command } = context;
    if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
    if (!text) return reply(`<blockquote>❌ Format salah!\n\nPenggunaan: <code>${prefix + command} [Key Produk]</code></blockquote>`, { parse_mode: 'HTML' });
    const key = text.trim();
    const groupID = xy.chat.id;
    let listData = readJson(LIST_FILE);
    const initialLength = listData.length;
    listData = listData.filter(item => !(item.id === groupID && item.key.toLowerCase() === key.toLowerCase()));
    if (listData.length < initialLength) {
        writeJson(LIST_FILE, listData);
        reply(`<blockquote>✅ Produk <b>${key}</b> berhasil dihapus.</blockquote>`, { parse_mode: 'HTML' });
    } else {
        reply(`<blockquote>⚠️ Key "<b>${key}</b>" tidak ditemukan.</blockquote>`, { parse_mode: 'HTML' });
    }
};

const handleUpdateList = async (context) => {
    const { xy, reply, text, mess, prefix, command } = context;
    if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
    const productInfo = text.split('|');
    if (productInfo.length < 2) return reply(`<blockquote>❌ Format salah!\n\nPenggunaan: <code>${prefix + command} [Key] | [Respon Baru]</code>\n(Opsional: Reply media baru)</blockquote>`, { parse_mode: 'HTML' });
    const [key, responseText] = productInfo.map(s => s.trim());
    const groupID = xy.chat.id;
    let listData = readJson(LIST_FILE);
    const foundIndex = listData.findIndex(item => item.id === groupID && item.key.toLowerCase() === key.toLowerCase());
    if (foundIndex === -1) return reply(`<blockquote>⚠️ Key "<b>${key}</b>" tidak ditemukan.</blockquote>`, { parse_mode: 'HTML' });
    
    listData[foundIndex].response = responseText;
    listData[foundIndex].isImage = false;
    listData[foundIndex].image_url = '';
    
    const replyMessage = xy.message.reply_to_message;
    if (replyMessage && (replyMessage.photo || replyMessage.video)) {
        listData[foundIndex].isImage = true;
        // TODO: Implement actual image upload
        listData[foundIndex].image_url = 'https://telegra.ph/file/134ccbbd0dfc434a910ab.png'; // Placeholder
    }
    writeJson(LIST_FILE, listData);
    reply(`<blockquote>✅ Produk <b>${key}</b> berhasil diperbarui.</blockquote>`, { parse_mode: 'HTML' });
};

const handleDelListAll = async (context) => {
    const { xy, reply, mess } = context;
    if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
    const groupID = xy.chat.id;
    let listData = readJson(LIST_FILE);
    const initialLength = listData.length;
    listData = listData.filter(item => item.id !== groupID);
    if (listData.length < initialLength) {
        writeJson(LIST_FILE, listData);
        reply(`<blockquote>✅ Semua Produk (${initialLength - listData.length} item) berhasil dihapus.</blockquote>`, { parse_mode: 'HTML' });
    } else {
        reply(`<blockquote>⚠️ Tidak ada Produk yang terdaftar.</blockquote>`, { parse_mode: 'HTML' });
    }
};

const handleListProduk = async (context) => {
    const { xy, reply, mess } = context;
    if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
    const groupID = xy.chat.id;
    const listData = readJson(LIST_FILE);
    const groupList = listData.filter(item => item.id === groupID);
    if (groupList.length === 0) return reply(`<blockquote>⚠️ Tidak ada Produk yang terdaftar.</blockquote>`, { parse_mode: 'HTML' });
    let responseText = `📜 <b>DAFTAR PRODUK/RESPON</b> (${groupList.length} item)\n\n`;
    groupList.forEach((item, index) => {
        const media = item.isImage ? '🖼️ (Media)' : '';
        responseText += `${index + 1}. <b>${item.key}</b> ${media}\n`;
    });
    responseText += `\n📌 Untuk melihat detail, ketik <b>Key</b> produk.`;
    reply(`<blockquote>${responseText}</blockquote>`, { parse_mode: 'HTML' });
};

const handleSearchProduk = async (context) => {
    const { xy, reply, text, mess, prefix, command } = context;
    if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
    if (!text) return reply(`<blockquote>❌ Format salah!\n\nPenggunaan: <code>${prefix + command} [Kata Kunci]</code></blockquote>`, { parse_mode: 'HTML' });
    const keyword = text.trim().toLowerCase();
    const groupID = xy.chat.id;
    const listData = readJson(LIST_FILE);
    const results = listData.filter(item => item.id === groupID && (item.key.toLowerCase().includes(keyword) || item.response.toLowerCase().includes(keyword)));
    if (results.length === 0) return reply(`<blockquote>⚠️ Tidak ditemukan Produk "<b>${text}</b>".</blockquote>`, { parse_mode: 'HTML' });
    let responseText = `🔍 <b>HASIL PENCARIAN PRODUK</b> (${results.length} item)\n\n`;
    results.forEach((item, index) => {
        const media = item.isImage ? '🖼️ (Media)' : '';
        responseText += `${index + 1}. <b>${item.key}</b> ${media}\n`;
    });
    responseText += `\n📌 Untuk melihat detail, ketik <b>Key</b> produk.`;
    reply(`<blockquote>${responseText}</blockquote>`, { parse_mode: 'HTML' });
};


module.exports = {
    // Payment
    'pay': handlePay,
    'cancelpay': handleCancelPay,
    'saldo': handleSaldo,
    'cek': handleSaldo,
    // List
    'addlist': handleAddList,
    'dellist': handleDelList,
    'updatelist': handleUpdateList,
    'dellistall': handleDelListAll,
    'listproduk': handleListProduk,
    'searchproduk': handleSearchProduk,
};

