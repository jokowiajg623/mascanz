// config/ai.js
// Berisi semua logika untuk perintah AI

const fs = require('fs');
const axios = require('axios');
const path = require('path');
const { exec } = require("child_process");

// Impor lib AI (diasumsikan path-nya benar)
const genmusic = require('../src/lib/aimusic'); 
// const toanime = require('../src/lib/toanime'); // Jika ada lib khusus

// --- AI MUSIC ---
const handleAiMusic = async (context) => {
    const { xy, reply, text, editReply, prefix, command, CatBox } = context;
    if (!text) return reply(`<blockquote>❌ <b>Format salah!</b>\n\nContoh: <code>${prefix + command} musik yang tenang instrumental</code></blockquote>`, { parse_mode: 'HTML' });
    const sentMessage = await reply('<blockquote>🎶 Sedang membuat musik dari idemu...\nMohon tunggu sebentar...</blockquote>', { parse_mode: 'HTML' });
    (async () => {
        try {
            const result = await genmusic(text);
            if (!result || !result[0]?.audio_url) {
                return editReply(xy, sentMessage.message_id, '<blockquote>❌ Gagal menghasilkan musik.\nCoba lagi dengan ide yang berbeda.</blockquote>');
            }
            const audio = result[0].audio_url;
            const title = result[0].title || 'Musik AI';
            const info = `🎵 Musik Selesai!\n\n📝 Judul: ${title}\n💡 Ide: ${text}\n\n⬆️ Mengunggah musik ke server...`;
            await editReply(xy, sentMessage.message_id, `<blockquote>${info}</blockquote>`);
            const filePath = path.join(__dirname, 'music_ai.mp3'); // Gunakan __dirname
            const res = await axios.get(audio, { responseType: 'stream' });
            const writer = fs.createWriteStream(filePath);
            res.data.pipe(writer);
            await new Promise((resolve, reject) => { writer.on('finish', resolve); writer.on('error', reject); });
            const uploadedUrl = await CatBox(filePath);
            await xy.api.sendAudio(xy.chat.id, uploadedUrl, { caption: `<blockquote>🎵 <b>${title}</b></blockquote>`, parse_mode: "HTML" });
            fs.unlinkSync(filePath);
            await editReply(xy, sentMessage.message_id, `<blockquote>✅ <b>Musik AI berhasil dibuat dan dikirim!</b></blockquote>`);
        } catch (e) {
            console.error('GenMusic Error:', e);
            await editReply(xy, sentMessage.message_id, `<blockquote>❌ <b>Gagal membuat musik dari idemu</b>\n\nError: <code>${e.message}</code></blockquote>`);
        }
    })();
};

// --- AI (GPT, VID, IMG, VOICE, TOANIME) ---
const handleAiBlock = async (context) => {
    const { xy, reply, q, text, command, editReply, InputFile, CatBox } = context;
    if (!q && (command !== 'toanime' || !xy.message.photo && !xy.message.reply_to_message?.photo)) {
        return reply(`<blockquote><b>Masukkan deskripsi/teks!</b> Contoh: <code>/${command} Anime</code></blockquote>`, { parse_mode: 'HTML' });
    }
    const sentMessage = await reply(`<blockquote>⏳ <b>Sedang memproses ${command.includes('ai') ? 'AI' : 'Gambar/Suara'}...</b></blockquote>`, { parse_mode: 'HTML' });
    (async () => {
        try {
            if (command === 'ai' || command === 'gpt' || command === 'nekogpt') {
                const res = await fetch(`https://api.nekorinn.my.id/ai/gpt-4.1-mini?text=${encodeURIComponent(q)}`);
                const data = await res.json();
                if (!data.status || !data.result) throw new Error('Tidak ada respons dari AI.');
                await editReply(xy, sentMessage.message_id, data.result);
            } else if (command.includes('aivid')) {
                const videoUrl = `https://api.nekorinn.my.id/ai-vid/videogpt?text=${encodeURIComponent(q)}`;
                const filePath = path.join(__dirname, 'temp_aivid.mp4'); // Gunakan __dirname
                const res = await axios.get(videoUrl, { responseType: 'stream' });
                const writer = fs.createWriteStream(filePath);
                res.data.pipe(writer);
                await new Promise((resolve, reject) => { writer.on('finish', resolve); writer.on('error', reject); });
                const uploadedUrl = await CatBox(filePath);
                await xy.replyWithVideo(uploadedUrl, { caption: `<blockquote>🎥 <b>Hasil Video AI</b>\n\nPrompt: ${q}</blockquote>`, parse_mode: "HTML" });
                fs.unlinkSync(filePath);
                await editReply(xy, sentMessage.message_id, `<blockquote>✅ Video AI berhasil dibuat dan dikirim.</blockquote>`);
            } else if (command.includes('aiimg')) {
                const imageUrl = `https://api.nekorinn.my.id/ai-img/ai4chat?text=${encodeURIComponent(q)}&ratio=16%3A9`;
                await xy.replyWithPhoto(imageUrl, { caption: `<blockquote>🖼️ <b>Hasil Gambar AI</b>\n\nPrompt: ${q}</blockquote>`, parse_mode: 'HTML' });
                await editReply(xy, sentMessage.message_id, `<blockquote>✅ Gambar AI berhasil dibuat dan dikirim.</blockquote>`);
            } else if (command === 'voiceai') {
                const url = `https://api.streamelements.com/kappa/v2/speech?voice=Brian&text=${encodeURIComponent(text)}`;
                const filepath = './tmp_voice.mp3'; // Path sementara
                const response = await axios.get(url, { responseType: 'arraybuffer' });
                fs.writeFileSync(filepath, response.data);
                await xy.api.sendVoice(xy.chat.id, new InputFile(filepath));
                fs.unlinkSync(filepath);
                await editReply(xy, sentMessage.message_id, `<blockquote>✅ Voice AI berhasil dibuat dan dikirim.</blockquote>`);
            } else if (command === 'toanime') {
                // ... (Logika To Anime Anda yang kompleks) ...
                // Contoh placeholder:
                await editReply(xy, sentMessage.message_id, `<blockquote>✅ (Placeholder) Foto berhasil diubah jadi anime dan dikirim.</blockquote>`);
            }
        } catch (err) {
            console.error(`❌ ${command.toUpperCase()} Error:`, err.message);
            await editReply(xy, sentMessage.message_id, `<blockquote>❌ Terjadi kesalahan saat memproses: ${err.message}</blockquote>`);
        }
    })();
};


module.exports = {
    'aimusic': handleAiMusic,
    'ai': handleAiBlock,
    'gpt': handleAiBlock,
    'nekogpt': handleAiBlock,
    'aivid': handleAiBlock,
    'vidai': handleAiBlock,
    'aivideo': handleAiBlock,
    'aiimg': handleAiBlock,
    'imgai': handleAiBlock,
    'aigambar': handleAiBlock,
    'voiceai': handleAiBlock,
    'toanime': handleAiBlock,
};

