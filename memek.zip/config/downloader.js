// config/downloader.js
// Berisi semua logika untuk perintah downloader

const fs = require('fs');
const axios = require('axios');
const path = require('path');
const ffmpeg = require('fluent-ffmpeg');

// Impor spesifik untuk downloader
const Tiktok = require("@tobyg74/tiktok-api-dl");
const ytdl = require('@distube/ytdl-core');
const { igdl } = require('btch-downloader');
const tiktok2 = require('../src/lib/tiktok');
const pinterest = require('../src/lib/pinterest'); 
const helpers = require('./helpers.js'); 

// --- TIKTOK ---
const handleTiktok = async (context) => {
    const { xy, reply, text, editReply, InputFile } = context;
    if (!text || !text.includes('tiktok')) {
        return reply(`<blockquote><b>❌ Tautan tidak valid.</b>\n\nContoh: <code>/tiktok link_video</code></blockquote>`, { parse_mode: 'HTML' });
    }
    const sentMessage = await reply(`<blockquote>⏳ <b>Sedang memproses video TikTok...</b></blockquote>`, { parse_mode: 'HTML' });
    (async () => {
        try {
            const data = await tiktok2(text); 
            if (data.no_watermark) {
                await xy.api.sendVideo(xy.chat.id, data.no_watermark, { caption: `<blockquote>🎥 <b>Tanpa Watermark</b>\n${data.title || ''}</blockquote>`, parse_mode: "HTML" });
            }
            if (data.music && data.music.startsWith('http')) {
                const audioBuffer = await axios.get(data.music, { responseType: "arraybuffer" });
                await xy.api.sendAudio(xy.chat.id, new InputFile(Buffer.from(audioBuffer.data), "audio.mp3"), { caption: `<blockquote>🎵 <b>Audio dari TikTok</b></blockquote>`, parse_mode: "HTML" });
            }
            await editReply(xy, sentMessage.message_id, `<blockquote>✅ <b>Berhasil mengunduh video TikTok!</b></blockquote>`);
        } catch (err) {
            console.error(err);
            await editReply(xy, sentMessage.message_id, `<blockquote>❌ <b>Terjadi kesalahan saat memproses video TikTok.</b></blockquote>`);
        }
    })();
};

// --- TIKTOK SLIDE ---
const handleTiktokSlide = async (context) => {
    const { xy, reply, text, editReply, prefix, command } = context;
    if (!text) {
        return reply(`<blockquote>Gunakan perintah ini dengan cara <code>${prefix + command} url</code></blockquote>`, { parse_mode: 'HTML' });
    }
    const sentMessage = await reply('<blockquote>⏳ Sedang memproses TikTok Slide...</blockquote>', { parse_mode: 'HTML' });
    (async () => {
        try {
            const result = await Tiktok.Downloader(text, { version: "v1", proxy: null });
            if (result.status !== "success") {
                return editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal mengunduh TikTok.</blockquote>`);
            }
            const { images, author, description, statistics } = result.result;
            const urlCreator = author?.url;
            const audioUrl = result.result.music?.playUrl?.[0];
            if (audioUrl) {
                await xy.api.sendAudio(xy.chat.id, audioUrl, { caption: '<blockquote>🎵 Audio TikTok</blockquote>', parse_mode: 'HTML' });
            }
            if (result.result.type === "image" && images?.length) {
                let i = 1;
                for (const imageUrl of images) {
                    await xy.api.sendPhoto(xy.chat.id, imageUrl, { caption: `<blockquote>📸 Gambar ke-${i++}\n👤 ${author.nickname}\n📝 ${description}</blockquote>`, parse_mode: 'HTML' });
                }
                const statsMessage = `📊 Statistik:\n👀 Views: ${statistics.playCount}\n🔄 Shares: ${statistics.shareCount}\n💬 Comments: ${statistics.commentCount}\n📥 Downloads: ${statistics.downloadCount}\n👤 Creator: <a href="${urlCreator}">${author.nickname}</a>`;
                await editReply(xy, sentMessage.message_id, `<blockquote>✅ <b>Berhasil mengunduh TikTok Slide!</b>\n\n${statsMessage}</blockquote>`);
            } else {
                await editReply(xy, sentMessage.message_id, `<blockquote>⚠️ Konten TikTok yang diberikan tidak berupa audio maupun gambar.</blockquote>`);
            }
        } catch (error) {
            console.error(`Error processing TikTok:`, error);
            await editReply(xy, sentMessage.message_id, `<blockquote>❌ Terjadi kesalahan saat memproses video TikTok.</blockquote>`);
        }
    })();
};

// --- INSTAGRAM ---
const handleIgdl = async (context) => {
    const { xy, reply, text, editReply, CatBox, InputFile } = context;
    if (!text || !text.includes("instagram.com/")) {
        return reply("<blockquote>❌ <b>Link Instagram tidak valid!</b>\n\nContoh: <code>/igdl https://www.instagram.com/p/xyz</code></blockquote>", { parse_mode: 'HTML' });
    }
    const sentMessage = await reply("<blockquote>⏳ <b>Sedang memproses media dari Instagram...</b></blockquote>", { parse_mode: 'HTML' });
    (async () => {
        try {
            const data = await igdl(text);
            if (!data || !Array.isArray(data) || data.length === 0) {
                return editReply(xy, sentMessage.message_id, "<blockquote>❌ <b>Tidak ada media yang ditemukan di link Instagram tersebut!</b></blockquote>");
            }
            let alreadySent = new Set();
            for (const item of data) {
                if (!item.url || alreadySent.has(item.url)) continue;
                const isVideo = item.url.includes("video") || item.type === 'video';
                const ext = isVideo ? ".mp4" : ".jpg";
                const filePath = `./igmedia${ext}`;
                try {
                    const writer = fs.createWriteStream(filePath);
                    const response = await axios({ url: item.url, method: "GET", responseType: "stream", headers: { 'User-Agent': 'Mozilla/5.0' } });
                    response.data.pipe(writer);
                    await new Promise((resolve, reject) => { writer.on("finish", resolve); writer.on("error", reject); response.data.on("error", reject); });
                    const uploadedUrl = await CatBox(filePath);
                    alreadySent.add(item.url);
                    if (isVideo) {
                        await xy.api.sendVideo(xy.chat.id, uploadedUrl, { caption: "<blockquote>🎥 <b>Berikut adalah video dari Instagram!</b></blockquote>", parse_mode: "HTML" });
                    } else {
                        await xy.api.sendPhoto(xy.chat.id, uploadedUrl, { caption: "<blockquote>🖼️ <b>Berikut adalah foto dari Instagram!</b></blockquote>", parse_mode: "HTML" });
                    }
                    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
                } catch (itemError) {
                    console.error(`Error processing item ${item.url}:`, itemError);
                }
            }
            await editReply(xy, sentMessage.message_id, `<blockquote>✅ <b>Media Instagram berhasil diunduh! (${alreadySent.size} file)</b></blockquote>`);
        } catch (err) {
            console.error("Kesalahan saat mengunduh dari Instagram:", err);
            await editReply(xy, sentMessage.message_id, "<blockquote>❌ <b>Terjadi kesalahan saat mengunduh media Instagram!</b></blockquote>");
        }
    })();
};

// --- YOUTUBE ---
const handleYtdl = async (context) => {
    const { xy, reply, text, editReply, CatBox } = context;
    if (!text || !ytdl.validateURL(text)) return reply('<blockquote>❌ <b>Link tidak valid!</b>\n\nContoh: <code>/yt https://...</code></blockquote>', { parse_mode: 'HTML' });
    const sentMessage = await reply('<blockquote>⏳ <b>Mengunduh video dan audio dari YouTube...</b></blockquote>', { parse_mode: 'HTML' });
    (async () => {
        const link = text;
        const videoPath = './yt_video.mp4';
        const audioPath = './yt_audio.mp3';
        try {
            const info = await ytdl.getInfo(link);
            const { title, author, lengthSeconds, uploadDate } = info.videoDetails;
            const duration = new Date(lengthSeconds * 1000).toISOString().substr(11, 8);
            const durationFormatted = duration.startsWith('00:') ? duration.substr(3) : duration;

            await new Promise((resolve, reject) => {
                ytdl(link, { quality: 'highestvideo' }).pipe(fs.createWriteStream(videoPath)).on('finish', resolve).on('error', reject);
            });
            await new Promise((resolve, reject) => {
                ffmpeg(ytdl(link, { quality: 'highestaudio' })).audioCodec('libmp3lame').save(audioPath).on('end', resolve).on('error', reject);
            });

            const audioUrl = await CatBox(audioPath);
            await xy.api.sendAudio(xy.chat.id, audioUrl, { caption: '<blockquote>🎵 <b>Audio YouTube</b></blockquote>', parse_mode: 'HTML' });
            const videoUrl = await CatBox(videoPath);
            await xy.api.sendVideo(xy.chat.id, videoUrl, { caption: `<blockquote>🎬 <b>Video YouTube:</b>\n\n📌 <b>Judul:</b> ${title}\n📺 <b>Channel:</b> ${author.name}\n⏳ <b>Durasi:</b> ${durationFormatted}\n📅 <b>Upload:</b> ${uploadDate || '-'}</blockquote>`, parse_mode: 'HTML' });
            
            fs.unlinkSync(videoPath); fs.unlinkSync(audioPath);
            const jsFile = fs.readdirSync('.').find(file => file.endsWith('-player-script.js'));
            if (jsFile) fs.unlinkSync(jsFile);
            
            await editReply(xy, sentMessage.message_id, '<blockquote>✅ <b>Pengunduhan YouTube selesai!</b></blockquote>');
        } catch (err) {
            console.error('YTDL Error:', err);
            if (fs.existsSync(videoPath)) fs.unlinkSync(videoPath);
            if (fs.existsSync(audioPath)) fs.unlinkSync(audioPath);
            await editReply(xy, sentMessage.message_id, '<blockquote>❌ <b>Gagal mengunduh YouTube!</b></blockquote>');
        }
    })();
};

// --- SPOTIFY ---
const handleSpotify = async (context) => {
    const { xy, reply, q, editReply, InputFile } = context;
    if (!q || !q.includes('spotify.com')) return reply('<blockquote>❌ Masukkan URL Spotify yang valid!</blockquote>', { parse_mode: 'HTML' });
    const sentMessage = await reply("<blockquote>⏳ <b>Sedang mengunduh lagu Spotify...</b></blockquote>", { parse_mode: 'HTML' });
    (async () => {
        try {
            const res = await fetch(`https://api.nekorinn.my.id/downloader/spotify?url=${encodeURIComponent(q)}`);
            if (!res.ok) throw new Error('Gagal mengambil data lagu.');
            const data = await res.json();
            if (!data.status) throw new Error('Lagu tidak ditemukan!');

            const { title, artist, imageUrl, downloadUrl } = data.result;
            const fileName = `${title.replace(/[^\w\s]/gi, '')}.mp3`;
            const filePath = path.join('./temp', fileName);
            const tempDir = './temp';
            if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });
            
            const response = await axios({ method: 'GET', url: downloadUrl, responseType: 'stream' });
            const writer = fs.createWriteStream(filePath);
            response.data.pipe(writer);
            await new Promise((resolve, reject) => { writer.on('finish', resolve); writer.on('error', reject); });
            
            let thumbnailPath = null;
            if (imageUrl) {
                try {
                    thumbnailPath = path.join(tempDir, `thumb_${Date.now()}.jpg`);
                    const thumbResponse = await axios({ method: 'GET', url: imageUrl, responseType: 'stream' });
                    const thumbWriter = fs.createWriteStream(thumbnailPath);
                    thumbResponse.data.pipe(thumbWriter);
                    await new Promise((resolve, reject) => { thumbWriter.on('finish', resolve); thumbWriter.on('error', reject); });
                } catch (thumbErr) { console.error("Thumbnail download error:", thumbErr); }
            }

            await xy.api.sendAudio(xy.chat.id, new InputFile(filePath), {
                caption: `<blockquote>🎵 <b>${title}</b></blockquote>`,
                title: title,
                performer: artist,
                thumbnail: thumbnailPath ? new InputFile(thumbnailPath) : undefined,
                parse_mode: 'HTML'
            });
            fs.unlinkSync(filePath);
            if (thumbnailPath && fs.existsSync(thumbnailPath)) fs.unlinkSync(thumbnailPath);
            await editReply(xy, sentMessage.message_id, `<blockquote>✅ Lagu Spotify berhasil dikirim!</blockquote>`);
        } catch (err) {
            console.error("Spotify Error:", err);
            await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal download lagu Spotify: ${err.message}</blockquote>`);
        }
    })();
};

// --- SCREENSHOT WEB ---
const handleSsweb = async (context) => {
    const { xy, reply, text, editReply, prefix, command, InputFile } = context;
    if (!text) return reply(`<blockquote>❌ <b>Format salah!</b>\n\nContoh: <code>${prefix + command} https://github.com</code></blockquote>`, { parse_mode: 'HTML' });
    const sentMessage = await reply('<blockquote>⏳ <b>Sedang mengambil Screenshot Web...</b></blockquote>', { parse_mode: 'HTML' });
    (async () => {
        const url = text.startsWith('http') ? text : 'https://' + text;
        const screenshotUrl = `https://image.thum.io/get/width/1900/crop/1000/fullpage/${url}`;
        const filename = path.join(__dirname, 'screenshot.jpg'); // Gunakan __dirname
        try {
            const response = await axios.get(screenshotUrl, { responseType: 'stream' });
            const writer = fs.createWriteStream(filename);
            response.data.pipe(writer);
            await new Promise((resolve, reject) => { writer.on('finish', resolve); writer.on('error', reject); });
            await xy.api.sendPhoto(xy.chat.id, new InputFile(filename), { caption: '<blockquote>✅ <b>Screenshot berhasil diambil!</b></blockquote>', parse_mode: 'HTML' });
            fs.unlinkSync(filename);
            await editReply(xy, sentMessage.message_id, `<blockquote>✅ Proses screenshot selesai.</blockquote>`);
        } catch (err) {
            console.error('Kesalahan saat mengambil screenshot:', err);
            await editReply(xy, sentMessage.message_id, '<blockquote>❌ <b>Gagal mengambil screenshot, coba lagi nanti!</b></blockquote>');
        }
    })();
};

// --- PINTEREST ---
const handlePinterest = async (context) => {
    const { xy, reply, text, editReply, prefix, command } = context;
    if (!text) return reply(`<blockquote>• <b>Contoh:</b> <code>${prefix + command} Anime</code></blockquote>`, { parse_mode: 'HTML' });
    const sentMessage = await reply('<blockquote>⏳ Sedang mencari gambar dari Pinterest...</blockquote>', { parse_mode: 'HTML' });
    (async () => {
        try {
            let images = await pinterest(text);
            if (!images || images.length === 0) {
                return editReply(xy, sentMessage.message_id, `<blockquote>❌ Tidak ditemukan gambar untuk "${text}".</blockquote>`);
            }
            images = images.sort(() => Math.random() - 0.5);
            const selectedImages = images.slice(0, 5);
            let i = 1;
            for (const imageUrl of selectedImages) {
                await xy.api.sendPhoto(xy.chat.id, imageUrl, { caption: `<blockquote>📸 Gambar ke-${i++}</blockquote>`, parse_mode: 'HTML' });
            }
            await editReply(xy, sentMessage.message_id, `<blockquote>✅ Berikut hasil pencarian Pinterest untuk "${text}".</blockquote>`);
        } catch (err) {
            console.error('Pinterest Error:', err);
            await editReply(xy, sentMessage.message_id, `<blockquote>❌ Terjadi kesalahan saat mengambil gambar dari Pinterest.</blockquote>`);
        }
    })();
};


// Ekspor semua fungsi
module.exports = {
    'tiktok': handleTiktok,
    'tiktokslide': handleTiktokSlide,
    'igdl': handleIgdl,
    'ytdl': handleYtdl,
    'spo': handleSpotify,
    'spotify': handleSpotify,
    'spotifydl': handleSpotify,
    'playspotify': handleSpotify,
    'ssweb': handleSsweb,
    'pinterest': handlePinterest,
    'pin': handlePinterest,
};

