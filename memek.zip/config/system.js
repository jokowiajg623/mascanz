// config/system.js
// Berisi perintah untuk mengelola bot (stop, restart)

const path = require('path');
const { spawn } = require("child_process");

const handleStop = async (context) => {
    const { reply, isOwner, mess } = context;
    if (!isOwner) return reply(mess.owner);
    
    const confirmationMessage = '<blockquote>✅ <b>Bot dihentikan!</b>\n\nSistem Node.js telah dimatikan. \n\n⚠️ **PENTING:** Jika bot otomatis menyala lagi, ini berarti Anda menggunakan **PM2** atau **forever**.\nUntuk mematikan total, jalankan perintah ini di terminal server Anda: \n`pm2 stop <nama_aplikasi>` atau `kill <ID_PROSES_BOT>`</blockquote>';
    
    reply(confirmationMessage, { parse_mode: 'HTML' })
      .catch(e => console.error("Gagal mengirim notifikasi stop:", e.message))
      .finally(() => {
        setTimeout(() => {
             console.log("STOP: Bot dihentikan secara paksa melalui SIGTERM.");
             process.kill(process.pid, 'SIGTERM'); 
        }, 500); 
      });
};

const handleRestart = async (context) => {
    const { reply, isOwner, mess } = context;
    if (!isOwner) return reply(mess.owner);
    
    await reply("<blockquote>🔄 <b>Memulai Restart Bot...</b>\n\n<i>Bot akan offline sebentar dan kembali otomatis.</i></blockquote>", {
      parse_mode: 'HTML'
    });
    
    setTimeout(() => {
      try {        
        const child = spawn(process.argv[0], [path.join(__dirname, '../index.js'), '--restarted'], {
          detached: true,
          stdio: 'inherit',
        });
        child.unref();
        process.kill(process.pid, 'SIGTERM'); 
      } catch (e) {
        console.error("Gagal melakukan restart:", e);
        reply("<blockquote>❌ Gagal melakukan restart. Cek log server.</blockquote>", {
          parse_mode: 'HTML'
        });
      }
    }, 3000); 
};

module.exports = {
    'stop': handleStop,
    'restart': handleRestart,
};

