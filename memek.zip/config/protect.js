const { Client } = require('ssh2');
const fs =require('fs');

/**
 * Fungsi helper untuk menjalankan perintah SSH dengan logging dasar.
 * @param {object} context - Konteks dari xy.js (termasuk reply, q, isOwner)
 * @param {string} scriptURL - URL ke skrip bash yang akan dijalankan.
 * @param {string} actionName - Nama aksi (misal: "Install Protect 1")
 */
async function runProtectScript(context, scriptURL, actionName) {
    const { q, reply, isOwner } = context;

    // Hanya Owner yang bisa menjalankan ini
    if (!isOwner) {
        return reply(global.mess.owner);
    }

    // Validasi format input
    if (!q || !q.includes('|')) {
        return reply(`❌ Format salah!\nGunakan: /perintah ipvps|pwvps`);
    }

    const [ipvps, pwvps] = q.split('|').map(i => i.trim());
    if (!ipvps || !pwvps) {
        return reply(`❌ Format salah!\nInput tidak lengkap. Gunakan: /perintah ipvps|pwvps`);
    }

    const conn = new Client();
    await reply(`⏳ Menghubungkan ke VPS *${ipvps}* dan memulai *${actionName}*...`, { parse_mode: 'Markdown' });

    conn.on('ready', () => {
        reply('⚙️ Koneksi berhasil! Proses sedang berjalan...');

        // Jalankan skrip install via SSH
        conn.exec(`curl -fsSL ${scriptURL} | bash`, (err, stream) => {
            if (err) {
                conn.end();
                return reply(`❌ Gagal mengeksekusi perintah:\n\`${err.message}\``, { parse_mode: 'Markdown' });
            }

            let output = '';
            stream.on('data', (data) => { output += data.toString(); });
            stream.stderr.on('data', (data) => { output += `\n[ERROR] ${data.toString()}`; });

            stream.on('close', () => {
                conn.end();
                const cleanOutput = output.trim().slice(-3800) || '(tidak ada output)';
                reply(`✅ *${actionName} selesai!*\n\n📦 Output terakhir:\n\`\`\`${cleanOutput}\`\`\``, {
                    parse_mode: 'Markdown'
                });
            });
        });
    });

    conn.on('error', (err) => {
        reply(`❌ Gagal terhubung ke VPS!\nPeriksa IP & Password kamu.\n\nError:\n\`${err.message}\``, {
            parse_mode: 'Markdown'
        });
    });

    try {
        conn.connect({
            host: ipvps,
            port: 22,
            username: 'root',
            password: pwvps
        });
    } catch (e) {
        reply(`❌ Gagal koneksi: ${e.message}`);
    }
}

// --- INSTALL HANDLERS ---

async function installprotect1(context) {
    await runProtectScript(context, 'https://raw.githubusercontent.com/jhonaleyhost-oss/installpanel/main/installprotect1.sh', 'Install Protect 1');
}
async function installprotect2(context) {
    await runProtectScript(context, 'https://raw.githubusercontent.com/jhonaleyhost-oss/installpanel/main/installprotect2.sh', 'Install Protect 2');
}
async function installprotect3(context) {
    await runProtectScript(context, 'https://raw.githubusercontent.com/jhonaleyhost-oss/installpanel/main/installprotect3.sh', 'Install Protect 3');
}
async function installprotect4(context) {
    await runProtectScript(context, 'https://raw.githubusercontent.com/jhonaleyhost-oss/installpanel/main/installprotect4.sh', 'Install Protect 4');
}
async function installprotect5(context) {
    await runProtectScript(context, 'https://raw.githubusercontent.com/jhonaleyhost-oss/installpanel/main/installprotect5.sh', 'Install Protect 5');
}
async function installprotect6(context) {
    await runProtectScript(context, 'https://raw.githubusercontent.com/jhonaleyhost-oss/installpanel/main/installprotect6.sh', 'Install Protect 6');
}
async function installprotect7(context) {
    await runProtectScript(context, 'https://raw.githubusercontent.com/jhonaleyhost-oss/installpanel/main/installprotect7.sh', 'Install Protect 7');
}
async function installprotect8(context) {
    await runProtectScript(context, 'https://raw.githubusercontent.com/jhonaleyhost-oss/installpanel/main/installprotect8.sh', 'Install Protect 8');
}
async function installprotect9(context) {
    await runProtectScript(context, 'https://raw.githubusercontent.com/jhonaleyhost-oss/installpanel/main/installprotect9.sh', 'Install Protect 9');
}
async function installprotectall(context) {

    
    const { q, reply, isOwner } = context;
    if (!isOwner) return reply(global.mess.owner);
    if (!q || !q.includes('|')) return reply(`❌ Format salah!\nGunakan: /installprotectall ipvps|pwvps`);
    
    const [ipvps, pwvps] = q.split('|').map(i => i.trim());
    if (!ipvps || !pwvps) return reply(`❌ Format salah!\nInput tidak lengkap.`);

    const conn = new Client();
    await reply(`⏳ Menghubungkan ke VPS *${ipvps}* dan memulai *Install Protect 1-9*...`, { parse_mode: 'Markdown' });
    
    const scripts = [
        { name: 'Protect 1', url: 'https://raw.githubusercontent.com/jhonaleyhost-oss/installpanel/main/installprotect1.sh' },
        { name: 'Protect 2', url: 'https://raw.githubusercontent.com/jhonaleyhost-oss/installpanel/main/installprotect2.sh' },
        { name: 'Protect 3', url: 'https://raw.githubusercontent.com/jhonaleyhost-oss/installpanel/main/installprotect3.sh' },
        { name: 'Protect 4', url: 'https://raw.githubusercontent.com/jhonaleyhost-oss/installpanel/main/installprotect4.sh' },
        { name: 'Protect 5', url: 'https://raw.githubusercontent.com/jhonaleyhost-oss/installpanel/main/installprotect5.sh' },
        { name: 'Protect 6', url: 'https://raw.githubusercontent.com/jhonaleyhost-oss/installpanel/main/installprotect6.sh' },
        { name: 'Protect 7', url: 'https://raw.githubusercontent.com/jhonaleyhost-oss/installpanel/main/installprotect7.sh' },
        { name: 'Protect 8', url: 'https://raw.githubusercontent.com/jhonaleyhost-oss/installpanel/main/installprotect8.sh' },
        { name: 'Protect 9', url: 'https://raw.githubusercontent.com/jhonaleyhost-oss/installpanel/main/installprotect9.sh' },
    ];

    conn.on('ready', async () => {
        reply('⚙️ Koneksi berhasil! Memulai instalasi berurutan...');
        for (const script of scripts) {
            await reply(`🚀 Memulai *${script.name}*...`, { parse_mode: 'Markdown' });
            await new Promise((resolve) => {
                conn.exec(`curl -fsSL ${script.url} | bash`, (err, stream) => {
                    if (err) {
                        reply(`❌ Gagal mengeksekusi ${script.name}:\n\`${err.message}\``, { parse_mode: 'Markdown' });
                        return resolve();
                    }
                    let output = '';
                    stream.on('data', (data) => { output += data.toString(); });
                    stream.stderr.on('data', (data) => { output += `\n[ERROR] ${data.toString()}`; });
                    stream.on('close', () => {
                        reply(`✅ *${script.name} selesai!*`, { parse_mode: 'Markdown' });
                        resolve();
                    });
                });
            });
        }
        conn.end();
        reply('🎉 *Semua instalasi Protect 1-9 selesai!*', { parse_mode: 'Markdown' });
    });

    conn.on('error', (err) => reply(`❌ Gagal terhubung: ${err.message}`));
    conn.connect({ host: ipvps, port: 22, username: 'root', password: pwvps });
}

// --- UNINSTALL HANDLERS ---

async function uninstallprotect1(context) {
    await runProtectScript(context, 'https://raw.githubusercontent.com/jhonaleyhost-oss/uninstallprotect/main/uninstallprotect1.sh', 'Uninstall Protect 1');
}
async function uninstallprotect2(context) {
    await runProtectScript(context, 'https://raw.githubusercontent.com/jhonaleyhost-oss/uninstallprotect/main/uninstallprotect2.sh', 'Uninstall Protect 2');
}
async function uninstallprotect3(context) {
    await runProtectScript(context, 'https://raw.githubusercontent.com/jhonaleyhost-oss/uninstallprotect/main/uninstallprotect3.sh', 'Uninstall Protect 3');
}
async function uninstallprotect4(context) {
    await runProtectScript(context, 'https://raw.githubusercontent.com/jhonaleyhost-oss/uninstallprotect/main/uninstallprotect4.sh', 'Uninstall Protect 4');
}
async function uninstallprotect5(context) {
    await runProtectScript(context, 'https://raw.githubusercontent.com/jhonaleyhost-oss/uninstallprotect/main/uninstallprotect5.sh', 'Uninstall Protect 5');
}
async function uninstallprotect6(context) {
    await runProtectScript(context, 'https://raw.githubusercontent.com/jhonaleyhost-oss/uninstallprotect/main/uninstallprotect6.sh', 'Uninstall Protect 6');
}
async function uninstallprotect7(context) {
    await runProtectScript(context, 'https://raw.githubusercontent.com/jhonaleyhost-oss/uninstallprotect/main/uninstallprotect7.sh', 'Uninstall Protect 7');
}
async function uninstallprotect8(context) {
    await runProtectScript(context, 'https://raw.githubusercontent.com/jhonaleyhost-oss/uninstallprotect/main/uninstallprotect8.sh', 'Uninstall Protect 8');
}
async function uninstallprotect9(context) {
    await runProtectScript(context, 'https://raw.githubusercontent.com/jhonaleyhost-oss/uninstallprotect/main/uninstallprotect9.sh', 'Uninstall Protect 9');
}
async function uninstallprotectall(context) {
    // Logika ini juga meniru install.js
    const { q, reply, isOwner } = context;
    if (!isOwner) return reply(global.mess.owner);
    if (!q || !q.includes('|')) return reply(`❌ Format salah!\nGunakan: /uninstallprotectall ipvps|pwvps`);

    const [ipvps, pwvps] = q.split('|').map(i => i.trim());
    if (!ipvps || !pwvps) return reply(`❌ Format salah!\nInput tidak lengkap.`);
    
    const conn = new Client();
    await reply(`⏳ Menghubungkan ke VPS *${ipvps}* dan memulai *Uninstall Protect 1-9*...`, { parse_mode: 'Markdown' });

    const scripts = [
        { name: 'Uninstall Protect 1', url: 'https://raw.githubusercontent.com/jhonaleyhost-oss/uninstallprotect/main/uninstallprotect1.sh' },
        { name: 'Uninstall Protect 2', url: 'https://raw.githubusercontent.com/jhonaleyhost-oss/uninstallprotect/main/uninstallprotect2.sh' },
        { name: 'Uninstall Protect 3', url: 'https://raw.githubusercontent.com/jhonaleyhost-oss/uninstallprotect/main/uninstallprotect3.sh' },
        { name: 'Uninstall Protect 4', url: 'https://raw.githubusercontent.com/jhonaleyhost-oss/uninstallprotect/main/uninstallprotect4.sh' },
        { name: 'Uninstall Protect 5', url: 'https://raw.githubusercontent.com/jhonaleyhost-oss/uninstallprotect/main/uninstallprotect5.sh' },
        { name: 'Uninstall Protect 6', url: 'https://raw.githubusercontent.com/jhonaleyhost-oss/uninstallprotect/main/uninstallprotect6.sh' },
        { name: 'Uninstall Protect 7', url: 'https://raw.githubusercontent.com/jhonaleyhost-oss/uninstallprotect/main/uninstallprotect7.sh' },
        { name: 'Uninstall Protect 8', url: 'https://raw.githubusercontent.com/jhonaleyhost-oss/uninstallprotect/main/uninstallprotect8.sh' },
        { name: 'Uninstall Protect 9', url: 'https://raw.githubusercontent.com/jhonaleyhost-oss/uninstallprotect/main/uninstallprotect9.sh' },
    ];

    conn.on('ready', async () => {
        reply('⚙️ Koneksi berhasil! Memulai uninstall berurutan...');
        for (const script of scripts) {
            await reply(`🚀 Memulai *${script.name}*...`, { parse_mode: 'Markdown' });
            await new Promise((resolve) => {
                conn.exec(`curl -fsSL ${script.url} | bash`, (err, stream) => {
                    if (err) {
                        reply(`❌ Gagal mengeksekusi ${script.name}:\n\`${err.message}\``, { parse_mode: 'Markdown' });
                        return resolve();
                    }
                    stream.on('data', () => {});
                    stream.stderr.on('data', () => {});
                    stream.on('close', () => {
                        reply(`✅ *${script.name} selesai!*`, { parse_mode: 'Markdown' });
                        resolve();
                    });
                });
            });
        }
        conn.end();
        reply('🎉 *Semua uninstall Protect 1-9 selesai!*', { parse_mode: 'Markdown' });
    });

    conn.on('error', (err) => reply(`❌ Gagal terhubung: ${err.message}`));
    conn.connect({ host: ipvps, port: 22, username: 'root', password: pwvps });
}

module.exports = {
    installprotect1,
    installprotect2,
    installprotect3,
    installprotect4,
    installprotect5,
    installprotect6,
    installprotect7,
    installprotect8,
    installprotect9,
    installprotectall,
    uninstallprotect1,
    uninstallprotect2,
    uninstallprotect3,
    uninstallprotect4,
    uninstallprotect5,
    uninstallprotect6,
    uninstallprotect7,
    uninstallprotect8,
    uninstallprotect9,
    uninstallprotectall
};